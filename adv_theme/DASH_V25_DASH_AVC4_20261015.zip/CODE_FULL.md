# V25-DASH 코드 전문

설치·실행 명령은 RUN_KR.md, 모델의 출처와 수치 계약은 v25_dash/README_KR.md를 먼저 읽는다. examples/synthetic_only는 기능 검증용 예시다.

## INSTALL_V25.py

```python
#!/usr/bin/env python3
"""Add only v25_dash to an existing adv_theme; reject conflicts rather than overwrite."""
import argparse
import hashlib
from pathlib import Path
import shutil

def digest(p):return hashlib.sha256(p.read_bytes()).digest()

def main():
    a=argparse.ArgumentParser();a.add_argument('--adv-theme',required=True);args=a.parse_args()
    source=Path(__file__).resolve().parent/'v25_dash';root=Path(args.adv_theme).resolve()
    required=('src/dash_cnn/data/audit.py','src/dash_cnn/evaluation/metrics.py','tests/make_smoke_data.py')
    for f in required:
        if not (root/f).is_file():raise SystemExit('Existing adv_theme helper missing: '+str(root/f))
    dest=root/'v25_dash';pairs=[(p,dest/p.relative_to(source)) for p in sorted(source.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
    # Complete conflict check before copying any file.
    for original,target in pairs:
        if target.is_symlink():raise SystemExit('Refusing symlink target: '+str(target))
        if target.exists() and (not target.is_file() or digest(original)!=digest(target)):
            raise SystemExit('Different v25_dash file already exists: '+str(target)+'; choose another installation root')
        for parent in target.parents:
            if parent==root:break
            if parent.is_symlink():raise SystemExit('Refusing symlink directory: '+str(parent))
    added=0
    for original,target in pairs:
        if not target.exists():target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,target);added+=1
    print('INSTALLED',dest,'new_files='+str(added))
    print('Next: cd '+str(root)+' && python v25_dash/run.py doctor')

if __name__=='__main__':main()
```

## v25_dash/examples/synthetic_only/NOTICE.txt

```text
SYNTHETIC_SMOKE_ONLY
24 samples/split, 2 FP32 + 2 INT8 + 2 V25-H epochs.
These are plumbing checks, not BBB/ED accuracy or PPA claims.
Generated RTL is an inspection/reproduction example; actual DASH RTL is regenerated from your trained export.
```

## v25_dash/examples/synthetic_only/int8/mul/tb_engine.sv

```systemverilog
`timescale 1ps/1ps
module tb_engine;
reg clk=0,rst_n=0,req_valid=0,req_is_fc=0;reg [15:0] req_tag=0;
reg signed [8:0] tile[0:5][0:5],fa[0:47];wire rv,rf;wire [15:0] rt;
wire signed [31:0] y0,y1,y2,y3,fs;
v25_dash_engine dut(clk,rst_n,req_valid,req_is_fc,req_tag,tile,fa,rv,rf,rt,y0,y1,y2,y3,fs);
always #5 clk=~clk;
reg [7:0] xs[0:9215];reg [15:0] tags[0:191];reg fcs[0:191];reg [31:0] ys[0:767];
integer sent=0,received=0,r,c,j,cycle=0,issue_cycle[0:191];
always @(posedge clk)begin
 cycle=cycle+1;
 if(rst_n && req_valid)begin issue_cycle[sent]=cycle;sent=sent+1;end
 #1;
 if(rst_n && rv)begin
  if(received>=sent || rt!==tags[received] || rf!==fcs[received])$fatal(1,"FAIL engine tag/order");
  if(cycle-issue_cycle[received]!=6)$fatal(1,"FAIL engine latency");
  if(rf)begin if(fs!==ys[received*4])$fatal(1,"FAIL FC engine case=%0d got=%0d expected=%0d",received,fs,$signed(ys[received*4]));end
  else if(y0!==ys[received*4]||y1!==ys[received*4+1]||y2!==ys[received*4+2]||y3!==ys[received*4+3])
   $fatal(1,"FAIL Conv engine case=%0d got=%0d,%0d,%0d,%0d expected=%0d,%0d,%0d,%0d",received,y0,y1,y2,y3,$signed(ys[received*4]),$signed(ys[received*4+1]),$signed(ys[received*4+2]),$signed(ys[received*4+3]));
  received=received+1;
 end
end
initial begin
 $readmemh("engine_x.hex",xs);$readmemh("engine_tag.hex",tags);$readmemh("engine_fc.hex",fcs);$readmemh("engine_y.hex",ys);
 repeat(3)@(negedge clk);rst_n=1;
 for(j=0;j<192;j=j+1)begin
  if(j%11==0)begin req_valid=0;@(negedge clk);end
  req_valid=1;req_tag=tags[j];req_is_fc=fcs[j];
  for(r=0;r<6;r=r+1)for(c=0;c<6;c=c+1)tile[r][c]={1'b0,xs[j*48+r*6+c]};
  for(r=0;r<48;r=r+1)fa[r]={1'b0,xs[j*48+r]};
  @(negedge clk);
 end
 req_valid=0;repeat(10)@(negedge clk);
 if(received!=192)$fatal(1,"FAIL missing engine results");
 $display("PASS engine: 192 requests, all coefficient tags, bubbles, II=1, latency=6");$finish;
end
endmodule
```

## v25_dash/examples/synthetic_only/int8/mul/tb_top.sv

```systemverilog
`timescale 1ps/1ps
module tb_top;
reg clk=0,rst_n=0;reg [7:0] data_in=0;wire [1:0] decision;wire valid_out_6;wire [127:0] logits;
v25_dash_top dut(clk,rst_n,data_in,decision,valid_out_6,logits);
always #5 clk=~clk;
reg [7:0] pixels[0:5487],p1[0:2015],p2[0:335];
reg [31:0] scores[0:27];reg [1:0] decisions[0:6];
integer n,j,c,r,col,cycles;
always @(posedge clk)begin
 if(rst_n)begin
  if(dut.c1_wb_valid)begin
   r=dut.c1_commit_count/24;c=dut.c1_wb_oc;col=dut.c1_wb_pc;
   if(dut.max4_relu_a8(dut.c1_wb_q00,dut.c1_wb_q01,dut.c1_wb_q10,dut.c1_wb_q11)!==p1[n*288+c*144+r*12+col])
    $fatal(1,"FAIL pool1 case=%0d channel=%0d row=%0d col=%0d",n,c,r,col);
  end
 end
end
task reset_patch;begin rst_n=0;data_in=0;repeat(3)@(negedge clk);rst_n=1;@(negedge clk);end endtask
initial begin
 $readmemh("pixels.hex",pixels);$readmemh("scores.hex",scores);$readmemh("pool1.hex",p1);$readmemh("pool2.hex",p2);$readmemh("decision.hex",decisions);
 for(n=0;n<7;n=n+1)begin
  reset_patch();
  for(j=0;j<784;j=j+1)begin data_in=pixels[n*784+j];@(negedge clk);end
  data_in=0;cycles=784;
  while(!valid_out_6 && cycles<2000)begin @(negedge clk);cycles=cycles+1;end
  if(!valid_out_6)$fatal(1,"FAIL top timeout");
  for(c=0;c<4;c=c+1)if(logits[c*32+:32]!==scores[n*4+c])$fatal(1,"FAIL score case=%0d class=%0d got=%0d expected=%0d",n,c,$signed(logits[c*32+:32]),$signed(scores[n*4+c]));
  if(decision!==decisions[n])$fatal(1,"FAIL decision");
  for(c=0;c<3;c=c+1)for(r=0;r<4;r=r+1)for(col=0;col<4;col=col+1)
   if(dut.fmap2[c][r][col]!==p2[n*48+c*16+r*4+col])$fatal(1,"FAIL pool2");
  if(dut.c1_commit_count!=288||dut.c2_commit_count!=48)$fatal(1,"FAIL commit count");
  $display("PASS top case=%0d class=%0d input_start_to_result_cycles=%0d",n,decision,cycles);
  repeat(3)begin @(negedge clk);if(valid_out_6)$fatal(1,"FAIL repeated valid");end
 end
 // Interrupt a fresh patch, reset, then reproduce case zero to catch stale ring/valid state.
 n=0;reset_patch();for(j=0;j<97;j=j+1)begin data_in=pixels[j];@(negedge clk);end
 reset_patch();for(j=0;j<784;j=j+1)begin data_in=pixels[j];@(negedge clk);end
 cycles=784;while(!valid_out_6&&cycles<2000)begin @(negedge clk);cycles=cycles+1;end
 if(!valid_out_6||decision!==decisions[0])$fatal(1,"FAIL mid-patch reset");
 for(c=0;c<4;c=c+1)if(logits[c*32+:32]!==scores[c])$fatal(1,"FAIL reset score");
 $display("PASS top: all four scores, both pooled maps, U8 extremes, repeat reset, mid-patch reset");$finish;
end
endmodule
```

## v25_dash/examples/synthetic_only/int8/mul/v25_dash_engine.sv

```systemverilog
`timescale 1ps/1ps
// V25-derived 49-lane coefficient-specific shared pipeline; generated for DASH.
// mode=int8, backend=mul; P0 request -> P6 response, II=1.
module v25_dash_engine(input logic clk,rst_n,req_valid,req_is_fc, input logic [15:0] req_tag,
input wire signed [8:0] conv_tile[0:5][0:5], input wire signed [8:0] fc_a[0:47],
output logic rsp_valid,rsp_is_fc, output logic [15:0] rsp_tag,
output logic signed [31:0] conv_y00,conv_y01,conv_y10,conv_y11,fc_sum);
logic [6:0] valid_pipe,mode_pipe; logic [15:0] tag_pipe[0:6]; integer k;
always @(posedge clk) begin if(!rst_n)begin valid_pipe<=0;mode_pipe<=0;for(k=0;k<7;k=k+1)tag_pipe[k]<=0;end
else begin valid_pipe<={valid_pipe[5:0],req_valid};mode_pipe<={mode_pipe[5:0],req_is_fc};
tag_pipe[0]<=req_tag;for(k=1;k<7;k=k+1)tag_pipe[k]<=tag_pipe[k-1];end end
assign rsp_valid=valid_pipe[6];assign rsp_is_fc=mode_pipe[6];assign rsp_tag=tag_pipe[6];
logic [7:0] x0[0:35],f0[0:47],f1[0:47];integer r,c;
always @(posedge clk)begin if(!rst_n)begin for(r=0;r<36;r=r+1)x0[r]<=0;
for(r=0;r<48;r=r+1)begin f0[r]<=0;f1[r]<=0;end end else begin
if(req_valid)begin if(req_is_fc)begin for(r=0;r<48;r=r+1)f0[r]<=fc_a[r][7:0];end
else begin for(r=0;r<6;r=r+1)for(c=0;c<6;c=c+1)x0[r*6+c]<=conv_tile[r][c][7:0];end end
if(valid_pipe[0]&&mode_pipe[0])for(r=0;r<48;r=r+1)f1[r]<=f0[r];end end
wire [6:0] key1={mode_pipe[1],tag_pipe[1][15],(mode_pipe[1]?tag_pipe[1][4]:1'b0),tag_pipe[1][3:0]};
wire [6:0] key2={mode_pipe[2],tag_pipe[2][15],(mode_pipe[2]?tag_pipe[2][4]:1'b0),tag_pipe[2][3:0]};
logic signed [9:0] b1_0,a2_0;logic signed [18:0] p3_0;
always @(posedge clk)begin if(!rst_n)begin b1_0<=0;a2_0<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_0<=(($signed({2'd0,x0[0]}) + -$signed({2'd0,x0[2]})) + (-$signed({2'd0,x0[12]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_0<=mode_pipe[1]?$signed({2'd0,f1[0]}):b1_0;
end end
logic signed [9:0] coefficient2_0;
always @(posedge clk)begin if(!rst_n)coefficient2_0<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_0<=-10'sd284;
7'd4:coefficient2_0<=-10'sd212;
7'd32:coefficient2_0<=10'sd12;
7'd33:coefficient2_0<=-10'sd168;
7'd36:coefficient2_0<=10'sd4;
7'd37:coefficient2_0<=10'sd148;
7'd40:coefficient2_0<=10'sd132;
7'd41:coefficient2_0<=10'sd280;
7'd64:coefficient2_0<=10'sd18;
7'd65:coefficient2_0<=-10'sd63;
7'd66:coefficient2_0<=-10'sd45;
7'd67:coefficient2_0<=-10'sd62;
default:coefficient2_0<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_0<=0;else if(valid_pipe[2])p3_0<=$signed({{9{a2_0[9]}},a2_0})*$signed({{9{coefficient2_0[9]}},coefficient2_0});end
logic signed [9:0] b1_1,a2_1;logic signed [17:0] p3_1;
always @(posedge clk)begin if(!rst_n)begin b1_1<=0;a2_1<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_1<=(($signed({2'd0,x0[1]}) + $signed({2'd0,x0[2]})) + (-$signed({2'd0,x0[13]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_1<=mode_pipe[1]?$signed({2'd0,f1[1]}):b1_1;
end end
logic signed [8:0] coefficient2_1;
always @(posedge clk)begin if(!rst_n)coefficient2_1<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_1<=-9'sd150;
7'd4:coefficient2_1<=-9'sd28;
7'd32:coefficient2_1<=-9'sd16;
7'd33:coefficient2_1<=-9'sd230;
7'd36:coefficient2_1<=9'sd36;
7'd37:coefficient2_1<=9'sd140;
7'd40:coefficient2_1<=-9'sd24;
7'd41:coefficient2_1<=9'sd94;
7'd64:coefficient2_1<=9'sd55;
7'd65:coefficient2_1<=-9'sd24;
7'd66:coefficient2_1<=9'sd17;
7'd67:coefficient2_1<=9'sd40;
default:coefficient2_1<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_1<=0;else if(valid_pipe[2])p3_1<=$signed({{8{a2_1[9]}},a2_1})*$signed({{9{coefficient2_1[8]}},coefficient2_1});end
logic signed [9:0] b1_2,a2_2;logic signed [18:0] p3_2;
always @(posedge clk)begin if(!rst_n)begin b1_2<=0;a2_2<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_2<=((-$signed({2'd0,x0[1]}) + $signed({2'd0,x0[2]})) + ($signed({2'd0,x0[13]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_2<=mode_pipe[1]?$signed({2'd0,f1[2]}):b1_2;
end end
logic signed [9:0] coefficient2_2;
always @(posedge clk)begin if(!rst_n)coefficient2_2<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_2<=10'sd54;
7'd4:coefficient2_2<=-10'sd344;
7'd32:coefficient2_2<=-10'sd152;
7'd33:coefficient2_2<=10'sd38;
7'd36:coefficient2_2<=10'sd160;
7'd37:coefficient2_2<=-10'sd28;
7'd40:coefficient2_2<=10'sd108;
7'd41:coefficient2_2<=10'sd222;
7'd64:coefficient2_2<=10'sd37;
7'd65:coefficient2_2<=10'sd41;
7'd66:coefficient2_2<=-10'sd14;
7'd67:coefficient2_2<=10'sd24;
default:coefficient2_2<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_2<=0;else if(valid_pipe[2])p3_2<=$signed({{9{a2_2[9]}},a2_2})*$signed({{9{coefficient2_2[9]}},coefficient2_2});end
logic signed [9:0] b1_3,a2_3;logic signed [17:0] p3_3;
always @(posedge clk)begin if(!rst_n)begin b1_3<=0;a2_3<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_3<=(($signed({2'd0,x0[1]}) + -$signed({2'd0,x0[3]})) + (-$signed({2'd0,x0[13]}) + $signed({2'd0,x0[15]})));
if(valid_pipe[1])a2_3<=mode_pipe[1]?$signed({2'd0,f1[3]}):b1_3;
end end
logic signed [8:0] coefficient2_3;
always @(posedge clk)begin if(!rst_n)coefficient2_3<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_3<=9'sd188;
7'd4:coefficient2_3<=-9'sd160;
7'd32:coefficient2_3<=-9'sd180;
7'd33:coefficient2_3<=-9'sd24;
7'd36:coefficient2_3<=9'sd192;
7'd37:coefficient2_3<=-9'sd36;
7'd40:coefficient2_3<=-9'sd48;
7'd41:coefficient2_3<=9'sd36;
7'd64:coefficient2_3<=9'sd24;
7'd65:coefficient2_3<=9'sd40;
7'd66:coefficient2_3<=9'sd70;
7'd67:coefficient2_3<=9'sd32;
default:coefficient2_3<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_3<=0;else if(valid_pipe[2])p3_3<=$signed({{8{a2_3[9]}},a2_3})*$signed({{9{coefficient2_3[8]}},coefficient2_3});end
logic signed [9:0] b1_4,a2_4;logic signed [18:0] p3_4;
always @(posedge clk)begin if(!rst_n)begin b1_4<=0;a2_4<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_4<=(($signed({2'd0,x0[6]}) + -$signed({2'd0,x0[8]})) + ($signed({2'd0,x0[12]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_4<=mode_pipe[1]?$signed({2'd0,f1[4]}):b1_4;
end end
logic signed [9:0] coefficient2_4;
always @(posedge clk)begin if(!rst_n)coefficient2_4<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_4<=-10'sd16;
7'd4:coefficient2_4<=10'sd92;
7'd32:coefficient2_4<=-10'sd96;
7'd33:coefficient2_4<=10'sd64;
7'd36:coefficient2_4<=10'sd112;
7'd37:coefficient2_4<=10'sd42;
7'd40:coefficient2_4<=10'sd50;
7'd41:coefficient2_4<=10'sd276;
7'd64:coefficient2_4<=10'sd24;
7'd65:coefficient2_4<=-10'sd1;
7'd66:coefficient2_4<=-10'sd72;
7'd67:coefficient2_4<=10'sd61;
default:coefficient2_4<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_4<=0;else if(valid_pipe[2])p3_4<=$signed({{9{a2_4[9]}},a2_4})*$signed({{9{coefficient2_4[9]}},coefficient2_4});end
logic signed [10:0] b1_5,a2_5;logic signed [18:0] p3_5;
always @(posedge clk)begin if(!rst_n)begin b1_5<=0;a2_5<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_5<=(($signed({3'd0,x0[7]}) + $signed({3'd0,x0[8]})) + ($signed({3'd0,x0[13]}) + $signed({3'd0,x0[14]})));
if(valid_pipe[1])a2_5<=mode_pipe[1]?$signed({3'd0,f1[5]}):b1_5;
end end
logic signed [8:0] coefficient2_5;
always @(posedge clk)begin if(!rst_n)coefficient2_5<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_5<=-9'sd77;
7'd4:coefficient2_5<=9'sd187;
7'd32:coefficient2_5<=9'sd51;
7'd33:coefficient2_5<=9'sd46;
7'd36:coefficient2_5<=-9'sd37;
7'd37:coefficient2_5<=-9'sd56;
7'd40:coefficient2_5<=-9'sd97;
7'd41:coefficient2_5<=9'sd164;
7'd64:coefficient2_5<=-9'sd32;
7'd65:coefficient2_5<=9'sd63;
7'd66:coefficient2_5<=-9'sd23;
7'd67:coefficient2_5<=-9'sd9;
default:coefficient2_5<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_5<=0;else if(valid_pipe[2])p3_5<=$signed({{8{a2_5[10]}},a2_5})*$signed({{10{coefficient2_5[8]}},coefficient2_5});end
logic signed [9:0] b1_6,a2_6;logic signed [17:0] p3_6;
always @(posedge clk)begin if(!rst_n)begin b1_6<=0;a2_6<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_6<=((-$signed({2'd0,x0[7]}) + $signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[13]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_6<=mode_pipe[1]?$signed({2'd0,f1[6]}):b1_6;
end end
logic signed [8:0] coefficient2_6;
always @(posedge clk)begin if(!rst_n)coefficient2_6<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_6<=9'sd43;
7'd4:coefficient2_6<=-9'sd55;
7'd32:coefficient2_6<=-9'sd131;
7'd33:coefficient2_6<=9'sd104;
7'd36:coefficient2_6<=9'sd49;
7'd37:coefficient2_6<=9'sd106;
7'd40:coefficient2_6<=-9'sd107;
7'd41:coefficient2_6<=9'sd144;
7'd64:coefficient2_6<=9'sd57;
7'd65:coefficient2_6<=9'sd47;
7'd66:coefficient2_6<=9'sd15;
7'd67:coefficient2_6<=9'sd9;
default:coefficient2_6<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_6<=0;else if(valid_pipe[2])p3_6<=$signed({{8{a2_6[9]}},a2_6})*$signed({{9{coefficient2_6[8]}},coefficient2_6});end
logic signed [9:0] b1_7,a2_7;logic signed [17:0] p3_7;
always @(posedge clk)begin if(!rst_n)begin b1_7<=0;a2_7<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_7<=(($signed({2'd0,x0[7]}) + -$signed({2'd0,x0[9]})) + ($signed({2'd0,x0[13]}) + -$signed({2'd0,x0[15]})));
if(valid_pipe[1])a2_7<=mode_pipe[1]?$signed({2'd0,f1[7]}):b1_7;
end end
logic signed [8:0] coefficient2_7;
always @(posedge clk)begin if(!rst_n)coefficient2_7<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_7<=-9'sd18;
7'd4:coefficient2_7<=9'sd40;
7'd32:coefficient2_7<=9'sd16;
7'd33:coefficient2_7<=9'sd86;
7'd36:coefficient2_7<=-9'sd100;
7'd37:coefficient2_7<=9'sd8;
7'd40:coefficient2_7<=-9'sd254;
7'd41:coefficient2_7<=9'sd32;
7'd64:coefficient2_7<=-9'sd55;
7'd65:coefficient2_7<=9'sd5;
7'd66:coefficient2_7<=9'sd41;
7'd67:coefficient2_7<=-9'sd15;
default:coefficient2_7<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_7<=0;else if(valid_pipe[2])p3_7<=$signed({{8{a2_7[9]}},a2_7})*$signed({{9{coefficient2_7[8]}},coefficient2_7});end
logic signed [9:0] b1_8,a2_8;logic signed [18:0] p3_8;
always @(posedge clk)begin if(!rst_n)begin b1_8<=0;a2_8<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_8<=((-$signed({2'd0,x0[6]}) + $signed({2'd0,x0[8]})) + ($signed({2'd0,x0[12]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_8<=mode_pipe[1]?$signed({2'd0,f1[8]}):b1_8;
end end
logic signed [9:0] coefficient2_8;
always @(posedge clk)begin if(!rst_n)coefficient2_8<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_8<=-10'sd12;
7'd4:coefficient2_8<=-10'sd268;
7'd32:coefficient2_8<=-10'sd112;
7'd33:coefficient2_8<=-10'sd8;
7'd36:coefficient2_8<=10'sd104;
7'd37:coefficient2_8<=10'sd254;
7'd40:coefficient2_8<=10'sd74;
7'd41:coefficient2_8<=10'sd4;
7'd64:coefficient2_8<=10'sd59;
7'd65:coefficient2_8<=-10'sd17;
7'd66:coefficient2_8<=-10'sd13;
7'd67:coefficient2_8<=-10'sd19;
default:coefficient2_8<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_8<=0;else if(valid_pipe[2])p3_8<=$signed({{9{a2_8[9]}},a2_8})*$signed({{9{coefficient2_8[9]}},coefficient2_8});end
logic signed [9:0] b1_9,a2_9;logic signed [17:0] p3_9;
always @(posedge clk)begin if(!rst_n)begin b1_9<=0;a2_9<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_9<=((-$signed({2'd0,x0[7]}) + -$signed({2'd0,x0[8]})) + ($signed({2'd0,x0[13]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_9<=mode_pipe[1]?$signed({2'd0,f1[9]}):b1_9;
end end
logic signed [8:0] coefficient2_9;
always @(posedge clk)begin if(!rst_n)coefficient2_9<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_9<=9'sd23;
7'd4:coefficient2_9<=-9'sd101;
7'd32:coefficient2_9<=9'sd49;
7'd33:coefficient2_9<=-9'sd78;
7'd36:coefficient2_9<=9'sd123;
7'd37:coefficient2_9<=9'sd248;
7'd40:coefficient2_9<=-9'sd61;
7'd41:coefficient2_9<=-9'sd8;
7'd64:coefficient2_9<=9'sd33;
7'd65:coefficient2_9<=9'sd63;
7'd66:coefficient2_9<=-9'sd72;
7'd67:coefficient2_9<=9'sd59;
default:coefficient2_9<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_9<=0;else if(valid_pipe[2])p3_9<=$signed({{8{a2_9[9]}},a2_9})*$signed({{9{coefficient2_9[8]}},coefficient2_9});end
logic signed [9:0] b1_10,a2_10;logic signed [18:0] p3_10;
always @(posedge clk)begin if(!rst_n)begin b1_10<=0;a2_10<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_10<=(($signed({2'd0,x0[7]}) + -$signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[13]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_10<=mode_pipe[1]?$signed({2'd0,f1[10]}):b1_10;
end end
logic signed [9:0] coefficient2_10;
always @(posedge clk)begin if(!rst_n)coefficient2_10<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_10<=10'sd355;
7'd4:coefficient2_10<=-10'sd411;
7'd32:coefficient2_10<=-10'sd169;
7'd33:coefficient2_10<=-10'sd24;
7'd36:coefficient2_10<=10'sd13;
7'd37:coefficient2_10<=10'sd174;
7'd40:coefficient2_10<=10'sd85;
7'd41:coefficient2_10<=-10'sd128;
7'd64:coefficient2_10<=-10'sd20;
7'd65:coefficient2_10<=-10'sd8;
7'd66:coefficient2_10<=-10'sd13;
7'd67:coefficient2_10<=-10'sd74;
default:coefficient2_10<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_10<=0;else if(valid_pipe[2])p3_10<=$signed({{9{a2_10[9]}},a2_10})*$signed({{9{coefficient2_10[9]}},coefficient2_10});end
logic signed [9:0] b1_11,a2_11;logic signed [18:0] p3_11;
always @(posedge clk)begin if(!rst_n)begin b1_11<=0;a2_11<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_11<=((-$signed({2'd0,x0[7]}) + $signed({2'd0,x0[9]})) + ($signed({2'd0,x0[13]}) + -$signed({2'd0,x0[15]})));
if(valid_pipe[1])a2_11<=mode_pipe[1]?$signed({2'd0,f1[11]}):b1_11;
end end
logic signed [9:0] coefficient2_11;
always @(posedge clk)begin if(!rst_n)coefficient2_11<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_11<=10'sd390;
7'd4:coefficient2_11<=-10'sd244;
7'd32:coefficient2_11<=-10'sd8;
7'd33:coefficient2_11<=-10'sd94;
7'd36:coefficient2_11<=10'sd32;
7'd37:coefficient2_11<=10'sd168;
7'd40:coefficient2_11<=-10'sd50;
7'd41:coefficient2_11<=-10'sd140;
7'd64:coefficient2_11<=-10'sd46;
7'd65:coefficient2_11<=10'sd33;
7'd66:coefficient2_11<=-10'sd5;
7'd67:coefficient2_11<=-10'sd27;
default:coefficient2_11<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_11<=0;else if(valid_pipe[2])p3_11<=$signed({{9{a2_11[9]}},a2_11})*$signed({{9{coefficient2_11[9]}},coefficient2_11});end
logic signed [9:0] b1_12,a2_12;logic signed [17:0] p3_12;
always @(posedge clk)begin if(!rst_n)begin b1_12<=0;a2_12<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_12<=(($signed({2'd0,x0[6]}) + -$signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[18]}) + $signed({2'd0,x0[20]})));
if(valid_pipe[1])a2_12<=mode_pipe[1]?$signed({2'd0,f1[12]}):b1_12;
end end
logic signed [9:0] coefficient2_12;
always @(posedge clk)begin if(!rst_n)coefficient2_12<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_12<=10'sd256;
7'd4:coefficient2_12<=10'sd36;
7'd32:coefficient2_12<=-10'sd220;
7'd33:coefficient2_12<=10'sd224;
7'd36:coefficient2_12<=10'sd212;
7'd37:coefficient2_12<=10'sd148;
7'd40:coefficient2_12<=-10'sd8;
7'd64:coefficient2_12<=-10'sd18;
7'd65:coefficient2_12<=10'sd32;
7'd66:coefficient2_12<=-10'sd2;
7'd67:coefficient2_12<=-10'sd38;
default:coefficient2_12<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_12<=0;else if(valid_pipe[2])p3_12<=$signed({{8{a2_12[9]}},a2_12})*$signed({{8{coefficient2_12[9]}},coefficient2_12});end
logic signed [9:0] b1_13,a2_13;logic signed [17:0] p3_13;
always @(posedge clk)begin if(!rst_n)begin b1_13<=0;a2_13<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_13<=(($signed({2'd0,x0[7]}) + $signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[19]}) + -$signed({2'd0,x0[20]})));
if(valid_pipe[1])a2_13<=mode_pipe[1]?$signed({2'd0,f1[13]}):b1_13;
end end
logic signed [8:0] coefficient2_13;
always @(posedge clk)begin if(!rst_n)coefficient2_13<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_13<=9'sd96;
7'd4:coefficient2_13<=9'sd114;
7'd32:coefficient2_13<=9'sd116;
7'd33:coefficient2_13<=9'sd198;
7'd36:coefficient2_13<=9'sd50;
7'd37:coefficient2_13<=9'sd52;
7'd40:coefficient2_13<=-9'sd134;
7'd41:coefficient2_13<=9'sd62;
7'd64:coefficient2_13<=-9'sd29;
7'd65:coefficient2_13<=-9'sd42;
7'd66:coefficient2_13<=-9'sd36;
7'd67:coefficient2_13<=9'sd73;
default:coefficient2_13<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_13<=0;else if(valid_pipe[2])p3_13<=$signed({{8{a2_13[9]}},a2_13})*$signed({{9{coefficient2_13[8]}},coefficient2_13});end
logic signed [9:0] b1_14,a2_14;logic signed [18:0] p3_14;
always @(posedge clk)begin if(!rst_n)begin b1_14<=0;a2_14<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_14<=((-$signed({2'd0,x0[7]}) + $signed({2'd0,x0[8]})) + ($signed({2'd0,x0[19]}) + -$signed({2'd0,x0[20]})));
if(valid_pipe[1])a2_14<=mode_pipe[1]?$signed({2'd0,f1[14]}):b1_14;
end end
logic signed [9:0] coefficient2_14;
always @(posedge clk)begin if(!rst_n)coefficient2_14<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_14<=10'sd344;
7'd4:coefficient2_14<=-10'sd122;
7'd32:coefficient2_14<=-10'sd148;
7'd33:coefficient2_14<=10'sd42;
7'd36:coefficient2_14<=-10'sd98;
7'd37:coefficient2_14<=10'sd308;
7'd40:coefficient2_14<=-10'sd130;
7'd41:coefficient2_14<=-10'sd206;
7'd64:coefficient2_14<=10'sd32;
7'd65:coefficient2_14<=10'sd63;
7'd66:coefficient2_14<=-10'sd19;
7'd67:coefficient2_14<=10'sd17;
default:coefficient2_14<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_14<=0;else if(valid_pipe[2])p3_14<=$signed({{9{a2_14[9]}},a2_14})*$signed({{9{coefficient2_14[9]}},coefficient2_14});end
logic signed [9:0] b1_15,a2_15;logic signed [18:0] p3_15;
always @(posedge clk)begin if(!rst_n)begin b1_15<=0;a2_15<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_15<=(($signed({2'd0,x0[7]}) + -$signed({2'd0,x0[9]})) + (-$signed({2'd0,x0[19]}) + $signed({2'd0,x0[21]})));
if(valid_pipe[1])a2_15<=mode_pipe[1]?$signed({2'd0,f1[15]}):b1_15;
end end
logic signed [9:0] coefficient2_15;
always @(posedge clk)begin if(!rst_n)coefficient2_15<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_15<=10'sd184;
7'd4:coefficient2_15<=-10'sd44;
7'd32:coefficient2_15<=10'sd188;
7'd33:coefficient2_15<=10'sd16;
7'd36:coefficient2_15<=-10'sd260;
7'd37:coefficient2_15<=10'sd212;
7'd40:coefficient2_15<=-10'sd256;
7'd41:coefficient2_15<=-10'sd144;
7'd64:coefficient2_15<=10'sd5;
7'd65:coefficient2_15<=-10'sd26;
7'd66:coefficient2_15<=10'sd24;
7'd67:coefficient2_15<=-10'sd25;
default:coefficient2_15<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_15<=0;else if(valid_pipe[2])p3_15<=$signed({{9{a2_15[9]}},a2_15})*$signed({{9{coefficient2_15[9]}},coefficient2_15});end
logic signed [9:0] b1_16,a2_16;logic signed [17:0] p3_16;
always @(posedge clk)begin if(!rst_n)begin b1_16<=0;a2_16<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_16<=(($signed({2'd0,x0[3]}) + -$signed({2'd0,x0[4]})) + (-$signed({2'd0,x0[15]}) + $signed({2'd0,x0[16]})));
if(valid_pipe[1])a2_16<=mode_pipe[1]?$signed({2'd0,f1[16]}):b1_16;
end end
logic signed [8:0] coefficient2_16;
always @(posedge clk)begin if(!rst_n)coefficient2_16<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_16<=-9'sd178;
7'd4:coefficient2_16<=-9'sd68;
7'd32:coefficient2_16<=9'sd2;
7'd33:coefficient2_16<=-9'sd22;
7'd36:coefficient2_16<=9'sd48;
7'd37:coefficient2_16<=-9'sd48;
7'd40:coefficient2_16<=-9'sd22;
7'd41:coefficient2_16<=9'sd126;
7'd64:coefficient2_16<=9'sd42;
7'd65:coefficient2_16<=9'sd4;
7'd66:coefficient2_16<=-9'sd16;
7'd67:coefficient2_16<=-9'sd49;
default:coefficient2_16<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_16<=0;else if(valid_pipe[2])p3_16<=$signed({{8{a2_16[9]}},a2_16})*$signed({{9{coefficient2_16[8]}},coefficient2_16});end
logic signed [8:0] b1_17,a2_17;logic signed [17:0] p3_17;
always @(posedge clk)begin if(!rst_n)begin b1_17<=0;a2_17<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_17<=($signed({1'd0,x0[4]}) + -$signed({1'd0,x0[16]}));
if(valid_pipe[1])a2_17<=mode_pipe[1]?$signed({1'd0,f1[17]}):b1_17;
end end
logic signed [9:0] coefficient2_17;
always @(posedge clk)begin if(!rst_n)coefficient2_17<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_17<=-10'sd376;
7'd4:coefficient2_17<=-10'sd246;
7'd32:coefficient2_17<=-10'sd142;
7'd33:coefficient2_17<=-10'sd74;
7'd36:coefficient2_17<=10'sd80;
7'd37:coefficient2_17<=-10'sd6;
7'd40:coefficient2_17<=-10'sd6;
7'd41:coefficient2_17<=10'sd84;
7'd64:coefficient2_17<=-10'sd33;
7'd65:coefficient2_17<=10'sd62;
7'd66:coefficient2_17<=-10'sd73;
7'd67:coefficient2_17<=10'sd7;
default:coefficient2_17<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_17<=0;else if(valid_pipe[2])p3_17<=$signed({{9{a2_17[8]}},a2_17})*$signed({{8{coefficient2_17[9]}},coefficient2_17});end
logic signed [9:0] b1_18,a2_18;logic signed [17:0] p3_18;
always @(posedge clk)begin if(!rst_n)begin b1_18<=0;a2_18<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_18<=((-$signed({2'd0,x0[4]}) + $signed({2'd0,x0[5]})) + ($signed({2'd0,x0[16]}) + -$signed({2'd0,x0[17]})));
if(valid_pipe[1])a2_18<=mode_pipe[1]?$signed({2'd0,f1[18]}):b1_18;
end end
logic signed [8:0] coefficient2_18;
always @(posedge clk)begin if(!rst_n)coefficient2_18<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_18<=-9'sd198;
7'd4:coefficient2_18<=-9'sd178;
7'd32:coefficient2_18<=-9'sd144;
7'd33:coefficient2_18<=-9'sd52;
7'd36:coefficient2_18<=9'sd32;
7'd37:coefficient2_18<=9'sd42;
7'd40:coefficient2_18<=9'sd16;
7'd41:coefficient2_18<=-9'sd42;
7'd64:coefficient2_18<=-9'sd67;
7'd65:coefficient2_18<=-9'sd8;
7'd66:coefficient2_18<=-9'sd53;
7'd67:coefficient2_18<=9'sd47;
default:coefficient2_18<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_18<=0;else if(valid_pipe[2])p3_18<=$signed({{8{a2_18[9]}},a2_18})*$signed({{9{coefficient2_18[8]}},coefficient2_18});end
logic signed [9:0] b1_19,a2_19;logic signed [17:0] p3_19;
always @(posedge clk)begin if(!rst_n)begin b1_19<=0;a2_19<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_19<=(($signed({2'd0,x0[9]}) + -$signed({2'd0,x0[10]})) + ($signed({2'd0,x0[15]}) + -$signed({2'd0,x0[16]})));
if(valid_pipe[1])a2_19<=mode_pipe[1]?$signed({2'd0,f1[19]}):b1_19;
end end
logic signed [8:0] coefficient2_19;
always @(posedge clk)begin if(!rst_n)coefficient2_19<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_19<=-9'sd19;
7'd4:coefficient2_19<=-9'sd43;
7'd32:coefficient2_19<=9'sd19;
7'd33:coefficient2_19<=-9'sd141;
7'd36:coefficient2_19<=9'sd53;
7'd37:coefficient2_19<=-9'sd45;
7'd40:coefficient2_19<=-9'sd20;
7'd41:coefficient2_19<=9'sd49;
7'd64:coefficient2_19<=-9'sd49;
7'd65:coefficient2_19<=-9'sd64;
7'd66:coefficient2_19<=-9'sd23;
7'd67:coefficient2_19<=-9'sd65;
default:coefficient2_19<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_19<=0;else if(valid_pipe[2])p3_19<=$signed({{8{a2_19[9]}},a2_19})*$signed({{9{coefficient2_19[8]}},coefficient2_19});end
logic signed [9:0] b1_20,a2_20;logic signed [17:0] p3_20;
always @(posedge clk)begin if(!rst_n)begin b1_20<=0;a2_20<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_20<=($signed({2'd0,x0[10]}) + $signed({2'd0,x0[16]}));
if(valid_pipe[1])a2_20<=mode_pipe[1]?$signed({2'd0,f1[20]}):b1_20;
end end
logic signed [8:0] coefficient2_20;
always @(posedge clk)begin if(!rst_n)coefficient2_20<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_20<=-9'sd232;
7'd4:coefficient2_20<=-9'sd236;
7'd32:coefficient2_20<=-9'sd67;
7'd33:coefficient2_20<=-9'sd137;
7'd36:coefficient2_20<=9'sd151;
7'd37:coefficient2_20<=-9'sd39;
7'd40:coefficient2_20<=-9'sd32;
7'd41:coefficient2_20<=-9'sd18;
7'd64:coefficient2_20<=-9'sd64;
7'd65:coefficient2_20<=9'sd20;
7'd66:coefficient2_20<=9'sd21;
7'd67:coefficient2_20<=9'sd50;
default:coefficient2_20<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_20<=0;else if(valid_pipe[2])p3_20<=$signed({{8{a2_20[9]}},a2_20})*$signed({{9{coefficient2_20[8]}},coefficient2_20});end
logic signed [9:0] b1_21,a2_21;logic signed [17:0] p3_21;
always @(posedge clk)begin if(!rst_n)begin b1_21<=0;a2_21<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_21<=((-$signed({2'd0,x0[10]}) + $signed({2'd0,x0[11]})) + (-$signed({2'd0,x0[16]}) + $signed({2'd0,x0[17]})));
if(valid_pipe[1])a2_21<=mode_pipe[1]?$signed({2'd0,f1[21]}):b1_21;
end end
logic signed [8:0] coefficient2_21;
always @(posedge clk)begin if(!rst_n)coefficient2_21<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_21<=-9'sd213;
7'd4:coefficient2_21<=-9'sd193;
7'd32:coefficient2_21<=-9'sd86;
7'd33:coefficient2_21<=9'sd4;
7'd36:coefficient2_21<=9'sd98;
7'd37:coefficient2_21<=9'sd6;
7'd40:coefficient2_21<=-9'sd12;
7'd41:coefficient2_21<=-9'sd67;
7'd64:coefficient2_21<=9'sd10;
7'd66:coefficient2_21<=-9'sd25;
7'd67:coefficient2_21<=9'sd55;
default:coefficient2_21<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_21<=0;else if(valid_pipe[2])p3_21<=$signed({{8{a2_21[9]}},a2_21})*$signed({{9{coefficient2_21[8]}},coefficient2_21});end
logic signed [9:0] b1_22,a2_22;logic signed [17:0] p3_22;
always @(posedge clk)begin if(!rst_n)begin b1_22<=0;a2_22<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_22<=((-$signed({2'd0,x0[9]}) + $signed({2'd0,x0[10]})) + ($signed({2'd0,x0[15]}) + -$signed({2'd0,x0[16]})));
if(valid_pipe[1])a2_22<=mode_pipe[1]?$signed({2'd0,f1[22]}):b1_22;
end end
logic signed [8:0] coefficient2_22;
always @(posedge clk)begin if(!rst_n)coefficient2_22<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_22<=-9'sd101;
7'd4:coefficient2_22<=-9'sd73;
7'd32:coefficient2_22<=-9'sd51;
7'd33:coefficient2_22<=-9'sd23;
7'd36:coefficient2_22<=-9'sd65;
7'd37:coefficient2_22<=-9'sd43;
7'd40:coefficient2_22<=9'sd20;
7'd41:coefficient2_22<=9'sd153;
7'd64:coefficient2_22<=9'sd7;
7'd65:coefficient2_22<=9'sd68;
7'd66:coefficient2_22<=9'sd61;
7'd67:coefficient2_22<=9'sd40;
default:coefficient2_22<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_22<=0;else if(valid_pipe[2])p3_22<=$signed({{8{a2_22[9]}},a2_22})*$signed({{9{coefficient2_22[8]}},coefficient2_22});end
logic signed [8:0] b1_23,a2_23;logic signed [16:0] p3_23;
always @(posedge clk)begin if(!rst_n)begin b1_23<=0;a2_23<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_23<=(-$signed({1'd0,x0[10]}) + $signed({1'd0,x0[16]}));
if(valid_pipe[1])a2_23<=mode_pipe[1]?$signed({1'd0,f1[23]}):b1_23;
end end
logic signed [8:0] coefficient2_23;
always @(posedge clk)begin if(!rst_n)coefficient2_23<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_23<=-9'sd128;
7'd4:coefficient2_23<=-9'sd106;
7'd32:coefficient2_23<=-9'sd197;
7'd33:coefficient2_23<=-9'sd131;
7'd36:coefficient2_23<=-9'sd109;
7'd37:coefficient2_23<=9'sd43;
7'd40:coefficient2_23<=9'sd44;
7'd41:coefficient2_23<=9'sd144;
7'd64:coefficient2_23<=-9'sd51;
7'd65:coefficient2_23<=-9'sd25;
7'd66:coefficient2_23<=9'sd58;
7'd67:coefficient2_23<=-9'sd33;
default:coefficient2_23<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_23<=0;else if(valid_pipe[2])p3_23<=$signed({{8{a2_23[8]}},a2_23})*$signed({{8{coefficient2_23[8]}},coefficient2_23});end
logic signed [9:0] b1_24,a2_24;logic signed [17:0] p3_24;
always @(posedge clk)begin if(!rst_n)begin b1_24<=0;a2_24<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_24<=(($signed({2'd0,x0[10]}) + -$signed({2'd0,x0[11]})) + (-$signed({2'd0,x0[16]}) + $signed({2'd0,x0[17]})));
if(valid_pipe[1])a2_24<=mode_pipe[1]?$signed({2'd0,f1[24]}):b1_24;
end end
logic signed [8:0] coefficient2_24;
always @(posedge clk)begin if(!rst_n)coefficient2_24<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_24<=-9'sd27;
7'd4:coefficient2_24<=-9'sd33;
7'd32:coefficient2_24<=-9'sd146;
7'd33:coefficient2_24<=-9'sd108;
7'd36:coefficient2_24<=-9'sd44;
7'd37:coefficient2_24<=9'sd86;
7'd40:coefficient2_24<=9'sd24;
7'd41:coefficient2_24<=-9'sd9;
7'd64:coefficient2_24<=9'sd55;
7'd65:coefficient2_24<=-9'sd19;
7'd66:coefficient2_24<=9'sd32;
7'd67:coefficient2_24<=9'sd55;
default:coefficient2_24<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_24<=0;else if(valid_pipe[2])p3_24<=$signed({{8{a2_24[9]}},a2_24})*$signed({{9{coefficient2_24[8]}},coefficient2_24});end
logic signed [9:0] b1_25,a2_25;logic signed [17:0] p3_25;
always @(posedge clk)begin if(!rst_n)begin b1_25<=0;a2_25<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_25<=(($signed({2'd0,x0[9]}) + -$signed({2'd0,x0[10]})) + (-$signed({2'd0,x0[21]}) + $signed({2'd0,x0[22]})));
if(valid_pipe[1])a2_25<=mode_pipe[1]?$signed({2'd0,f1[25]}):b1_25;
end end
logic signed [8:0] coefficient2_25;
always @(posedge clk)begin if(!rst_n)coefficient2_25<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_25<=9'sd58;
7'd4:coefficient2_25<=-9'sd48;
7'd32:coefficient2_25<=-9'sd34;
7'd33:coefficient2_25<=-9'sd142;
7'd36:coefficient2_25<=-9'sd60;
7'd37:coefficient2_25<=-9'sd40;
7'd40:coefficient2_25<=9'sd22;
7'd41:coefficient2_25<=9'sd76;
7'd64:coefficient2_25<=-9'sd28;
7'd65:coefficient2_25<=-9'sd10;
7'd66:coefficient2_25<=-9'sd61;
7'd67:coefficient2_25<=9'sd30;
default:coefficient2_25<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_25<=0;else if(valid_pipe[2])p3_25<=$signed({{8{a2_25[9]}},a2_25})*$signed({{9{coefficient2_25[8]}},coefficient2_25});end
logic signed [8:0] b1_26,a2_26;logic signed [16:0] p3_26;
always @(posedge clk)begin if(!rst_n)begin b1_26<=0;a2_26<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_26<=($signed({1'd0,x0[10]}) + -$signed({1'd0,x0[22]}));
if(valid_pipe[1])a2_26<=mode_pipe[1]?$signed({1'd0,f1[26]}):b1_26;
end end
logic signed [8:0] coefficient2_26;
always @(posedge clk)begin if(!rst_n)coefficient2_26<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_26<=9'sd16;
7'd4:coefficient2_26<=-9'sd96;
7'd32:coefficient2_26<=-9'sd122;
7'd33:coefficient2_26<=-9'sd194;
7'd36:coefficient2_26<=-9'sd38;
7'd37:coefficient2_26<=9'sd10;
7'd40:coefficient2_26<=9'sd18;
7'd41:coefficient2_26<=9'sd42;
7'd64:coefficient2_26<=9'sd8;
7'd65:coefficient2_26<=9'sd3;
7'd66:coefficient2_26<=9'sd39;
7'd67:coefficient2_26<=9'sd32;
default:coefficient2_26<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_26<=0;else if(valid_pipe[2])p3_26<=$signed({{8{a2_26[8]}},a2_26})*$signed({{8{coefficient2_26[8]}},coefficient2_26});end
logic signed [9:0] b1_27,a2_27;logic signed [16:0] p3_27;
always @(posedge clk)begin if(!rst_n)begin b1_27<=0;a2_27<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_27<=((-$signed({2'd0,x0[10]}) + $signed({2'd0,x0[11]})) + ($signed({2'd0,x0[22]}) + -$signed({2'd0,x0[23]})));
if(valid_pipe[1])a2_27<=mode_pipe[1]?$signed({2'd0,f1[27]}):b1_27;
end end
logic signed [7:0] coefficient2_27;
always @(posedge clk)begin if(!rst_n)coefficient2_27<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_27<=-8'sd42;
7'd4:coefficient2_27<=-8'sd48;
7'd32:coefficient2_27<=-8'sd88;
7'd33:coefficient2_27<=-8'sd52;
7'd36:coefficient2_27<=8'sd22;
7'd37:coefficient2_27<=8'sd50;
7'd40:coefficient2_27<=-8'sd4;
7'd41:coefficient2_27<=-8'sd34;
7'd64:coefficient2_27<=8'sd13;
7'd65:coefficient2_27<=-8'sd12;
7'd66:coefficient2_27<=8'sd51;
7'd67:coefficient2_27<=8'sd32;
default:coefficient2_27<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_27<=0;else if(valid_pipe[2])p3_27<=$signed({{7{a2_27[9]}},a2_27})*$signed({{9{coefficient2_27[7]}},coefficient2_27});end
logic signed [9:0] b1_28,a2_28;logic signed [17:0] p3_28;
always @(posedge clk)begin if(!rst_n)begin b1_28<=0;a2_28<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_28<=(($signed({2'd0,x0[18]}) + -$signed({2'd0,x0[20]})) + (-$signed({2'd0,x0[24]}) + $signed({2'd0,x0[26]})));
if(valid_pipe[1])a2_28<=mode_pipe[1]?$signed({2'd0,f1[28]}):b1_28;
end end
logic signed [8:0] coefficient2_28;
always @(posedge clk)begin if(!rst_n)coefficient2_28<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_28<=-9'sd66;
7'd4:coefficient2_28<=9'sd136;
7'd32:coefficient2_28<=9'sd14;
7'd33:coefficient2_28<=9'sd108;
7'd36:coefficient2_28<=-9'sd144;
7'd37:coefficient2_28<=9'sd62;
7'd40:coefficient2_28<=9'sd90;
7'd41:coefficient2_28<=-9'sd10;
7'd64:coefficient2_28<=-9'sd17;
7'd65:coefficient2_28<=9'sd17;
7'd66:coefficient2_28<=9'sd63;
7'd67:coefficient2_28<=9'sd52;
default:coefficient2_28<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_28<=0;else if(valid_pipe[2])p3_28<=$signed({{8{a2_28[9]}},a2_28})*$signed({{9{coefficient2_28[8]}},coefficient2_28});end
logic signed [9:0] b1_29,a2_29;logic signed [16:0] p3_29;
always @(posedge clk)begin if(!rst_n)begin b1_29<=0;a2_29<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_29<=(($signed({2'd0,x0[19]}) + $signed({2'd0,x0[20]})) + (-$signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})));
if(valid_pipe[1])a2_29<=mode_pipe[1]?$signed({2'd0,f1[29]}):b1_29;
end end
logic signed [7:0] coefficient2_29;
always @(posedge clk)begin if(!rst_n)coefficient2_29<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_29<=8'sd91;
7'd4:coefficient2_29<=8'sd8;
7'd32:coefficient2_29<=-8'sd49;
7'd33:coefficient2_29<=8'sd41;
7'd36:coefficient2_29<=-8'sd40;
7'd37:coefficient2_29<=-8'sd34;
7'd40:coefficient2_29<=8'sd94;
7'd41:coefficient2_29<=8'sd33;
7'd64:coefficient2_29<=8'sd57;
7'd65:coefficient2_29<=-8'sd30;
7'd66:coefficient2_29<=8'sd8;
7'd67:coefficient2_29<=-8'sd7;
default:coefficient2_29<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_29<=0;else if(valid_pipe[2])p3_29<=$signed({{7{a2_29[9]}},a2_29})*$signed({{9{coefficient2_29[7]}},coefficient2_29});end
logic signed [9:0] b1_30,a2_30;logic signed [17:0] p3_30;
always @(posedge clk)begin if(!rst_n)begin b1_30<=0;a2_30<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_30<=((-$signed({2'd0,x0[19]}) + $signed({2'd0,x0[20]})) + ($signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})));
if(valid_pipe[1])a2_30<=mode_pipe[1]?$signed({2'd0,f1[30]}):b1_30;
end end
logic signed [8:0] coefficient2_30;
always @(posedge clk)begin if(!rst_n)coefficient2_30<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_30<=-9'sd77;
7'd4:coefficient2_30<=-9'sd44;
7'd32:coefficient2_30<=-9'sd65;
7'd33:coefficient2_30<=9'sd147;
7'd36:coefficient2_30<=9'sd28;
7'd37:coefficient2_30<=9'sd74;
7'd40:coefficient2_30<=9'sd130;
7'd41:coefficient2_30<=9'sd59;
7'd64:coefficient2_30<=-9'sd22;
7'd65:coefficient2_30<=-9'sd55;
7'd66:coefficient2_30<=9'sd44;
7'd67:coefficient2_30<=-9'sd27;
default:coefficient2_30<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_30<=0;else if(valid_pipe[2])p3_30<=$signed({{8{a2_30[9]}},a2_30})*$signed({{9{coefficient2_30[8]}},coefficient2_30});end
logic signed [9:0] b1_31,a2_31;logic signed [17:0] p3_31;
always @(posedge clk)begin if(!rst_n)begin b1_31<=0;a2_31<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_31<=(($signed({2'd0,x0[19]}) + -$signed({2'd0,x0[21]})) + (-$signed({2'd0,x0[25]}) + $signed({2'd0,x0[27]})));
if(valid_pipe[1])a2_31<=mode_pipe[1]?$signed({2'd0,f1[31]}):b1_31;
end end
logic signed [8:0] coefficient2_31;
always @(posedge clk)begin if(!rst_n)coefficient2_31<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_31<=9'sd80;
7'd4:coefficient2_31<=-9'sd172;
7'd32:coefficient2_31<=-9'sd128;
7'd33:coefficient2_31<=9'sd80;
7'd36:coefficient2_31<=9'sd132;
7'd37:coefficient2_31<=-9'sd22;
7'd40:coefficient2_31<=9'sd134;
7'd41:coefficient2_31<=9'sd102;
7'd64:coefficient2_31<=9'sd30;
7'd65:coefficient2_31<=9'sd49;
7'd66:coefficient2_31<=9'sd14;
7'd67:coefficient2_31<=9'sd5;
default:coefficient2_31<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_31<=0;else if(valid_pipe[2])p3_31<=$signed({{8{a2_31[9]}},a2_31})*$signed({{9{coefficient2_31[8]}},coefficient2_31});end
logic signed [8:0] b1_32,a2_32;logic signed [16:0] p3_32;
always @(posedge clk)begin if(!rst_n)begin b1_32<=0;a2_32<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_32<=($signed({1'd0,x0[24]}) + -$signed({1'd0,x0[26]}));
if(valid_pipe[1])a2_32<=mode_pipe[1]?$signed({1'd0,f1[32]}):b1_32;
end end
logic signed [8:0] coefficient2_32;
always @(posedge clk)begin if(!rst_n)coefficient2_32<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_32<=-9'sd94;
7'd4:coefficient2_32<=-9'sd6;
7'd32:coefficient2_32<=-9'sd114;
7'd33:coefficient2_32<=9'sd198;
7'd36:coefficient2_32<=-9'sd158;
7'd37:coefficient2_32<=9'sd44;
7'd40:coefficient2_32<=-9'sd52;
7'd41:coefficient2_32<=-9'sd132;
7'd64:coefficient2_32<=-9'sd48;
7'd65:coefficient2_32<=-9'sd57;
7'd66:coefficient2_32<=-9'sd63;
7'd67:coefficient2_32<=9'sd58;
default:coefficient2_32<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_32<=0;else if(valid_pipe[2])p3_32<=$signed({{8{a2_32[8]}},a2_32})*$signed({{8{coefficient2_32[8]}},coefficient2_32});end
logic signed [9:0] b1_33,a2_33;logic signed [17:0] p3_33;
always @(posedge clk)begin if(!rst_n)begin b1_33<=0;a2_33<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_33<=($signed({2'd0,x0[25]}) + $signed({2'd0,x0[26]}));
if(valid_pipe[1])a2_33<=mode_pipe[1]?$signed({2'd0,f1[33]}):b1_33;
end end
logic signed [8:0] coefficient2_33;
always @(posedge clk)begin if(!rst_n)coefficient2_33<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_33<=9'sd176;
7'd4:coefficient2_33<=9'sd28;
7'd32:coefficient2_33<=-9'sd192;
7'd33:coefficient2_33<=9'sd139;
7'd36:coefficient2_33<=9'sd56;
7'd37:coefficient2_33<=-9'sd23;
7'd40:coefficient2_33<=-9'sd47;
7'd41:coefficient2_33<=9'sd109;
7'd64:coefficient2_33<=9'sd74;
7'd65:coefficient2_33<=-9'sd18;
7'd66:coefficient2_33<=9'sd15;
7'd67:coefficient2_33<=9'sd10;
default:coefficient2_33<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_33<=0;else if(valid_pipe[2])p3_33<=$signed({{8{a2_33[9]}},a2_33})*$signed({{9{coefficient2_33[8]}},coefficient2_33});end
logic signed [8:0] b1_34,a2_34;logic signed [16:0] p3_34;
always @(posedge clk)begin if(!rst_n)begin b1_34<=0;a2_34<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_34<=(-$signed({1'd0,x0[25]}) + $signed({1'd0,x0[26]}));
if(valid_pipe[1])a2_34<=mode_pipe[1]?$signed({1'd0,f1[34]}):b1_34;
end end
logic signed [8:0] coefficient2_34;
always @(posedge clk)begin if(!rst_n)coefficient2_34<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_34<=-9'sd104;
7'd4:coefficient2_34<=-9'sd58;
7'd32:coefficient2_34<=-9'sd176;
7'd33:coefficient2_34<=9'sd169;
7'd36:coefficient2_34<=9'sd56;
7'd37:coefficient2_34<=-9'sd17;
7'd40:coefficient2_34<=9'sd131;
7'd41:coefficient2_34<=-9'sd7;
7'd64:coefficient2_34<=9'sd22;
7'd65:coefficient2_34<=9'sd49;
7'd66:coefficient2_34<=-9'sd41;
7'd67:coefficient2_34<=9'sd69;
default:coefficient2_34<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_34<=0;else if(valid_pipe[2])p3_34<=$signed({{8{a2_34[8]}},a2_34})*$signed({{8{coefficient2_34[8]}},coefficient2_34});end
logic signed [8:0] b1_35,a2_35;logic signed [17:0] p3_35;
always @(posedge clk)begin if(!rst_n)begin b1_35<=0;a2_35<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_35<=($signed({1'd0,x0[25]}) + -$signed({1'd0,x0[27]}));
if(valid_pipe[1])a2_35<=mode_pipe[1]?$signed({1'd0,f1[35]}):b1_35;
end end
logic signed [9:0] coefficient2_35;
always @(posedge clk)begin if(!rst_n)coefficient2_35<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_35<=10'sd166;
7'd4:coefficient2_35<=-10'sd24;
7'd32:coefficient2_35<=-10'sd254;
7'd33:coefficient2_35<=10'sd110;
7'd36:coefficient2_35<=10'sd270;
7'd37:coefficient2_35<=-10'sd84;
7'd40:coefficient2_35<=10'sd136;
7'd41:coefficient2_35<=10'sd234;
7'd64:coefficient2_35<=-10'sd17;
7'd65:coefficient2_35<=-10'sd51;
7'd66:coefficient2_35<=10'sd69;
7'd67:coefficient2_35<=-10'sd7;
default:coefficient2_35<=10'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_35<=0;else if(valid_pipe[2])p3_35<=$signed({{9{a2_35[8]}},a2_35})*$signed({{8{coefficient2_35[9]}},coefficient2_35});end
logic signed [9:0] b1_36,a2_36;logic signed [17:0] p3_36;
always @(posedge clk)begin if(!rst_n)begin b1_36<=0;a2_36<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_36<=((-$signed({2'd0,x0[24]}) + $signed({2'd0,x0[26]})) + ($signed({2'd0,x0[30]}) + -$signed({2'd0,x0[32]})));
if(valid_pipe[1])a2_36<=mode_pipe[1]?$signed({2'd0,f1[36]}):b1_36;
end end
logic signed [8:0] coefficient2_36;
always @(posedge clk)begin if(!rst_n)coefficient2_36<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_36<=-9'sd28;
7'd4:coefficient2_36<=-9'sd142;
7'd32:coefficient2_36<=-9'sd128;
7'd33:coefficient2_36<=9'sd90;
7'd36:coefficient2_36<=-9'sd14;
7'd37:coefficient2_36<=-9'sd18;
7'd40:coefficient2_36<=-9'sd142;
7'd41:coefficient2_36<=-9'sd122;
7'd64:coefficient2_36<=-9'sd38;
7'd65:coefficient2_36<=-9'sd19;
7'd66:coefficient2_36<=-9'sd45;
7'd67:coefficient2_36<=-9'sd21;
default:coefficient2_36<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_36<=0;else if(valid_pipe[2])p3_36<=$signed({{8{a2_36[9]}},a2_36})*$signed({{9{coefficient2_36[8]}},coefficient2_36});end
logic signed [9:0] b1_37,a2_37;logic signed [17:0] p3_37;
always @(posedge clk)begin if(!rst_n)begin b1_37<=0;a2_37<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_37<=((-$signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})) + ($signed({2'd0,x0[31]}) + $signed({2'd0,x0[32]})));
if(valid_pipe[1])a2_37<=mode_pipe[1]?$signed({2'd0,f1[37]}):b1_37;
end end
logic signed [8:0] coefficient2_37;
always @(posedge clk)begin if(!rst_n)coefficient2_37<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_37<=9'sd85;
7'd4:coefficient2_37<=9'sd20;
7'd32:coefficient2_37<=-9'sd143;
7'd33:coefficient2_37<=9'sd98;
7'd36:coefficient2_37<=9'sd96;
7'd37:coefficient2_37<=9'sd11;
7'd40:coefficient2_37<=-9'sd141;
7'd41:coefficient2_37<=9'sd76;
7'd64:coefficient2_37<=-9'sd26;
7'd65:coefficient2_37<=9'sd7;
7'd66:coefficient2_37<=9'sd67;
7'd67:coefficient2_37<=-9'sd8;
default:coefficient2_37<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_37<=0;else if(valid_pipe[2])p3_37<=$signed({{8{a2_37[9]}},a2_37})*$signed({{9{coefficient2_37[8]}},coefficient2_37});end
logic signed [9:0] b1_38,a2_38;logic signed [16:0] p3_38;
always @(posedge clk)begin if(!rst_n)begin b1_38<=0;a2_38<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_38<=(($signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})) + (-$signed({2'd0,x0[31]}) + $signed({2'd0,x0[32]})));
if(valid_pipe[1])a2_38<=mode_pipe[1]?$signed({2'd0,f1[38]}):b1_38;
end end
logic signed [7:0] coefficient2_38;
always @(posedge clk)begin if(!rst_n)coefficient2_38<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_38<=-8'sd27;
7'd4:coefficient2_38<=-8'sd14;
7'd32:coefficient2_38<=-8'sd111;
7'd33:coefficient2_38<=8'sd22;
7'd36:coefficient2_38<=8'sd28;
7'd37:coefficient2_38<=-8'sd91;
7'd40:coefficient2_38<=8'sd1;
7'd41:coefficient2_38<=-8'sd66;
7'd64:coefficient2_38<=-8'sd50;
7'd65:coefficient2_38<=8'sd46;
7'd66:coefficient2_38<=-8'sd35;
7'd67:coefficient2_38<=8'sd17;
default:coefficient2_38<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_38<=0;else if(valid_pipe[2])p3_38<=$signed({{7{a2_38[9]}},a2_38})*$signed({{9{coefficient2_38[7]}},coefficient2_38});end
logic signed [9:0] b1_39,a2_39;logic signed [17:0] p3_39;
always @(posedge clk)begin if(!rst_n)begin b1_39<=0;a2_39<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_39<=((-$signed({2'd0,x0[25]}) + $signed({2'd0,x0[27]})) + ($signed({2'd0,x0[31]}) + -$signed({2'd0,x0[33]})));
if(valid_pipe[1])a2_39<=mode_pipe[1]?$signed({2'd0,f1[39]}):b1_39;
end end
logic signed [8:0] coefficient2_39;
always @(posedge clk)begin if(!rst_n)coefficient2_39<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_39<=9'sd86;
7'd4:coefficient2_39<=9'sd148;
7'd32:coefficient2_39<=-9'sd126;
7'd33:coefficient2_39<=9'sd30;
7'd36:coefficient2_39<=9'sd138;
7'd37:coefficient2_39<=-9'sd62;
7'd40:coefficient2_39<=9'sd2;
7'd41:coefficient2_39<=9'sd132;
7'd64:coefficient2_39<=-9'sd61;
7'd65:coefficient2_39<=9'sd45;
7'd66:coefficient2_39<=9'sd41;
7'd67:coefficient2_39<=-9'sd37;
default:coefficient2_39<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_39<=0;else if(valid_pipe[2])p3_39<=$signed({{8{a2_39[9]}},a2_39})*$signed({{9{coefficient2_39[8]}},coefficient2_39});end
logic signed [9:0] b1_40,a2_40;logic signed [15:0] p3_40;
always @(posedge clk)begin if(!rst_n)begin b1_40<=0;a2_40<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_40<=(($signed({2'd0,x0[21]}) + -$signed({2'd0,x0[22]})) + (-$signed({2'd0,x0[27]}) + $signed({2'd0,x0[28]})));
if(valid_pipe[1])a2_40<=mode_pipe[1]?$signed({2'd0,f1[40]}):b1_40;
end end
logic signed [6:0] coefficient2_40;
always @(posedge clk)begin if(!rst_n)coefficient2_40<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_40<=7'sd1;
7'd4:coefficient2_40<=-7'sd20;
7'd32:coefficient2_40<=7'sd57;
7'd33:coefficient2_40<=-7'sd31;
7'd36:coefficient2_40<=-7'sd9;
7'd37:coefficient2_40<=-7'sd7;
7'd40:coefficient2_40<=7'sd12;
7'd41:coefficient2_40<=7'sd41;
7'd64:coefficient2_40<=-7'sd14;
7'd65:coefficient2_40<=7'sd42;
7'd66:coefficient2_40<=7'sd56;
7'd67:coefficient2_40<=-7'sd25;
default:coefficient2_40<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_40<=0;else if(valid_pipe[2])p3_40<=$signed({{6{a2_40[9]}},a2_40})*$signed({{9{coefficient2_40[6]}},coefficient2_40});end
logic signed [8:0] b1_41,a2_41;logic signed [15:0] p3_41;
always @(posedge clk)begin if(!rst_n)begin b1_41<=0;a2_41<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_41<=($signed({1'd0,x0[22]}) + -$signed({1'd0,x0[28]}));
if(valid_pipe[1])a2_41<=mode_pipe[1]?$signed({1'd0,f1[41]}):b1_41;
end end
logic signed [7:0] coefficient2_41;
always @(posedge clk)begin if(!rst_n)coefficient2_41<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_41<=8'sd90;
7'd4:coefficient2_41<=-8'sd47;
7'd32:coefficient2_41<=8'sd61;
7'd33:coefficient2_41<=-8'sd101;
7'd36:coefficient2_41<=-8'sd28;
7'd37:coefficient2_41<=-8'sd40;
7'd40:coefficient2_41<=8'sd58;
7'd41:coefficient2_41<=8'sd87;
7'd64:coefficient2_41<=8'sd32;
7'd65:coefficient2_41<=8'sd47;
7'd66:coefficient2_41<=8'sd40;
7'd67:coefficient2_41<=8'sd38;
default:coefficient2_41<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_41<=0;else if(valid_pipe[2])p3_41<=$signed({{7{a2_41[8]}},a2_41})*$signed({{8{coefficient2_41[7]}},coefficient2_41});end
logic signed [9:0] b1_42,a2_42;logic signed [16:0] p3_42;
always @(posedge clk)begin if(!rst_n)begin b1_42<=0;a2_42<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_42<=((-$signed({2'd0,x0[22]}) + $signed({2'd0,x0[23]})) + ($signed({2'd0,x0[28]}) + -$signed({2'd0,x0[29]})));
if(valid_pipe[1])a2_42<=mode_pipe[1]?$signed({2'd0,f1[42]}):b1_42;
end end
logic signed [7:0] coefficient2_42;
always @(posedge clk)begin if(!rst_n)coefficient2_42<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_42<=8'sd89;
7'd4:coefficient2_42<=-8'sd27;
7'd32:coefficient2_42<=8'sd4;
7'd33:coefficient2_42<=-8'sd70;
7'd36:coefficient2_42<=-8'sd19;
7'd37:coefficient2_42<=-8'sd33;
7'd40:coefficient2_42<=8'sd46;
7'd41:coefficient2_42<=8'sd46;
7'd64:coefficient2_42<=8'sd72;
7'd65:coefficient2_42<=8'sd61;
7'd66:coefficient2_42<=8'sd5;
7'd67:coefficient2_42<=-8'sd27;
default:coefficient2_42<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_42<=0;else if(valid_pipe[2])p3_42<=$signed({{7{a2_42[9]}},a2_42})*$signed({{9{coefficient2_42[7]}},coefficient2_42});end
logic signed [8:0] b1_43,a2_43;logic signed [15:0] p3_43;
always @(posedge clk)begin if(!rst_n)begin b1_43<=0;a2_43<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_43<=($signed({1'd0,x0[27]}) + -$signed({1'd0,x0[28]}));
if(valid_pipe[1])a2_43<=mode_pipe[1]?$signed({1'd0,f1[43]}):b1_43;
end end
logic signed [7:0] coefficient2_43;
always @(posedge clk)begin if(!rst_n)coefficient2_43<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_43<=8'sd8;
7'd4:coefficient2_43<=-8'sd41;
7'd32:coefficient2_43<=8'sd62;
7'd33:coefficient2_43<=-8'sd17;
7'd36:coefficient2_43<=8'sd17;
7'd37:coefficient2_43<=-8'sd11;
7'd40:coefficient2_43<=8'sd24;
7'd41:coefficient2_43<=8'sd94;
7'd64:coefficient2_43<=-8'sd70;
7'd65:coefficient2_43<=8'sd67;
7'd66:coefficient2_43<=-8'sd43;
7'd67:coefficient2_43<=8'sd42;
default:coefficient2_43<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_43<=0;else if(valid_pipe[2])p3_43<=$signed({{7{a2_43[8]}},a2_43})*$signed({{8{coefficient2_43[7]}},coefficient2_43});end
logic signed [8:0] b1_44,a2_44;logic signed [16:0] p3_44;
always @(posedge clk)begin if(!rst_n)begin b1_44<=0;a2_44<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_44<=$signed({1'd0,x0[28]});
if(valid_pipe[1])a2_44<=mode_pipe[1]?$signed({1'd0,f1[44]}):b1_44;
end end
logic signed [8:0] coefficient2_44;
always @(posedge clk)begin if(!rst_n)coefficient2_44<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_44<=9'sd152;
7'd4:coefficient2_44<=-9'sd11;
7'd32:coefficient2_44<=9'sd63;
7'd33:coefficient2_44<=-9'sd150;
7'd36:coefficient2_44<=-9'sd16;
7'd37:coefficient2_44<=9'sd11;
7'd40:coefficient2_44<=9'sd44;
7'd41:coefficient2_44<=9'sd101;
7'd64:coefficient2_44<=9'sd21;
7'd65:coefficient2_44<=-9'sd5;
7'd66:coefficient2_44<=9'sd38;
7'd67:coefficient2_44<=9'sd3;
default:coefficient2_44<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_44<=0;else if(valid_pipe[2])p3_44<=$signed({{8{a2_44[8]}},a2_44})*$signed({{8{coefficient2_44[8]}},coefficient2_44});end
logic signed [8:0] b1_45,a2_45;logic signed [16:0] p3_45;
always @(posedge clk)begin if(!rst_n)begin b1_45<=0;a2_45<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_45<=(-$signed({1'd0,x0[28]}) + $signed({1'd0,x0[29]}));
if(valid_pipe[1])a2_45<=mode_pipe[1]?$signed({1'd0,f1[45]}):b1_45;
end end
logic signed [8:0] coefficient2_45;
always @(posedge clk)begin if(!rst_n)coefficient2_45<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_45<=9'sd144;
7'd4:coefficient2_45<=9'sd30;
7'd32:coefficient2_45<=9'sd1;
7'd33:coefficient2_45<=-9'sd133;
7'd36:coefficient2_45<=-9'sd33;
7'd37:coefficient2_45<=9'sd22;
7'd40:coefficient2_45<=9'sd20;
7'd41:coefficient2_45<=9'sd7;
7'd64:coefficient2_45<=9'sd22;
7'd65:coefficient2_45<=-9'sd1;
7'd66:coefficient2_45<=9'sd2;
7'd67:coefficient2_45<=-9'sd49;
default:coefficient2_45<=9'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_45<=0;else if(valid_pipe[2])p3_45<=$signed({{8{a2_45[8]}},a2_45})*$signed({{8{coefficient2_45[8]}},coefficient2_45});end
logic signed [9:0] b1_46,a2_46;logic signed [15:0] p3_46;
always @(posedge clk)begin if(!rst_n)begin b1_46<=0;a2_46<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_46<=((-$signed({2'd0,x0[27]}) + $signed({2'd0,x0[28]})) + ($signed({2'd0,x0[33]}) + -$signed({2'd0,x0[34]})));
if(valid_pipe[1])a2_46<=mode_pipe[1]?$signed({2'd0,f1[46]}):b1_46;
end end
logic signed [6:0] coefficient2_46;
always @(posedge clk)begin if(!rst_n)coefficient2_46<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_46<=7'sd7;
7'd4:coefficient2_46<=-7'sd21;
7'd32:coefficient2_46<=7'sd5;
7'd33:coefficient2_46<=7'sd14;
7'd36:coefficient2_46<=7'sd26;
7'd37:coefficient2_46<=-7'sd4;
7'd40:coefficient2_46<=7'sd12;
7'd41:coefficient2_46<=7'sd53;
7'd64:coefficient2_46<=-7'sd18;
7'd65:coefficient2_46<=7'sd29;
7'd66:coefficient2_46<=-7'sd20;
7'd67:coefficient2_46<=7'sd27;
default:coefficient2_46<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_46<=0;else if(valid_pipe[2])p3_46<=$signed({{6{a2_46[9]}},a2_46})*$signed({{9{coefficient2_46[6]}},coefficient2_46});end
logic signed [8:0] b1_47,a2_47;logic signed [15:0] p3_47;
always @(posedge clk)begin if(!rst_n)begin b1_47<=0;a2_47<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_47<=(-$signed({1'd0,x0[28]}) + $signed({1'd0,x0[34]}));
if(valid_pipe[1])a2_47<=mode_pipe[1]?$signed({1'd0,f1[47]}):b1_47;
end end
logic signed [7:0] coefficient2_47;
always @(posedge clk)begin if(!rst_n)coefficient2_47<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_47<=8'sd62;
7'd4:coefficient2_47<=8'sd36;
7'd32:coefficient2_47<=8'sd2;
7'd33:coefficient2_47<=-8'sd49;
7'd36:coefficient2_47<=8'sd12;
7'd37:coefficient2_47<=8'sd51;
7'd40:coefficient2_47<=-8'sd14;
7'd41:coefficient2_47<=8'sd14;
7'd64:coefficient2_47<=-8'sd54;
7'd65:coefficient2_47<=8'sd17;
7'd66:coefficient2_47<=8'sd53;
7'd67:coefficient2_47<=8'sd70;
default:coefficient2_47<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_47<=0;else if(valid_pipe[2])p3_47<=$signed({{7{a2_47[8]}},a2_47})*$signed({{8{coefficient2_47[7]}},coefficient2_47});end
logic signed [9:0] b1_48,a2_48;logic signed [15:0] p3_48;
always @(posedge clk)begin if(!rst_n)begin b1_48<=0;a2_48<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_48<=(($signed({2'd0,x0[28]}) + -$signed({2'd0,x0[29]})) + (-$signed({2'd0,x0[34]}) + $signed({2'd0,x0[35]})));
if(valid_pipe[1])a2_48<=mode_pipe[1]?0:b1_48;
end end
logic signed [6:0] coefficient2_48;
always @(posedge clk)begin if(!rst_n)coefficient2_48<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_48<=7'sd55;
7'd4:coefficient2_48<=7'sd57;
7'd32:coefficient2_48<=-7'sd3;
7'd33:coefficient2_48<=-7'sd63;
7'd36:coefficient2_48<=-7'sd14;
7'd37:coefficient2_48<=7'sd55;
7'd40:coefficient2_48<=-7'sd26;
7'd41:coefficient2_48<=-7'sd39;
default:coefficient2_48<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_48<=0;else if(valid_pipe[2])p3_48<=$signed({{6{a2_48[9]}},a2_48})*$signed({{9{coefficient2_48[6]}},coefficient2_48});end
logic signed [19:0] h_0_0_0;
logic signed [19:0] h_0_0_1;
logic signed [19:0] h_0_1_0;
logic signed [19:0] h_0_1_1;
logic signed [19:0] h_0_2_0;
logic signed [20:0] h_0_2_1;
logic signed [19:0] h_0_3_0;
logic signed [19:0] h_0_3_1;
logic signed [18:0] h_1_0_0;
logic signed [18:0] h_1_0_1;
logic signed [18:0] h_1_1_0;
logic signed [18:0] h_1_1_1;
logic signed [17:0] h_1_2_0;
logic signed [17:0] h_1_2_1;
logic signed [17:0] h_1_3_0;
logic signed [17:0] h_1_3_1;
logic signed [18:0] h_2_0_0;
logic signed [18:0] h_2_0_1;
logic signed [18:0] h_2_1_0;
logic signed [18:0] h_2_1_1;
logic signed [18:0] h_2_2_0;
logic signed [18:0] h_2_2_1;
logic signed [16:0] h_3_0_0;
logic signed [17:0] h_3_0_1;
logic signed [16:0] h_3_1_0;
logic signed [17:0] h_3_1_1;
logic signed [16:0] h_3_2_0;
logic signed [16:0] h_3_2_1;
logic signed [21:0] z_0_0;
logic signed [21:0] z_0_1;
logic signed [21:0] z_0_2;
logic signed [21:0] z_0_3;
logic signed [19:0] z_1_0;
logic signed [20:0] z_1_1;
logic signed [19:0] z_1_2;
logic signed [19:0] z_1_3;
logic signed [19:0] z_2_0;
logic signed [19:0] z_2_1;
logic signed [19:0] z_2_2;
logic signed [19:0] z_2_3;
logic signed [17:0] z_3_0;
logic signed [18:0] z_3_1;
logic signed [17:0] z_3_2;
logic signed [17:0] z_3_3;
logic signed [15:0] fg4_0;
logic signed [16:0] fg4_1;
logic signed [16:0] fg4_2;
logic signed [16:0] fg4_3;
logic signed [16:0] fg4_4;
logic signed [16:0] fg4_5;
logic signed [16:0] fg4_6;
logic signed [16:0] fg4_7;
logic signed [15:0] fg4_8;
logic signed [16:0] fg4_9;
logic signed [16:0] fg4_10;
logic signed [16:0] fg4_11;
logic signed [15:0] fg4_12;
logic signed [16:0] fg4_13;
logic signed [16:0] fg4_14;
logic signed [15:0] fg4_15;
logic signed [18:0] fg5_0;
logic signed [18:0] fg5_1;
logic signed [18:0] fg5_2;
logic signed [18:0] fg5_3;
always @(posedge clk)begin if(!rst_n)begin
h_0_0_0<=0;
h_0_0_1<=0;
h_0_1_0<=0;
h_0_1_1<=0;
h_0_2_0<=0;
h_0_2_1<=0;
h_0_3_0<=0;
h_0_3_1<=0;
h_1_0_0<=0;
h_1_0_1<=0;
h_1_1_0<=0;
h_1_1_1<=0;
h_1_2_0<=0;
h_1_2_1<=0;
h_1_3_0<=0;
h_1_3_1<=0;
h_2_0_0<=0;
h_2_0_1<=0;
h_2_1_0<=0;
h_2_1_1<=0;
h_2_2_0<=0;
h_2_2_1<=0;
h_3_0_0<=0;
h_3_0_1<=0;
h_3_1_0<=0;
h_3_1_1<=0;
h_3_2_0<=0;
h_3_2_1<=0;
fg4_0<=0;
fg4_1<=0;
fg4_2<=0;
fg4_3<=0;
fg4_4<=0;
fg4_5<=0;
fg4_6<=0;
fg4_7<=0;
fg4_8<=0;
fg4_9<=0;
fg4_10<=0;
fg4_11<=0;
fg4_12<=0;
fg4_13<=0;
fg4_14<=0;
fg4_15<=0;
end else if(valid_pipe[3])begin if(!mode_pipe[3])begin
h_0_0_0<=($signed({{1{p3_0[18]}},p3_0}) + ($signed({{2{p3_1[17]}},p3_1}) + $signed({{1{p3_2[18]}},p3_2})));
h_0_0_1<=($signed({{2{p3_1[17]}},p3_1}) + (-$signed({{1{p3_2[18]}},p3_2}) + -$signed({{2{p3_3[17]}},p3_3})));
h_0_1_0<=($signed({{1{p3_4[18]}},p3_4}) + ($signed({{1{p3_5[18]}},p3_5}) + $signed({{2{p3_6[17]}},p3_6})));
h_0_1_1<=($signed({{1{p3_5[18]}},p3_5}) + (-$signed({{2{p3_6[17]}},p3_6}) + -$signed({{2{p3_7[17]}},p3_7})));
h_0_2_0<=($signed({{1{p3_8[18]}},p3_8}) + ($signed({{2{p3_9[17]}},p3_9}) + $signed({{1{p3_10[18]}},p3_10})));
h_0_2_1<=($signed({{3{p3_9[17]}},p3_9}) + (-$signed({{2{p3_10[18]}},p3_10}) + -$signed({{2{p3_11[18]}},p3_11})));
h_0_3_0<=($signed({{2{p3_12[17]}},p3_12}) + ($signed({{2{p3_13[17]}},p3_13}) + $signed({{1{p3_14[18]}},p3_14})));
h_0_3_1<=($signed({{2{p3_13[17]}},p3_13}) + (-$signed({{1{p3_14[18]}},p3_14}) + -$signed({{1{p3_15[18]}},p3_15})));
h_1_0_0<=($signed({{1{p3_16[17]}},p3_16}) + $signed({{1{p3_17[17]}},p3_17}));
h_1_0_1<=($signed({{1{p3_17[17]}},p3_17}) + $signed({{1{p3_18[17]}},p3_18}));
h_1_1_0<=($signed({{1{p3_19[17]}},p3_19}) + $signed({{1{p3_20[17]}},p3_20}));
h_1_1_1<=($signed({{1{p3_20[17]}},p3_20}) + $signed({{1{p3_21[17]}},p3_21}));
h_1_2_0<=($signed(p3_22) + $signed({{1{p3_23[16]}},p3_23}));
h_1_2_1<=($signed({{1{p3_23[16]}},p3_23}) + $signed(p3_24));
h_1_3_0<=($signed(p3_25) + $signed({{1{p3_26[16]}},p3_26}));
h_1_3_1<=($signed({{1{p3_26[16]}},p3_26}) + $signed({{1{p3_27[16]}},p3_27}));
h_2_0_0<=($signed({{1{p3_28[17]}},p3_28}) + ($signed({{2{p3_29[16]}},p3_29}) + $signed({{1{p3_30[17]}},p3_30})));
h_2_0_1<=($signed({{2{p3_29[16]}},p3_29}) + (-$signed({{1{p3_30[17]}},p3_30}) + -$signed({{1{p3_31[17]}},p3_31})));
h_2_1_0<=($signed({{2{p3_32[16]}},p3_32}) + ($signed({{1{p3_33[17]}},p3_33}) + $signed({{2{p3_34[16]}},p3_34})));
h_2_1_1<=($signed({{1{p3_33[17]}},p3_33}) + (-$signed({{2{p3_34[16]}},p3_34}) + -$signed({{1{p3_35[17]}},p3_35})));
h_2_2_0<=($signed({{1{p3_36[17]}},p3_36}) + ($signed({{1{p3_37[17]}},p3_37}) + $signed({{2{p3_38[16]}},p3_38})));
h_2_2_1<=($signed({{1{p3_37[17]}},p3_37}) + (-$signed({{2{p3_38[16]}},p3_38}) + -$signed({{1{p3_39[17]}},p3_39})));
h_3_0_0<=($signed({{1{p3_40[15]}},p3_40}) + $signed({{1{p3_41[15]}},p3_41}));
h_3_0_1<=($signed({{2{p3_41[15]}},p3_41}) + $signed({{1{p3_42[16]}},p3_42}));
h_3_1_0<=($signed({{1{p3_43[15]}},p3_43}) + $signed(p3_44));
h_3_1_1<=($signed({{1{p3_44[16]}},p3_44}) + $signed({{1{p3_45[16]}},p3_45}));
h_3_2_0<=($signed({{1{p3_46[15]}},p3_46}) + $signed({{1{p3_47[15]}},p3_47}));
h_3_2_1<=($signed({{1{p3_47[15]}},p3_47}) + $signed({{1{p3_48[15]}},p3_48}));
end else begin
fg4_0<=($signed(p3_0[15:0]) + ($signed(p3_1[15:0]) + $signed(p3_2[15:0])));
fg4_1<=($signed(p3_3[16:0]) + ($signed(p3_4[16:0]) + $signed(p3_5[16:0])));
fg4_2<=($signed(p3_6[16:0]) + ($signed(p3_7[16:0]) + $signed(p3_8[16:0])));
fg4_3<=($signed(p3_9[16:0]) + ($signed(p3_10[16:0]) + $signed(p3_11[16:0])));
fg4_4<=($signed(p3_12[16:0]) + ($signed(p3_13[16:0]) + $signed(p3_14[16:0])));
fg4_5<=($signed(p3_15[16:0]) + ($signed(p3_16[16:0]) + $signed(p3_17[16:0])));
fg4_6<=($signed(p3_18[16:0]) + ($signed(p3_19[16:0]) + $signed(p3_20[16:0])));
fg4_7<=($signed(p3_21[16:0]) + ($signed(p3_22[16:0]) + $signed(p3_23)));
fg4_8<=($signed(p3_24[15:0]) + ($signed(p3_25[15:0]) + $signed(p3_26[15:0])));
fg4_9<=($signed(p3_27) + ($signed(p3_28[16:0]) + $signed(p3_29)));
fg4_10<=($signed(p3_30[16:0]) + ($signed(p3_31[16:0]) + $signed(p3_32)));
fg4_11<=($signed(p3_33[16:0]) + ($signed(p3_34) + $signed(p3_35[16:0])));
fg4_12<=($signed(p3_36[15:0]) + ($signed(p3_37[15:0]) + $signed(p3_38[15:0])));
fg4_13<=($signed(p3_39[16:0]) + ($signed({{1{p3_40[15]}},p3_40}) + $signed({{1{p3_41[15]}},p3_41})));
fg4_14<=($signed(p3_42) + ($signed({{1{p3_43[15]}},p3_43}) + $signed(p3_44)));
fg4_15<=($signed(p3_45[15:0]) + ($signed(p3_46) + $signed(p3_47)));
end end end
always @(posedge clk)begin if(!rst_n)begin
z_0_0<=0;
z_0_1<=0;
z_0_2<=0;
z_0_3<=0;
z_1_0<=0;
z_1_1<=0;
z_1_2<=0;
z_1_3<=0;
z_2_0<=0;
z_2_1<=0;
z_2_2<=0;
z_2_3<=0;
z_3_0<=0;
z_3_1<=0;
z_3_2<=0;
z_3_3<=0;
fg5_0<=0;
fg5_1<=0;
fg5_2<=0;
fg5_3<=0;
end else if(valid_pipe[4])begin if(!mode_pipe[4])begin
z_0_0<=($signed({{2{h_0_0_0[19]}},h_0_0_0}) + ($signed({{2{h_0_1_0[19]}},h_0_1_0}) + $signed({{2{h_0_2_0[19]}},h_0_2_0})));
z_0_1<=($signed({{2{h_0_0_1[19]}},h_0_0_1}) + ($signed({{2{h_0_1_1[19]}},h_0_1_1}) + $signed({{1{h_0_2_1[20]}},h_0_2_1})));
z_0_2<=($signed({{2{h_0_1_0[19]}},h_0_1_0}) + (-$signed({{2{h_0_2_0[19]}},h_0_2_0}) + -$signed({{2{h_0_3_0[19]}},h_0_3_0})));
z_0_3<=($signed({{2{h_0_1_1[19]}},h_0_1_1}) + (-$signed({{1{h_0_2_1[20]}},h_0_2_1}) + -$signed({{2{h_0_3_1[19]}},h_0_3_1})));
z_1_0<=($signed({{1{h_1_0_0[18]}},h_1_0_0}) + ($signed({{1{h_1_1_0[18]}},h_1_1_0}) + $signed({{2{h_1_2_0[17]}},h_1_2_0})));
z_1_1<=($signed({{2{h_1_0_1[18]}},h_1_0_1}) + ($signed({{2{h_1_1_1[18]}},h_1_1_1}) + $signed({{3{h_1_2_1[17]}},h_1_2_1})));
z_1_2<=($signed({{1{h_1_1_0[18]}},h_1_1_0}) + (-$signed({{2{h_1_2_0[17]}},h_1_2_0}) + -$signed({{2{h_1_3_0[17]}},h_1_3_0})));
z_1_3<=($signed({{1{h_1_1_1[18]}},h_1_1_1}) + (-$signed({{2{h_1_2_1[17]}},h_1_2_1}) + -$signed({{2{h_1_3_1[17]}},h_1_3_1})));
z_2_0<=($signed({{1{h_2_0_0[18]}},h_2_0_0}) + $signed({{1{h_2_1_0[18]}},h_2_1_0}));
z_2_1<=($signed({{1{h_2_0_1[18]}},h_2_0_1}) + $signed({{1{h_2_1_1[18]}},h_2_1_1}));
z_2_2<=($signed({{1{h_2_1_0[18]}},h_2_1_0}) + $signed({{1{h_2_2_0[18]}},h_2_2_0}));
z_2_3<=($signed({{1{h_2_1_1[18]}},h_2_1_1}) + $signed({{1{h_2_2_1[18]}},h_2_2_1}));
z_3_0<=($signed({{1{h_3_0_0[16]}},h_3_0_0}) + $signed({{1{h_3_1_0[16]}},h_3_1_0}));
z_3_1<=($signed({{1{h_3_0_1[17]}},h_3_0_1}) + $signed({{1{h_3_1_1[17]}},h_3_1_1}));
z_3_2<=($signed({{1{h_3_1_0[16]}},h_3_1_0}) + $signed({{1{h_3_2_0[16]}},h_3_2_0}));
z_3_3<=($signed(h_3_1_1) + $signed({{1{h_3_2_1[16]}},h_3_2_1}));
end else begin
fg5_0<=(($signed({{3{fg4_0[15]}},fg4_0}) + $signed({{2{fg4_1[16]}},fg4_1})) + ($signed({{2{fg4_2[16]}},fg4_2}) + $signed({{2{fg4_3[16]}},fg4_3})));
fg5_1<=(($signed({{2{fg4_4[16]}},fg4_4}) + $signed({{2{fg4_5[16]}},fg4_5})) + ($signed({{2{fg4_6[16]}},fg4_6}) + $signed({{2{fg4_7[16]}},fg4_7})));
fg5_2<=(($signed({{3{fg4_8[15]}},fg4_8}) + $signed({{2{fg4_9[16]}},fg4_9})) + ($signed({{2{fg4_10[16]}},fg4_10}) + $signed({{2{fg4_11[16]}},fg4_11})));
fg5_3<=(($signed({{3{fg4_12[15]}},fg4_12}) + $signed({{2{fg4_13[16]}},fg4_13})) + ($signed({{2{fg4_14[16]}},fg4_14}) + $signed({{3{fg4_15[15]}},fg4_15})));
end end end
always @(posedge clk)begin if(!rst_n)begin conv_y00<=0;conv_y01<=0;conv_y10<=0;conv_y11<=0;fc_sum<=0;end
else if(valid_pipe[5])begin if(!mode_pipe[5])begin
conv_y00<=((($signed({{10{z_0_0[21]}},z_0_0}) >>> 2) + ($signed({{12{z_1_0[19]}},z_1_0}) >>> 1)) + (($signed({{12{z_2_0[19]}},z_2_0}) >>> 1) + ($signed({{14{z_3_0[17]}},z_3_0}) >>> 0)));
conv_y01<=((($signed({{10{z_0_1[21]}},z_0_1}) >>> 2) + ($signed({{11{z_1_1[20]}},z_1_1}) >>> 1)) + (($signed({{12{z_2_1[19]}},z_2_1}) >>> 1) + ($signed({{13{z_3_1[18]}},z_3_1}) >>> 0)));
conv_y10<=((($signed({{10{z_0_2[21]}},z_0_2}) >>> 2) + ($signed({{12{z_1_2[19]}},z_1_2}) >>> 1)) + (($signed({{12{z_2_2[19]}},z_2_2}) >>> 1) + ($signed({{14{z_3_2[17]}},z_3_2}) >>> 0)));
conv_y11<=((($signed({{10{z_0_3[21]}},z_0_3}) >>> 2) + ($signed({{12{z_1_3[19]}},z_1_3}) >>> 1)) + (($signed({{12{z_2_3[19]}},z_2_3}) >>> 1) + ($signed({{14{z_3_3[17]}},z_3_3}) >>> 0)));
end else begin fc_sum<=(($signed({{13{fg5_0[18]}},fg5_0}) + $signed({{13{fg5_1[18]}},fg5_1})) + ($signed({{13{fg5_2[18]}},fg5_2}) + $signed({{13{fg5_3[18]}},fg5_3})));end end end
endmodule
```

## v25_dash/examples/synthetic_only/int8/mul/v25_dash_top.sv

```systemverilog
`timescale 1ps/1ps
// Derived from V25-H controller, commit 0d345f1. Continuous byte stream; one prime cycle after reset.
// DASH adaptation: four classes, train-derived scales, signed32 bias/score, RNE+U8 saturation.
module v25_dash_top(input logic clk,rst_n,input logic [7:0] data_in,
                   output logic [1:0] decision,output logic valid_out_6,output wire [127:0] logits);
    localparam ST_STREAM = 2'd0;
    localparam ST_FC     = 2'd1;
    localparam ST_DONE   = 2'd2;
    logic [1:0] state;

    // -------------------------------------------------------------------------
    // External input stream storage.
    // Explicit row/col/slot counters replace /28, %28 and %7 address arithmetic.
    // -------------------------------------------------------------------------
    logic [7:0] linebuf [0:6][0:27];
    logic [9:0] pixels_stored;
    logic       capture_primed;
    logic [4:0] cap_row, cap_col;
    logic [2:0] cap_slot;

    // Conv1 local 6x6 sliding window.
    // The engine sees only this register bank, not a dynamic 7x28 column mux.
    logic        [7:0]  c1_window [0:5][0:5];
    logic               c1_window_valid;
    logic [4:0]         c1_new_col;  // two entering columns for next stride-2 tile

    // Pool outputs. V6 retains only seven logical fmap1 rows at a time.
    // V25-H stores post-ReLU pooled values directly as unsigned 8-bit data.
    // Conv1 keeps two physical channels: 2 x 7 x 12 x 8 = 1344 payload bits.
    logic        [7:0] fmap1_ring [0:1][0:6][0:11];
    logic        [7:0] fmap2 [0:2][0:3][0:3];

    // -------------------------------------------------------------------------
    // Conv1 progress.
    // c1_base_slot = (2*c1_issue_pr) mod 7, maintained incrementally.
    // -------------------------------------------------------------------------
    logic [3:0] c1_issue_pr, c1_issue_pc;
    logic       c1_issue_oc;
    logic [2:0] c1_base_slot;
    logic [8:0] c1_issue_count;
    logic [8:0] c1_commit_count;

    // Conv1 writeback pipeline. WB0 registers the four quantized values; the
    // following cycle performs only 4-way max/ReLU and commits to fmap1_ring.
    logic c1_wb_valid;
    logic [2:0] c1_wb_slot;
    logic [3:0] c1_wb_pc;
    logic       c1_wb_oc;
    logic signed [11:0] c1_wb_q00, c1_wb_q01, c1_wb_q10, c1_wb_q11;

    // Conv2 progress.
    logic [1:0] c2_issue_pr, c2_issue_pc;
    logic [1:0] c2_issue_oc;
    logic       c2_issue_ic;
    // Physical ring slot corresponding to logical Conv2 window start row
    // (2*c2_issue_pr) mod 7. Updated only when Conv2 advances to next row.
    logic [2:0] c2_base_slot;
    logic [7:0] c2_issue_count;
    logic [7:0] c2_rsp_count;
    logic signed [31:0] c2_acc00, c2_acc01, c2_acc10, c2_acc11;

    // Conv2 writeback pipeline. the prior critical path ran directly from the
    // engine output register through final channel accumulation, quantization,
    // max-pool/ReLU and into fmap2. V4 cuts that cone into three short stages.
    logic c2_wb0_valid, c2_wb1_valid;
    logic [1:0] c2_wb0_pr, c2_wb0_pc, c2_wb0_oc;
    logic [1:0] c2_wb1_pr, c2_wb1_pc, c2_wb1_oc;
    logic signed [31:0] c2_wb0_sum00, c2_wb0_sum01, c2_wb0_sum10, c2_wb0_sum11;
    logic signed [11:0] c2_wb1_q00, c2_wb1_q01, c2_wb1_q10, c2_wb1_q11;
    logic [5:0] c2_commit_count;

    // FC progress: two temporal PoT1 requests per class implement SP2 exactly.
    logic [3:0] fc_issue_class;
    logic [4:0] fc_issue_count;
    logic       fc_issue_term;
    logic signed [31:0] fc_term0_sum;
    logic signed [31:0] best_score;
    logic [3:0] best_idx;

    // -------------------------------------------------------------------------
    // Helpers.
    // -------------------------------------------------------------------------
    localparam integer C1_RESTORE_SHIFT=0,C2_RESTORE_SHIFT=0;
    localparam integer FC_TWO_PASS=0;
function automatic signed [31:0] get_b1(input integer idx);begin case(idx)
0:get_b1=32'sd0;
1:get_b1=32'sd0;
default:get_b1=0;endcase end endfunction
function automatic signed [31:0] get_b2(input integer idx);begin case(idx)
0:get_b2=32'sd0;
1:get_b2=32'sd0;
2:get_b2=32'sd0;
default:get_b2=0;endcase end endfunction
function automatic signed [31:0] get_fcb(input integer idx);begin case(idx)
0:get_fcb=32'sd0;
1:get_fcb=32'sd0;
2:get_fcb=32'sd0;
3:get_fcb=32'sd0;
default:get_fcb=0;endcase end endfunction
function automatic [7:0] quant_u8(input signed [31:0] raw,input integer shift);
reg signed [63:0] base,rem,half;begin base=$signed(raw)>>>shift;
if(shift>0)begin rem=$signed(raw)-(base<<<shift);half=64'sd1<<<(shift-1);
if(rem>half||(rem==half&&base[0]))base=base+1;end
if(base<0)quant_u8=0;else if(base>255)quant_u8=255;else quant_u8=base[7:0];end endfunction
function automatic signed [11:0] conv1_q(input signed [31:0] raw,bias32);begin conv1_q={4'd0,quant_u8(raw+bias32,8)};end endfunction
function automatic signed [11:0] conv2_q(input signed [31:0] raw,bias32);begin conv2_q={4'd0,quant_u8(raw+bias32,7)};end endfunction
function automatic [7:0] max4_relu_a8(input signed [11:0] a,b,c,d);reg signed [11:0] m;begin
m=a;if(b>m)m=b;if(c>m)m=c;if(d>m)m=d;max4_relu_a8=m[7:0];end endfunction
logic signed [31:0] scores[0:3];integer score_clear;
assign logits={scores[3],scores[2],scores[1],scores[0]};
    function automatic [2:0] add_mod7(
        input logic [2:0] base,
        input integer off
    );
        integer tmp;
        begin
            tmp = base + off;
            if (tmp >= 7) tmp = tmp - 7;
            add_mod7 = tmp[2:0];
        end
    endfunction

    // -------------------------------------------------------------------------
    // Shared V6 engine.
    // -------------------------------------------------------------------------
    logic req_valid, req_is_fc;
    logic [15:0] req_tag;
    logic signed [8:0] req_tile [0:5][0:5];
    logic signed [8:0] req_fc_a [0:47];

    logic rsp_valid, rsp_is_fc;
    logic [15:0] rsp_tag;
    logic signed [31:0] rsp_y00, rsp_y01, rsp_y10, rsp_y11;
    logic signed [31:0] rsp_fc_sum;

    v25_dash_engine u_engine (
        .clk(clk), .rst_n(rst_n),
        .req_valid(req_valid), .req_is_fc(req_is_fc), .req_tag(req_tag),
        .conv_tile(req_tile), .fc_a(req_fc_a),
        .rsp_valid(rsp_valid), .rsp_is_fc(rsp_is_fc), .rsp_tag(rsp_tag),
        .conv_y00(rsp_y00), .conv_y01(rsp_y01),
        .conv_y10(rsp_y10), .conv_y11(rsp_y11),
        .fc_sum(rsp_fc_sum)
    );

    // -------------------------------------------------------------------------
    // Dependency checks.
    // -------------------------------------------------------------------------
    logic c1_tile_ready;
    integer c2_required_commit_idx;
    logic c2_data_ready;

    always_comb begin
        // V6 issues Conv1 only from the local sliding window. The row-start
        // window becomes valid on the same capture edge that makes V6's first
        // tile ready; subsequent horizontal tiles are shifted in-place.
        c1_tile_ready = (c1_issue_count < 9'd288) && c1_window_valid;

        // fmap1 is produced row-major, col-major, then two physical channels.
        // Physical ic0/ic1 map to original Conv1 channels 1/2.
        c2_required_commit_idx = (((c2_issue_pr*2 + 5) * 12
                                 + (c2_issue_pc*2 + 5)) * 2
                                 + c2_issue_ic);
        c2_data_ready = (c2_issue_count < 8'd96)
                     && (c1_commit_count > c2_required_commit_idx);
    end

    // -------------------------------------------------------------------------
    // Dependency-aware request scheduler.
    // Conv1 gets priority so the 7-line input buffer safety proof remains the
    // same as V2. Conv2 uses only otherwise-idle Conv1 cycles until C1 finishes.
    // -------------------------------------------------------------------------
    integer rr, cc, kk, lane, ch, pos;
    logic issue_c1, issue_c2;
    always_comb begin
        req_valid = 1'b0;
        req_is_fc = 1'b0;
        req_tag   = 16'd0;
        issue_c1  = 1'b0;
        issue_c2  = 1'b0;
        kk = 0;
        ch = 0;
        pos = 0;

        for (rr = 0; rr < 6; rr = rr + 1)
            for (cc = 0; cc < 6; cc = cc + 1)
                req_tile[rr][cc] = 9'sd0;

        for (lane = 0; lane < 48; lane = lane + 1) begin
            req_fc_a[lane] = 9'sd0;
        end

        if (state == ST_STREAM) begin
            if (c1_tile_ready) begin
                issue_c1 = 1'b1;
                req_valid = 1'b1;
                req_is_fc = 1'b0;
                req_tag = {1'b0, 3'b000, c1_issue_pr, c1_issue_pc, 1'b0, c1_issue_oc, 2'b00};

                // Fixed/local wiring: no c1_issue_pc-driven 28-column mux.
                for (rr = 0; rr < 6; rr = rr + 1)
                    for (cc = 0; cc < 6; cc = cc + 1)
                        req_tile[rr][cc] = {1'b0,c1_window[rr][cc]};
            end else if (c2_data_ready) begin
                issue_c2 = 1'b1;
                req_valid = 1'b1;
                req_is_fc = 1'b0;
                req_tag = {1'b1, 3'b000, {2'b00,c2_issue_pr},
                           {2'b00,c2_issue_pc}, c2_issue_oc, 1'b0, c2_issue_ic};

                for (rr = 0; rr < 6; rr = rr + 1)
                    for (cc = 0; cc < 6; cc = cc + 1)
                        req_tile[rr][cc] = {1'b0, fmap1_ring[c2_issue_ic]
                            [add_mod7(c2_base_slot,rr)][c2_issue_pc*2+cc]};
            end
        end else if (state == ST_FC && fc_issue_count < 5'd4) begin
            req_valid = 1'b1;
            req_is_fc = 1'b1;
            req_tag = {11'd0,fc_issue_term,fc_issue_class};

            for (lane = 0; lane < 48; lane = lane + 1) begin
                ch  = lane / 16;
                pos = lane % 16;
                req_fc_a[lane] = {1'b0,fmap2[ch][pos/4][pos%4]};
            end
        end
    end

    // -------------------------------------------------------------------------
    // Response decode / fixed-point behavior.
    // -------------------------------------------------------------------------
    wire rsp_layer = rsp_tag[15];
    wire [3:0] rsp_pr = rsp_tag[11:8];
    wire [3:0] rsp_pc = rsp_tag[7:4];
    wire [1:0] rsp_oc = rsp_tag[3:2];
    wire [1:0] rsp_ic = rsp_tag[1:0];
    wire [3:0] rsp_fc_class = rsp_tag[3:0];
    wire       rsp_fc_term  = rsp_tag[4];

    logic signed [11:0] rsp_c1q00, rsp_c1q01, rsp_c1q10, rsp_c1q11;
    logic signed [31:0] rsp_eng20_00, rsp_eng20_01, rsp_eng20_10, rsp_eng20_11;
    logic signed [11:0] c2_wb0_q00, c2_wb0_q01, c2_wb0_q10, c2_wb0_q11;
    logic signed [31:0] fc_score_now;
    logic signed [31:0] fc_class_sum;
    logic [13:0] fc_sum_mod14;
    logic [11:0] fc_base12;
    logic [1:0]  fc_rem2;
    logic signed [8:0] fc_low9;

    always_comb begin
        rsp_c1q00 = conv1_q($signed(rsp_y00) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q01 = conv1_q($signed(rsp_y01) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q10 = conv1_q($signed(rsp_y10) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q11 = conv1_q($signed(rsp_y11) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));

        rsp_eng20_00 = $signed(rsp_y00[31:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_01 = $signed(rsp_y01[31:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_10 = $signed(rsp_y10[31:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_11 = $signed(rsp_y11[31:0]) <<< C2_RESTORE_SHIFT;

        // WB1 quantization is now isolated from engine-output accumulation.
        c2_wb0_q00 = conv2_q(c2_wb0_sum00,get_b2(c2_wb0_oc));
        c2_wb0_q01 = conv2_q(c2_wb0_sum01,get_b2(c2_wb0_oc));
        c2_wb0_q10 = conv2_q(c2_wb0_sum10,get_b2(c2_wb0_oc));
        c2_wb0_q11 = conv2_q(c2_wb0_sum11,get_b2(c2_wb0_oc));

        fc_class_sum = (FC_TWO_PASS ? fc_term0_sum : 32'sd0) + rsp_fc_sum;
        fc_score_now = fc_class_sum + get_fcb(rsp_fc_class);
    end

    // -------------------------------------------------------------------------
    // Main controller.
    // -------------------------------------------------------------------------
    integer c1wr, c1wc;
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= ST_STREAM;
            pixels_stored <= 10'd0;
            capture_primed <= 1'b0;
            cap_row <= 0;
            cap_col <= 0;
            cap_slot <= 0;
            c1_window_valid <= 1'b0;
            c1_new_col <= 5'd6;

            c1_issue_pr <= 0; c1_issue_pc <= 0; c1_issue_oc <= 0;
            c1_base_slot <= 0;
            c1_issue_count <= 0; c1_commit_count <= 0;
            c1_wb_valid <= 1'b0;
            c1_wb_slot <= 0; c1_wb_pc <= 0; c1_wb_oc <= 0;
            c1_wb_q00 <= 0; c1_wb_q01 <= 0;
            c1_wb_q10 <= 0; c1_wb_q11 <= 0;

            c2_issue_pr <= 0; c2_issue_pc <= 0;
            c2_issue_oc <= 0; c2_issue_ic <= 0;
            c2_base_slot <= 0;
            c2_issue_count <= 0; c2_rsp_count <= 0;
            c2_acc00 <= 0; c2_acc01 <= 0; c2_acc10 <= 0; c2_acc11 <= 0;

            c2_wb0_valid <= 1'b0;
            c2_wb1_valid <= 1'b0;
            c2_wb0_pr <= 0; c2_wb0_pc <= 0; c2_wb0_oc <= 0;
            c2_wb1_pr <= 0; c2_wb1_pc <= 0; c2_wb1_oc <= 0;
            c2_wb0_sum00 <= 0; c2_wb0_sum01 <= 0;
            c2_wb0_sum10 <= 0; c2_wb0_sum11 <= 0;
            c2_wb1_q00 <= 0; c2_wb1_q01 <= 0;
            c2_wb1_q10 <= 0; c2_wb1_q11 <= 0;
            c2_commit_count <= 0;

            fc_issue_class <= 0;
            fc_issue_count <= 0;
            fc_issue_term <= 1'b0;
            fc_term0_sum <= 32'sd0;
            best_score <= 32'sh80000000;
            best_idx <= 0;

            for(score_clear=0;score_clear<4;score_clear=score_clear+1)scores[score_clear]<=0;
            decision <= 0;
            valid_out_6 <= 1'b0;
        end else begin
            valid_out_6 <= 1'b0;

            // Conv1 writeback pipeline. The response cycle performs only the
            // fixed-point quantization into WB0. The next cycle performs the
            // max/ReLU and writes one pooled value into the seven-row ring.
            c1_wb_valid <= 1'b0;
            if (c1_wb_valid) begin
                fmap1_ring[c1_wb_oc][c1_wb_slot][c1_wb_pc] <=
                    max4_relu_a8(c1_wb_q00,c1_wb_q01,c1_wb_q10,c1_wb_q11);
                c1_commit_count <= c1_commit_count + 1'b1;
            end

            // Conv2 writeback pipeline advances every cycle.
            c2_wb0_valid <= 1'b0;
            c2_wb1_valid <= c2_wb0_valid;
            if (c2_wb0_valid) begin
                c2_wb1_pr <= c2_wb0_pr;
                c2_wb1_pc <= c2_wb0_pc;
                c2_wb1_oc <= c2_wb0_oc;
                c2_wb1_q00 <= c2_wb0_q00;
                c2_wb1_q01 <= c2_wb0_q01;
                c2_wb1_q10 <= c2_wb0_q10;
                c2_wb1_q11 <= c2_wb0_q11;
            end

            // Commit pooled Conv2 output from the isolated WB1 stage.
            if (c2_wb1_valid) begin
                fmap2[c2_wb1_oc][c2_wb1_pr][c2_wb1_pc] <=
                    max4_relu_a8(c2_wb1_q00,c2_wb1_q01,c2_wb1_q10,c2_wb1_q11);
                c2_commit_count <= c2_commit_count + 1'b1;

                // Start FC only after the 48th pooled fmap2 value is committed.
                if (c2_commit_count == 6'd47) begin
                    state <= ST_FC;
                    fc_issue_class <= 0;
                    fc_issue_count <= 0;
                    fc_issue_term <= 1'b0;
                    fc_term0_sum <= 32'sd0;
                    best_score <= 32'sh80000000;
                    best_idx <= 0;
                end
            end

            // Input capture continues independently of C1/C2 scheduling.
            if (pixels_stored < 10'd784) begin
                if (!capture_primed) begin
                    capture_primed <= 1'b1;
                end else begin
                    linebuf[cap_slot][cap_col] <= data_in;
                    pixels_stored <= pixels_stored + 1'b1;

                    // Row-start preload for the current Conv1 pooled row.
                    // It fires on the exact edge that captures raw column 5 of
                    // the sixth required input row. All other 35 bytes already
                    // reside in the seven-row line buffer; the just-arriving
                    // bottom-right byte bypasses the linebuf NBA write.
                    if (!c1_window_valid &&
                        (c1_issue_pc == 4'd0) &&
                        (c1_issue_oc == 2'd0) &&
                        (cap_col == 5'd5) &&
                        (cap_row == ({c1_issue_pr,1'b0} + 5'd5))) begin
                        for (c1wr = 0; c1wr < 6; c1wr = c1wr + 1) begin
                            for (c1wc = 0; c1wc < 6; c1wc = c1wc + 1) begin
                                if ((c1wr == 5) && (c1wc == 5))
                                    c1_window[c1wr][c1wc] <= data_in;
                                else
                                    c1_window[c1wr][c1wc] <=
                                        linebuf[add_mod7(c1_base_slot,c1wr)][c1wc];
                            end
                        end
                        c1_window_valid <= 1'b1;
                        c1_new_col <= 5'd6;
                    end

                    if (cap_col == 5'd27) begin
                        cap_col <= 0;
                        if (cap_row < 5'd27)
                            cap_row <= cap_row + 1'b1;
                        cap_slot <= (cap_slot == 3'd6) ? 3'd0 : cap_slot + 1'b1;
                    end else begin
                        cap_col <= cap_col + 1'b1;
                    end
                end
            end

            // Request-side progress. Conv1 reuses the same local 6x6 window
            // for the two surviving output channels. After physical channel 1, the
            // window advances by stride 2: four columns are retained and only two entering
            // columns (12 bytes total) are fetched from linebuf.
            if (req_valid && !req_is_fc && issue_c1) begin
                c1_issue_count <= c1_issue_count + 1'b1;
                if (c1_issue_oc == 1'b0) begin
                    c1_issue_oc <= 1'b1;
                end else begin
                    c1_issue_oc <= 0;
                    if (c1_issue_pc < 11) begin
                        for (c1wr = 0; c1wr < 6; c1wr = c1wr + 1) begin
                            c1_window[c1wr][0] <= c1_window[c1wr][2];
                            c1_window[c1wr][1] <= c1_window[c1wr][3];
                            c1_window[c1wr][2] <= c1_window[c1wr][4];
                            c1_window[c1wr][3] <= c1_window[c1wr][5];
                            c1_window[c1wr][4] <=
                                linebuf[add_mod7(c1_base_slot,c1wr)][c1_new_col];
                            // With only two Conv1 channels, the horizontal
                            // window advances one cycle earlier than V24.
                            // The newest bottom-row byte is being captured on
                            // this same edge, so bypass the linebuf NBA write.
                            if ((c1wr == 5) &&
                                (cap_row == ({c1_issue_pr,1'b0} + 5'd5)) &&
                                (cap_col == (c1_new_col + 1'b1)))
                                c1_window[c1wr][5] <= data_in;
                            else
                                c1_window[c1wr][5] <=
                                    linebuf[add_mod7(c1_base_slot,c1wr)][c1_new_col + 1'b1];
                        end
                        c1_new_col <= c1_new_col + 5'd2;
                        c1_issue_pc <= c1_issue_pc + 1'b1;
                    end else begin
                        // Next pooled row starts again at raw columns 0..5.
                        // Its window is reloaded by the input-capture preload
                        // above when the new bottom row reaches column 5.
                        c1_window_valid <= 1'b0;
                        c1_new_col <= 5'd6;
                        c1_issue_pc <= 0;
                        if (c1_issue_pr < 11) begin
                            c1_issue_pr <= c1_issue_pr + 1'b1;
                            c1_base_slot <= add_mod7(c1_base_slot,2);
                        end
                    end
                end
            end

            if (req_valid && !req_is_fc && issue_c2) begin
                c2_issue_count <= c2_issue_count + 1'b1;
                if (c2_issue_ic == 1'b0) begin
                    c2_issue_ic <= 1'b1;
                end else begin
                    c2_issue_ic <= 1'b0;
                    if (c2_issue_oc < 2) begin
                        c2_issue_oc <= c2_issue_oc + 1'b1;
                    end else begin
                        c2_issue_oc <= 0;
                        if (c2_issue_pc < 3) begin
                            c2_issue_pc <= c2_issue_pc + 1'b1;
                        end else begin
                            c2_issue_pc <= 0;
                            if (c2_issue_pr < 3) begin
                                c2_issue_pr <= c2_issue_pr + 1'b1;
                                c2_base_slot <= add_mod7(c2_base_slot,2);
                            end
                        end
                    end
                end
            end

            if(req_valid && req_is_fc && state==ST_FC)begin
                fc_issue_count<=fc_issue_count+1'b1;
                if(FC_TWO_PASS && !fc_issue_term)fc_issue_term<=1'b1;
                else begin fc_issue_term<=0;if(fc_issue_class<3)fc_issue_class<=fc_issue_class+1'b1;end
            end

            // Conv1 response -> WB0 quantization register. Pool/ReLU and the
            // physical ring write occur on the following cycle above.
            if (rsp_valid && !rsp_is_fc && (rsp_layer == 1'b0)) begin
                c1_wb_valid <= 1'b1;
                c1_wb_slot <= add_mod7(3'd0,rsp_pr);
                c1_wb_pc <= rsp_pc;
                c1_wb_oc <= rsp_oc;
                c1_wb_q00 <= rsp_c1q00;
                c1_wb_q01 <= rsp_c1q01;
                c1_wb_q10 <= rsp_c1q10;
                c1_wb_q11 <= rsp_c1q11;
            end

            // Conv2 response -> two-input-channel accumulation.
            // The second input-channel result is captured into WB0 instead of running
            // accumulation + quantization + pool/ReLU in one cycle.
            if (rsp_valid && !rsp_is_fc && (rsp_layer == 1'b1)) begin
                c2_rsp_count <= c2_rsp_count + 1'b1;

                if (rsp_ic == 0) begin
                    c2_acc00 <= rsp_eng20_00;
                    c2_acc01 <= rsp_eng20_01;
                    c2_acc10 <= rsp_eng20_10;
                    c2_acc11 <= rsp_eng20_11;
                end else begin
                    c2_wb0_valid <= 1'b1;
                    c2_wb0_pr <= rsp_pr[1:0];
                    c2_wb0_pc <= rsp_pc[1:0];
                    c2_wb0_oc <= rsp_oc;
                    c2_wb0_sum00 <= c2_acc00 + rsp_eng20_00;
                    c2_wb0_sum01 <= c2_acc01 + rsp_eng20_01;
                    c2_wb0_sum10 <= c2_acc10 + rsp_eng20_10;
                    c2_wb0_sum11 <= c2_acc11 + rsp_eng20_11;

                    c2_acc00 <= 0; c2_acc01 <= 0;
                    c2_acc10 <= 0; c2_acc11 <= 0;
                end
            end

            // FC SP2 is evaluated as two temporal PoT1 passes per class.
            // term0 is buffered; term1 completes the exact SP2 dot product,
            // after which the reduced-width bias/argmax datapath runs.
            if (rsp_valid && rsp_is_fc) begin
                if (FC_TWO_PASS && rsp_fc_term == 1'b0) begin
                    fc_term0_sum <= rsp_fc_sum;
                end else begin
                    scores[rsp_fc_class] <= fc_score_now;
                    if (rsp_fc_class == 0) begin
                        best_score <= fc_score_now;
                        best_idx <= 0;
                    end else if ($signed(fc_score_now) > $signed(best_score)) begin
                        best_score <= fc_score_now;
                        best_idx <= rsp_fc_class;
                    end

                    if (rsp_fc_class == 3) begin
                        if ($signed(fc_score_now) > $signed(best_score))
                            decision <= 2'd3;
                        else
                            decision <= best_idx;
                        valid_out_6 <= 1'b1;
                        state <= ST_DONE;
                    end
                end
            end
        end
    end

endmodule
```

## v25_dash/examples/synthetic_only/v25h/mul/tb_engine.sv

```systemverilog
`timescale 1ps/1ps
module tb_engine;
reg clk=0,rst_n=0,req_valid=0,req_is_fc=0;reg [15:0] req_tag=0;
reg signed [8:0] tile[0:5][0:5],fa[0:47];wire rv,rf;wire [15:0] rt;
wire signed [31:0] y0,y1,y2,y3,fs;
v25_dash_engine dut(clk,rst_n,req_valid,req_is_fc,req_tag,tile,fa,rv,rf,rt,y0,y1,y2,y3,fs);
always #5 clk=~clk;
reg [7:0] xs[0:9215];reg [15:0] tags[0:191];reg fcs[0:191];reg [31:0] ys[0:767];
integer sent=0,received=0,r,c,j,cycle=0,issue_cycle[0:191];
always @(posedge clk)begin
 cycle=cycle+1;
 if(rst_n && req_valid)begin issue_cycle[sent]=cycle;sent=sent+1;end
 #1;
 if(rst_n && rv)begin
  if(received>=sent || rt!==tags[received] || rf!==fcs[received])$fatal(1,"FAIL engine tag/order");
  if(cycle-issue_cycle[received]!=6)$fatal(1,"FAIL engine latency");
  if(rf)begin if(fs!==ys[received*4])$fatal(1,"FAIL FC engine case=%0d got=%0d expected=%0d",received,fs,$signed(ys[received*4]));end
  else if(y0!==ys[received*4]||y1!==ys[received*4+1]||y2!==ys[received*4+2]||y3!==ys[received*4+3])
   $fatal(1,"FAIL Conv engine case=%0d got=%0d,%0d,%0d,%0d expected=%0d,%0d,%0d,%0d",received,y0,y1,y2,y3,$signed(ys[received*4]),$signed(ys[received*4+1]),$signed(ys[received*4+2]),$signed(ys[received*4+3]));
  received=received+1;
 end
end
initial begin
 $readmemh("engine_x.hex",xs);$readmemh("engine_tag.hex",tags);$readmemh("engine_fc.hex",fcs);$readmemh("engine_y.hex",ys);
 repeat(3)@(negedge clk);rst_n=1;
 for(j=0;j<192;j=j+1)begin
  if(j%11==0)begin req_valid=0;@(negedge clk);end
  req_valid=1;req_tag=tags[j];req_is_fc=fcs[j];
  for(r=0;r<6;r=r+1)for(c=0;c<6;c=c+1)tile[r][c]={1'b0,xs[j*48+r*6+c]};
  for(r=0;r<48;r=r+1)fa[r]={1'b0,xs[j*48+r]};
  @(negedge clk);
 end
 req_valid=0;repeat(10)@(negedge clk);
 if(received!=192)$fatal(1,"FAIL missing engine results");
 $display("PASS engine: 192 requests, all coefficient tags, bubbles, II=1, latency=6");$finish;
end
endmodule
```

## v25_dash/examples/synthetic_only/v25h/mul/tb_top.sv

```systemverilog
`timescale 1ps/1ps
module tb_top;
reg clk=0,rst_n=0;reg [7:0] data_in=0;wire [1:0] decision;wire valid_out_6;wire [127:0] logits;
v25_dash_top dut(clk,rst_n,data_in,decision,valid_out_6,logits);
always #5 clk=~clk;
reg [7:0] pixels[0:5487],p1[0:2015],p2[0:335];
reg [31:0] scores[0:27];reg [1:0] decisions[0:6];
integer n,j,c,r,col,cycles;
always @(posedge clk)begin
 if(rst_n)begin
  if(dut.c1_wb_valid)begin
   r=dut.c1_commit_count/24;c=dut.c1_wb_oc;col=dut.c1_wb_pc;
   if(dut.max4_relu_a8(dut.c1_wb_q00,dut.c1_wb_q01,dut.c1_wb_q10,dut.c1_wb_q11)!==p1[n*288+c*144+r*12+col])
    $fatal(1,"FAIL pool1 case=%0d channel=%0d row=%0d col=%0d",n,c,r,col);
  end
 end
end
task reset_patch;begin rst_n=0;data_in=0;repeat(3)@(negedge clk);rst_n=1;@(negedge clk);end endtask
initial begin
 $readmemh("pixels.hex",pixels);$readmemh("scores.hex",scores);$readmemh("pool1.hex",p1);$readmemh("pool2.hex",p2);$readmemh("decision.hex",decisions);
 for(n=0;n<7;n=n+1)begin
  reset_patch();
  for(j=0;j<784;j=j+1)begin data_in=pixels[n*784+j];@(negedge clk);end
  data_in=0;cycles=784;
  while(!valid_out_6 && cycles<2000)begin @(negedge clk);cycles=cycles+1;end
  if(!valid_out_6)$fatal(1,"FAIL top timeout");
  for(c=0;c<4;c=c+1)if(logits[c*32+:32]!==scores[n*4+c])$fatal(1,"FAIL score case=%0d class=%0d got=%0d expected=%0d",n,c,$signed(logits[c*32+:32]),$signed(scores[n*4+c]));
  if(decision!==decisions[n])$fatal(1,"FAIL decision");
  for(c=0;c<3;c=c+1)for(r=0;r<4;r=r+1)for(col=0;col<4;col=col+1)
   if(dut.fmap2[c][r][col]!==p2[n*48+c*16+r*4+col])$fatal(1,"FAIL pool2");
  if(dut.c1_commit_count!=288||dut.c2_commit_count!=48)$fatal(1,"FAIL commit count");
  $display("PASS top case=%0d class=%0d input_start_to_result_cycles=%0d",n,decision,cycles);
  repeat(3)begin @(negedge clk);if(valid_out_6)$fatal(1,"FAIL repeated valid");end
 end
 // Interrupt a fresh patch, reset, then reproduce case zero to catch stale ring/valid state.
 n=0;reset_patch();for(j=0;j<97;j=j+1)begin data_in=pixels[j];@(negedge clk);end
 reset_patch();for(j=0;j<784;j=j+1)begin data_in=pixels[j];@(negedge clk);end
 cycles=784;while(!valid_out_6&&cycles<2000)begin @(negedge clk);cycles=cycles+1;end
 if(!valid_out_6||decision!==decisions[0])$fatal(1,"FAIL mid-patch reset");
 for(c=0;c<4;c=c+1)if(logits[c*32+:32]!==scores[c])$fatal(1,"FAIL reset score");
 $display("PASS top: all four scores, both pooled maps, U8 extremes, repeat reset, mid-patch reset");$finish;
end
endmodule
```

## v25_dash/examples/synthetic_only/v25h/mul/v25_dash_engine.sv

```systemverilog
`timescale 1ps/1ps
// V25-derived 49-lane coefficient-specific shared pipeline; generated for DASH.
// mode=v25h, backend=mul; P0 request -> P6 response, II=1.
module v25_dash_engine(input logic clk,rst_n,req_valid,req_is_fc, input logic [15:0] req_tag,
input wire signed [8:0] conv_tile[0:5][0:5], input wire signed [8:0] fc_a[0:47],
output logic rsp_valid,rsp_is_fc, output logic [15:0] rsp_tag,
output logic signed [31:0] conv_y00,conv_y01,conv_y10,conv_y11,fc_sum);
logic [6:0] valid_pipe,mode_pipe; logic [15:0] tag_pipe[0:6]; integer k;
always @(posedge clk) begin if(!rst_n)begin valid_pipe<=0;mode_pipe<=0;for(k=0;k<7;k=k+1)tag_pipe[k]<=0;end
else begin valid_pipe<={valid_pipe[5:0],req_valid};mode_pipe<={mode_pipe[5:0],req_is_fc};
tag_pipe[0]<=req_tag;for(k=1;k<7;k=k+1)tag_pipe[k]<=tag_pipe[k-1];end end
assign rsp_valid=valid_pipe[6];assign rsp_is_fc=mode_pipe[6];assign rsp_tag=tag_pipe[6];
logic [7:0] x0[0:35],f0[0:47],f1[0:47];integer r,c;
always @(posedge clk)begin if(!rst_n)begin for(r=0;r<36;r=r+1)x0[r]<=0;
for(r=0;r<48;r=r+1)begin f0[r]<=0;f1[r]<=0;end end else begin
if(req_valid)begin if(req_is_fc)begin for(r=0;r<48;r=r+1)f0[r]<=fc_a[r][7:0];end
else begin for(r=0;r<6;r=r+1)for(c=0;c<6;c=c+1)x0[r*6+c]<=conv_tile[r][c][7:0];end end
if(valid_pipe[0]&&mode_pipe[0])for(r=0;r<48;r=r+1)f1[r]<=f0[r];end end
wire [6:0] key1={mode_pipe[1],tag_pipe[1][15],(mode_pipe[1]?tag_pipe[1][4]:1'b0),tag_pipe[1][3:0]};
wire [6:0] key2={mode_pipe[2],tag_pipe[2][15],(mode_pipe[2]?tag_pipe[2][4]:1'b0),tag_pipe[2][3:0]};
logic signed [9:0] b1_0,a2_0;logic signed [15:0] p3_0;
always @(posedge clk)begin if(!rst_n)begin b1_0<=0;a2_0<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_0<=(($signed({2'd0,x0[0]}) + -$signed({2'd0,x0[2]})) + (-$signed({2'd0,x0[12]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_0<=mode_pipe[1]?$signed({2'd0,f1[0]}):b1_0;
end end
logic signed [7:0] coefficient2_0;
always @(posedge clk)begin if(!rst_n)coefficient2_0<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_0<=-8'sd32;
7'd4:coefficient2_0<=-8'sd32;
7'd33:coefficient2_0<=-8'sd32;
7'd37:coefficient2_0<=8'sd32;
7'd40:coefficient2_0<=8'sd32;
7'd41:coefficient2_0<=8'sd64;
7'd64:coefficient2_0<=8'sd4;
7'd65:coefficient2_0<=-8'sd16;
7'd66:coefficient2_0<=-8'sd8;
7'd82:coefficient2_0<=-8'sd4;
7'd67:coefficient2_0<=-8'sd16;
default:coefficient2_0<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_0<=0;else if(valid_pipe[2])p3_0<=$signed({{6{a2_0[9]}},a2_0})*$signed({{8{coefficient2_0[7]}},coefficient2_0});end
logic signed [9:0] b1_1,a2_1;logic signed [15:0] p3_1;
always @(posedge clk)begin if(!rst_n)begin b1_1<=0;a2_1<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_1<=(($signed({2'd0,x0[1]}) + $signed({2'd0,x0[2]})) + (-$signed({2'd0,x0[13]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_1<=mode_pipe[1]?$signed({2'd0,f1[1]}):b1_1;
end end
logic signed [6:0] coefficient2_1;
always @(posedge clk)begin if(!rst_n)coefficient2_1<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_1<=-7'sd16;
7'd4:coefficient2_1<=-7'sd4;
7'd32:coefficient2_1<=-7'sd8;
7'd33:coefficient2_1<=-7'sd64;
7'd36:coefficient2_1<=7'sd8;
7'd37:coefficient2_1<=7'sd32;
7'd40:coefficient2_1<=-7'sd8;
7'd41:coefficient2_1<=7'sd16;
7'd64:coefficient2_1<=7'sd8;
7'd80:coefficient2_1<=7'sd4;
7'd65:coefficient2_1<=-7'sd4;
7'd81:coefficient2_1<=-7'sd2;
7'd66:coefficient2_1<=7'sd4;
7'd67:coefficient2_1<=7'sd8;
7'd83:coefficient2_1<=7'sd2;
default:coefficient2_1<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_1<=0;else if(valid_pipe[2])p3_1<=$signed({{6{a2_1[9]}},a2_1})*$signed({{9{coefficient2_1[6]}},coefficient2_1});end
logic signed [9:0] b1_2,a2_2;logic signed [15:0] p3_2;
always @(posedge clk)begin if(!rst_n)begin b1_2<=0;a2_2<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_2<=((-$signed({2'd0,x0[1]}) + $signed({2'd0,x0[2]})) + ($signed({2'd0,x0[13]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_2<=mode_pipe[1]?$signed({2'd0,f1[2]}):b1_2;
end end
logic signed [7:0] coefficient2_2;
always @(posedge clk)begin if(!rst_n)coefficient2_2<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_2<=8'sd4;
7'd4:coefficient2_2<=-8'sd32;
7'd32:coefficient2_2<=-8'sd32;
7'd33:coefficient2_2<=8'sd8;
7'd36:coefficient2_2<=8'sd32;
7'd37:coefficient2_2<=-8'sd8;
7'd40:coefficient2_2<=8'sd32;
7'd41:coefficient2_2<=8'sd64;
7'd64:coefficient2_2<=8'sd8;
7'd80:coefficient2_2<=8'sd1;
7'd65:coefficient2_2<=8'sd8;
7'd81:coefficient2_2<=8'sd2;
7'd66:coefficient2_2<=-8'sd4;
7'd67:coefficient2_2<=8'sd4;
7'd83:coefficient2_2<=8'sd2;
default:coefficient2_2<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_2<=0;else if(valid_pipe[2])p3_2<=$signed({{6{a2_2[9]}},a2_2})*$signed({{8{coefficient2_2[7]}},coefficient2_2});end
logic signed [9:0] b1_3,a2_3;logic signed [14:0] p3_3;
always @(posedge clk)begin if(!rst_n)begin b1_3<=0;a2_3<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_3<=(($signed({2'd0,x0[1]}) + -$signed({2'd0,x0[3]})) + (-$signed({2'd0,x0[13]}) + $signed({2'd0,x0[15]})));
if(valid_pipe[1])a2_3<=mode_pipe[1]?$signed({2'd0,f1[3]}):b1_3;
end end
logic signed [6:0] coefficient2_3;
always @(posedge clk)begin if(!rst_n)coefficient2_3<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_3<=7'sd16;
7'd4:coefficient2_3<=-7'sd16;
7'd32:coefficient2_3<=-7'sd32;
7'd36:coefficient2_3<=7'sd32;
7'd37:coefficient2_3<=-7'sd8;
7'd40:coefficient2_3<=-7'sd8;
7'd41:coefficient2_3<=7'sd8;
7'd64:coefficient2_3<=7'sd4;
7'd80:coefficient2_3<=7'sd2;
7'd65:coefficient2_3<=7'sd8;
7'd81:coefficient2_3<=7'sd2;
7'd66:coefficient2_3<=7'sd16;
7'd82:coefficient2_3<=7'sd1;
7'd67:coefficient2_3<=7'sd8;
default:coefficient2_3<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_3<=0;else if(valid_pipe[2])p3_3<=$signed({{5{a2_3[9]}},a2_3})*$signed({{8{coefficient2_3[6]}},coefficient2_3});end
logic signed [9:0] b1_4,a2_4;logic signed [15:0] p3_4;
always @(posedge clk)begin if(!rst_n)begin b1_4<=0;a2_4<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_4<=(($signed({2'd0,x0[6]}) + -$signed({2'd0,x0[8]})) + ($signed({2'd0,x0[12]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_4<=mode_pipe[1]?$signed({2'd0,f1[4]}):b1_4;
end end
logic signed [7:0] coefficient2_4;
always @(posedge clk)begin if(!rst_n)coefficient2_4<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_4<=-8'sd2;
7'd4:coefficient2_4<=8'sd8;
7'd32:coefficient2_4<=-8'sd32;
7'd33:coefficient2_4<=8'sd16;
7'd36:coefficient2_4<=8'sd32;
7'd37:coefficient2_4<=8'sd8;
7'd40:coefficient2_4<=8'sd16;
7'd41:coefficient2_4<=8'sd64;
7'd64:coefficient2_4<=8'sd4;
7'd80:coefficient2_4<=8'sd2;
7'd66:coefficient2_4<=-8'sd16;
7'd82:coefficient2_4<=-8'sd2;
7'd67:coefficient2_4<=8'sd16;
7'd83:coefficient2_4<=-8'sd1;
default:coefficient2_4<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_4<=0;else if(valid_pipe[2])p3_4<=$signed({{6{a2_4[9]}},a2_4})*$signed({{8{coefficient2_4[7]}},coefficient2_4});end
logic signed [10:0] b1_5,a2_5;logic signed [15:0] p3_5;
always @(posedge clk)begin if(!rst_n)begin b1_5<=0;a2_5<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_5<=(($signed({3'd0,x0[7]}) + $signed({3'd0,x0[8]})) + ($signed({3'd0,x0[13]}) + $signed({3'd0,x0[14]})));
if(valid_pipe[1])a2_5<=mode_pipe[1]?$signed({3'd0,f1[5]}):b1_5;
end end
logic signed [6:0] coefficient2_5;
always @(posedge clk)begin if(!rst_n)coefficient2_5<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_5<=-7'sd16;
7'd4:coefficient2_5<=7'sd16;
7'd32:coefficient2_5<=7'sd4;
7'd33:coefficient2_5<=7'sd8;
7'd36:coefficient2_5<=-7'sd16;
7'd37:coefficient2_5<=-7'sd16;
7'd40:coefficient2_5<=-7'sd16;
7'd41:coefficient2_5<=7'sd32;
7'd64:coefficient2_5<=-7'sd8;
7'd65:coefficient2_5<=7'sd16;
7'd81:coefficient2_5<=-7'sd1;
7'd66:coefficient2_5<=-7'sd4;
7'd82:coefficient2_5<=-7'sd2;
7'd67:coefficient2_5<=-7'sd2;
7'd83:coefficient2_5<=-7'sd1;
default:coefficient2_5<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_5<=0;else if(valid_pipe[2])p3_5<=$signed({{5{a2_5[10]}},a2_5})*$signed({{9{coefficient2_5[6]}},coefficient2_5});end
logic signed [9:0] b1_6,a2_6;logic signed [14:0] p3_6;
always @(posedge clk)begin if(!rst_n)begin b1_6<=0;a2_6<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_6<=((-$signed({2'd0,x0[7]}) + $signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[13]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_6<=mode_pipe[1]?$signed({2'd0,f1[6]}):b1_6;
end end
logic signed [6:0] coefficient2_6;
always @(posedge clk)begin if(!rst_n)coefficient2_6<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_6<=7'sd4;
7'd4:coefficient2_6<=-7'sd4;
7'd32:coefficient2_6<=-7'sd32;
7'd33:coefficient2_6<=7'sd32;
7'd36:coefficient2_6<=7'sd8;
7'd37:coefficient2_6<=7'sd32;
7'd40:coefficient2_6<=-7'sd16;
7'd41:coefficient2_6<=7'sd32;
7'd64:coefficient2_6<=7'sd16;
7'd80:coefficient2_6<=-7'sd2;
7'd65:coefficient2_6<=7'sd8;
7'd81:coefficient2_6<=7'sd2;
7'd66:coefficient2_6<=7'sd2;
7'd82:coefficient2_6<=7'sd1;
7'd67:coefficient2_6<=7'sd2;
default:coefficient2_6<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_6<=0;else if(valid_pipe[2])p3_6<=$signed({{5{a2_6[9]}},a2_6})*$signed({{8{coefficient2_6[6]}},coefficient2_6});end
logic signed [9:0] b1_7,a2_7;logic signed [15:0] p3_7;
always @(posedge clk)begin if(!rst_n)begin b1_7<=0;a2_7<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_7<=(($signed({2'd0,x0[7]}) + -$signed({2'd0,x0[9]})) + ($signed({2'd0,x0[13]}) + -$signed({2'd0,x0[15]})));
if(valid_pipe[1])a2_7<=mode_pipe[1]?$signed({2'd0,f1[7]}):b1_7;
end end
logic signed [6:0] coefficient2_7;
always @(posedge clk)begin if(!rst_n)coefficient2_7<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_7<=-7'sd4;
7'd4:coefficient2_7<=7'sd4;
7'd32:coefficient2_7<=-7'sd2;
7'd33:coefficient2_7<=7'sd16;
7'd36:coefficient2_7<=-7'sd32;
7'd40:coefficient2_7<=-7'sd64;
7'd41:coefficient2_7<=7'sd4;
7'd64:coefficient2_7<=-7'sd16;
7'd80:coefficient2_7<=7'sd2;
7'd66:coefficient2_7<=7'sd8;
7'd82:coefficient2_7<=7'sd2;
7'd67:coefficient2_7<=-7'sd4;
default:coefficient2_7<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_7<=0;else if(valid_pipe[2])p3_7<=$signed({{6{a2_7[9]}},a2_7})*$signed({{9{coefficient2_7[6]}},coefficient2_7});end
logic signed [9:0] b1_8,a2_8;logic signed [15:0] p3_8;
always @(posedge clk)begin if(!rst_n)begin b1_8<=0;a2_8<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_8<=((-$signed({2'd0,x0[6]}) + $signed({2'd0,x0[8]})) + ($signed({2'd0,x0[12]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_8<=mode_pipe[1]?$signed({2'd0,f1[8]}):b1_8;
end end
logic signed [7:0] coefficient2_8;
always @(posedge clk)begin if(!rst_n)coefficient2_8<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_8<=-8'sd2;
7'd4:coefficient2_8<=-8'sd32;
7'd32:coefficient2_8<=-8'sd32;
7'd33:coefficient2_8<=-8'sd2;
7'd36:coefficient2_8<=8'sd32;
7'd37:coefficient2_8<=8'sd64;
7'd40:coefficient2_8<=8'sd16;
7'd64:coefficient2_8<=8'sd16;
7'd80:coefficient2_8<=-8'sd2;
7'd65:coefficient2_8<=-8'sd4;
7'd81:coefficient2_8<=-8'sd1;
7'd66:coefficient2_8<=-8'sd4;
7'd67:coefficient2_8<=-8'sd4;
7'd83:coefficient2_8<=-8'sd1;
default:coefficient2_8<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_8<=0;else if(valid_pipe[2])p3_8<=$signed({{6{a2_8[9]}},a2_8})*$signed({{8{coefficient2_8[7]}},coefficient2_8});end
logic signed [9:0] b1_9,a2_9;logic signed [15:0] p3_9;
always @(posedge clk)begin if(!rst_n)begin b1_9<=0;a2_9<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_9<=((-$signed({2'd0,x0[7]}) + -$signed({2'd0,x0[8]})) + ($signed({2'd0,x0[13]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_9<=mode_pipe[1]?$signed({2'd0,f1[9]}):b1_9;
end end
logic signed [7:0] coefficient2_9;
always @(posedge clk)begin if(!rst_n)coefficient2_9<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_9<=8'sd1;
7'd4:coefficient2_9<=-8'sd8;
7'd32:coefficient2_9<=8'sd8;
7'd33:coefficient2_9<=-8'sd16;
7'd36:coefficient2_9<=8'sd32;
7'd37:coefficient2_9<=8'sd64;
7'd40:coefficient2_9<=-8'sd16;
7'd41:coefficient2_9<=-8'sd2;
7'd64:coefficient2_9<=8'sd8;
7'd65:coefficient2_9<=8'sd16;
7'd81:coefficient2_9<=-8'sd1;
7'd66:coefficient2_9<=-8'sd16;
7'd82:coefficient2_9<=-8'sd2;
7'd67:coefficient2_9<=8'sd16;
7'd83:coefficient2_9<=-8'sd2;
default:coefficient2_9<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_9<=0;else if(valid_pipe[2])p3_9<=$signed({{6{a2_9[9]}},a2_9})*$signed({{8{coefficient2_9[7]}},coefficient2_9});end
logic signed [9:0] b1_10,a2_10;logic signed [15:0] p3_10;
always @(posedge clk)begin if(!rst_n)begin b1_10<=0;a2_10<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_10<=(($signed({2'd0,x0[7]}) + -$signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[13]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_10<=mode_pipe[1]?$signed({2'd0,f1[10]}):b1_10;
end end
logic signed [6:0] coefficient2_10;
always @(posedge clk)begin if(!rst_n)coefficient2_10<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_10<=7'sd32;
7'd4:coefficient2_10<=-7'sd64;
7'd32:coefficient2_10<=-7'sd32;
7'd33:coefficient2_10<=-7'sd4;
7'd36:coefficient2_10<=7'sd2;
7'd37:coefficient2_10<=7'sd32;
7'd40:coefficient2_10<=7'sd16;
7'd41:coefficient2_10<=-7'sd32;
7'd64:coefficient2_10<=-7'sd4;
7'd80:coefficient2_10<=-7'sd1;
7'd65:coefficient2_10<=-7'sd2;
7'd66:coefficient2_10<=-7'sd4;
7'd67:coefficient2_10<=-7'sd16;
7'd83:coefficient2_10<=-7'sd2;
default:coefficient2_10<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_10<=0;else if(valid_pipe[2])p3_10<=$signed({{6{a2_10[9]}},a2_10})*$signed({{9{coefficient2_10[6]}},coefficient2_10});end
logic signed [9:0] b1_11,a2_11;logic signed [14:0] p3_11;
always @(posedge clk)begin if(!rst_n)begin b1_11<=0;a2_11<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_11<=((-$signed({2'd0,x0[7]}) + $signed({2'd0,x0[9]})) + ($signed({2'd0,x0[13]}) + -$signed({2'd0,x0[15]})));
if(valid_pipe[1])a2_11<=mode_pipe[1]?$signed({2'd0,f1[11]}):b1_11;
end end
logic signed [6:0] coefficient2_11;
always @(posedge clk)begin if(!rst_n)coefficient2_11<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_11<=7'sd32;
7'd4:coefficient2_11<=-7'sd32;
7'd32:coefficient2_11<=-7'sd2;
7'd33:coefficient2_11<=-7'sd16;
7'd36:coefficient2_11<=7'sd8;
7'd37:coefficient2_11<=7'sd32;
7'd40:coefficient2_11<=-7'sd8;
7'd41:coefficient2_11<=-7'sd32;
7'd64:coefficient2_11<=-7'sd8;
7'd80:coefficient2_11<=-7'sd4;
7'd65:coefficient2_11<=7'sd8;
7'd67:coefficient2_11<=-7'sd8;
7'd83:coefficient2_11<=7'sd1;
default:coefficient2_11<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_11<=0;else if(valid_pipe[2])p3_11<=$signed({{5{a2_11[9]}},a2_11})*$signed({{8{coefficient2_11[6]}},coefficient2_11});end
logic signed [9:0] b1_12,a2_12;logic signed [15:0] p3_12;
always @(posedge clk)begin if(!rst_n)begin b1_12<=0;a2_12<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_12<=(($signed({2'd0,x0[6]}) + -$signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[18]}) + $signed({2'd0,x0[20]})));
if(valid_pipe[1])a2_12<=mode_pipe[1]?$signed({2'd0,f1[12]}):b1_12;
end end
logic signed [7:0] coefficient2_12;
always @(posedge clk)begin if(!rst_n)coefficient2_12<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_12<=8'sd32;
7'd32:coefficient2_12<=-8'sd64;
7'd33:coefficient2_12<=8'sd64;
7'd36:coefficient2_12<=8'sd64;
7'd37:coefficient2_12<=8'sd32;
7'd64:coefficient2_12<=-8'sd4;
7'd80:coefficient2_12<=-8'sd1;
7'd65:coefficient2_12<=8'sd8;
7'd67:coefficient2_12<=-8'sd8;
7'd83:coefficient2_12<=-8'sd2;
default:coefficient2_12<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_12<=0;else if(valid_pipe[2])p3_12<=$signed({{6{a2_12[9]}},a2_12})*$signed({{8{coefficient2_12[7]}},coefficient2_12});end
logic signed [9:0] b1_13,a2_13;logic signed [14:0] p3_13;
always @(posedge clk)begin if(!rst_n)begin b1_13<=0;a2_13<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_13<=(($signed({2'd0,x0[7]}) + $signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[19]}) + -$signed({2'd0,x0[20]})));
if(valid_pipe[1])a2_13<=mode_pipe[1]?$signed({2'd0,f1[13]}):b1_13;
end end
logic signed [6:0] coefficient2_13;
always @(posedge clk)begin if(!rst_n)coefficient2_13<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_13<=7'sd8;
7'd4:coefficient2_13<=7'sd16;
7'd32:coefficient2_13<=7'sd32;
7'd33:coefficient2_13<=7'sd32;
7'd36:coefficient2_13<=7'sd8;
7'd37:coefficient2_13<=7'sd8;
7'd40:coefficient2_13<=-7'sd32;
7'd41:coefficient2_13<=7'sd16;
7'd64:coefficient2_13<=-7'sd8;
7'd65:coefficient2_13<=-7'sd8;
7'd81:coefficient2_13<=-7'sd2;
7'd66:coefficient2_13<=-7'sd8;
7'd82:coefficient2_13<=-7'sd1;
7'd67:coefficient2_13<=7'sd16;
7'd83:coefficient2_13<=7'sd2;
default:coefficient2_13<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_13<=0;else if(valid_pipe[2])p3_13<=$signed({{5{a2_13[9]}},a2_13})*$signed({{8{coefficient2_13[6]}},coefficient2_13});end
logic signed [9:0] b1_14,a2_14;logic signed [15:0] p3_14;
always @(posedge clk)begin if(!rst_n)begin b1_14<=0;a2_14<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_14<=((-$signed({2'd0,x0[7]}) + $signed({2'd0,x0[8]})) + ($signed({2'd0,x0[19]}) + -$signed({2'd0,x0[20]})));
if(valid_pipe[1])a2_14<=mode_pipe[1]?$signed({2'd0,f1[14]}):b1_14;
end end
logic signed [7:0] coefficient2_14;
always @(posedge clk)begin if(!rst_n)coefficient2_14<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_14<=8'sd32;
7'd4:coefficient2_14<=-8'sd16;
7'd32:coefficient2_14<=-8'sd32;
7'd33:coefficient2_14<=8'sd8;
7'd36:coefficient2_14<=-8'sd32;
7'd37:coefficient2_14<=8'sd64;
7'd40:coefficient2_14<=-8'sd32;
7'd41:coefficient2_14<=-8'sd64;
7'd64:coefficient2_14<=8'sd8;
7'd65:coefficient2_14<=8'sd16;
7'd81:coefficient2_14<=-8'sd1;
7'd66:coefficient2_14<=-8'sd4;
7'd82:coefficient2_14<=-8'sd1;
7'd67:coefficient2_14<=8'sd4;
default:coefficient2_14<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_14<=0;else if(valid_pipe[2])p3_14<=$signed({{6{a2_14[9]}},a2_14})*$signed({{8{coefficient2_14[7]}},coefficient2_14});end
logic signed [9:0] b1_15,a2_15;logic signed [15:0] p3_15;
always @(posedge clk)begin if(!rst_n)begin b1_15<=0;a2_15<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_15<=(($signed({2'd0,x0[7]}) + -$signed({2'd0,x0[9]})) + (-$signed({2'd0,x0[19]}) + $signed({2'd0,x0[21]})));
if(valid_pipe[1])a2_15<=mode_pipe[1]?$signed({2'd0,f1[15]}):b1_15;
end end
logic signed [7:0] coefficient2_15;
always @(posedge clk)begin if(!rst_n)coefficient2_15<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_15<=8'sd16;
7'd32:coefficient2_15<=8'sd32;
7'd36:coefficient2_15<=-8'sd64;
7'd37:coefficient2_15<=8'sd64;
7'd40:coefficient2_15<=-8'sd64;
7'd41:coefficient2_15<=-8'sd32;
7'd65:coefficient2_15<=-8'sd8;
7'd81:coefficient2_15<=8'sd1;
7'd66:coefficient2_15<=8'sd4;
7'd82:coefficient2_15<=8'sd2;
7'd67:coefficient2_15<=-8'sd8;
7'd83:coefficient2_15<=8'sd1;
default:coefficient2_15<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_15<=0;else if(valid_pipe[2])p3_15<=$signed({{6{a2_15[9]}},a2_15})*$signed({{8{coefficient2_15[7]}},coefficient2_15});end
logic signed [9:0] b1_16,a2_16;logic signed [14:0] p3_16;
always @(posedge clk)begin if(!rst_n)begin b1_16<=0;a2_16<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_16<=(($signed({2'd0,x0[3]}) + -$signed({2'd0,x0[4]})) + (-$signed({2'd0,x0[15]}) + $signed({2'd0,x0[16]})));
if(valid_pipe[1])a2_16<=mode_pipe[1]?$signed({2'd0,f1[16]}):b1_16;
end end
logic signed [6:0] coefficient2_16;
always @(posedge clk)begin if(!rst_n)coefficient2_16<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_16<=-7'sd16;
7'd4:coefficient2_16<=-7'sd8;
7'd33:coefficient2_16<=-7'sd4;
7'd36:coefficient2_16<=7'sd8;
7'd37:coefficient2_16<=-7'sd8;
7'd40:coefficient2_16<=-7'sd4;
7'd41:coefficient2_16<=7'sd32;
7'd64:coefficient2_16<=7'sd8;
7'd80:coefficient2_16<=7'sd2;
7'd66:coefficient2_16<=-7'sd4;
7'd67:coefficient2_16<=-7'sd8;
7'd83:coefficient2_16<=-7'sd4;
default:coefficient2_16<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_16<=0;else if(valid_pipe[2])p3_16<=$signed({{5{a2_16[9]}},a2_16})*$signed({{8{coefficient2_16[6]}},coefficient2_16});end
logic signed [8:0] b1_17,a2_17;logic signed [14:0] p3_17;
always @(posedge clk)begin if(!rst_n)begin b1_17<=0;a2_17<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_17<=($signed({1'd0,x0[4]}) + -$signed({1'd0,x0[16]}));
if(valid_pipe[1])a2_17<=mode_pipe[1]?$signed({1'd0,f1[17]}):b1_17;
end end
logic signed [6:0] coefficient2_17;
always @(posedge clk)begin if(!rst_n)coefficient2_17<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_17<=-7'sd64;
7'd4:coefficient2_17<=-7'sd32;
7'd32:coefficient2_17<=-7'sd32;
7'd33:coefficient2_17<=-7'sd16;
7'd36:coefficient2_17<=7'sd16;
7'd37:coefficient2_17<=-7'sd2;
7'd40:coefficient2_17<=-7'sd2;
7'd41:coefficient2_17<=7'sd16;
7'd64:coefficient2_17<=-7'sd8;
7'd80:coefficient2_17<=-7'sd1;
7'd65:coefficient2_17<=7'sd16;
7'd81:coefficient2_17<=-7'sd1;
7'd66:coefficient2_17<=-7'sd16;
7'd82:coefficient2_17<=-7'sd2;
default:coefficient2_17<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_17<=0;else if(valid_pipe[2])p3_17<=$signed({{6{a2_17[8]}},a2_17})*$signed({{8{coefficient2_17[6]}},coefficient2_17});end
logic signed [9:0] b1_18,a2_18;logic signed [14:0] p3_18;
always @(posedge clk)begin if(!rst_n)begin b1_18<=0;a2_18<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_18<=((-$signed({2'd0,x0[4]}) + $signed({2'd0,x0[5]})) + ($signed({2'd0,x0[16]}) + -$signed({2'd0,x0[17]})));
if(valid_pipe[1])a2_18<=mode_pipe[1]?$signed({2'd0,f1[18]}):b1_18;
end end
logic signed [5:0] coefficient2_18;
always @(posedge clk)begin if(!rst_n)coefficient2_18<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_18<=-6'sd32;
7'd4:coefficient2_18<=-6'sd16;
7'd32:coefficient2_18<=-6'sd32;
7'd33:coefficient2_18<=-6'sd16;
7'd36:coefficient2_18<=6'sd8;
7'd37:coefficient2_18<=6'sd8;
7'd40:coefficient2_18<=6'sd4;
7'd41:coefficient2_18<=-6'sd8;
7'd64:coefficient2_18<=-6'sd16;
7'd80:coefficient2_18<=-6'sd1;
7'd65:coefficient2_18<=-6'sd2;
7'd66:coefficient2_18<=-6'sd16;
7'd82:coefficient2_18<=6'sd2;
7'd67:coefficient2_18<=6'sd8;
7'd83:coefficient2_18<=6'sd2;
default:coefficient2_18<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_18<=0;else if(valid_pipe[2])p3_18<=$signed({{5{a2_18[9]}},a2_18})*$signed({{9{coefficient2_18[5]}},coefficient2_18});end
logic signed [9:0] b1_19,a2_19;logic signed [14:0] p3_19;
always @(posedge clk)begin if(!rst_n)begin b1_19<=0;a2_19<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_19<=(($signed({2'd0,x0[9]}) + -$signed({2'd0,x0[10]})) + ($signed({2'd0,x0[15]}) + -$signed({2'd0,x0[16]})));
if(valid_pipe[1])a2_19<=mode_pipe[1]?$signed({2'd0,f1[19]}):b1_19;
end end
logic signed [5:0] coefficient2_19;
always @(posedge clk)begin if(!rst_n)coefficient2_19<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_19<=-6'sd4;
7'd4:coefficient2_19<=-6'sd8;
7'd32:coefficient2_19<=6'sd2;
7'd33:coefficient2_19<=-6'sd32;
7'd36:coefficient2_19<=6'sd8;
7'd37:coefficient2_19<=-6'sd8;
7'd40:coefficient2_19<=-6'sd4;
7'd41:coefficient2_19<=6'sd8;
7'd64:coefficient2_19<=-6'sd8;
7'd80:coefficient2_19<=-6'sd4;
7'd65:coefficient2_19<=-6'sd16;
7'd66:coefficient2_19<=-6'sd4;
7'd82:coefficient2_19<=-6'sd2;
7'd67:coefficient2_19<=-6'sd16;
7'd83:coefficient2_19<=-6'sd1;
default:coefficient2_19<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_19<=0;else if(valid_pipe[2])p3_19<=$signed({{5{a2_19[9]}},a2_19})*$signed({{9{coefficient2_19[5]}},coefficient2_19});end
logic signed [9:0] b1_20,a2_20;logic signed [14:0] p3_20;
always @(posedge clk)begin if(!rst_n)begin b1_20<=0;a2_20<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_20<=($signed({2'd0,x0[10]}) + $signed({2'd0,x0[16]}));
if(valid_pipe[1])a2_20<=mode_pipe[1]?$signed({2'd0,f1[20]}):b1_20;
end end
logic signed [6:0] coefficient2_20;
always @(posedge clk)begin if(!rst_n)coefficient2_20<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_20<=-7'sd32;
7'd4:coefficient2_20<=-7'sd32;
7'd32:coefficient2_20<=-7'sd16;
7'd33:coefficient2_20<=-7'sd32;
7'd36:coefficient2_20<=7'sd32;
7'd37:coefficient2_20<=-7'sd8;
7'd40:coefficient2_20<=-7'sd8;
7'd41:coefficient2_20<=-7'sd8;
7'd64:coefficient2_20<=-7'sd16;
7'd65:coefficient2_20<=7'sd4;
7'd81:coefficient2_20<=7'sd1;
7'd66:coefficient2_20<=7'sd4;
7'd82:coefficient2_20<=7'sd1;
7'd67:coefficient2_20<=7'sd8;
7'd83:coefficient2_20<=7'sd4;
default:coefficient2_20<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_20<=0;else if(valid_pipe[2])p3_20<=$signed({{5{a2_20[9]}},a2_20})*$signed({{8{coefficient2_20[6]}},coefficient2_20});end
logic signed [9:0] b1_21,a2_21;logic signed [14:0] p3_21;
always @(posedge clk)begin if(!rst_n)begin b1_21<=0;a2_21<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_21<=((-$signed({2'd0,x0[10]}) + $signed({2'd0,x0[11]})) + (-$signed({2'd0,x0[16]}) + $signed({2'd0,x0[17]})));
if(valid_pipe[1])a2_21<=mode_pipe[1]?$signed({2'd0,f1[21]}):b1_21;
end end
logic signed [5:0] coefficient2_21;
always @(posedge clk)begin if(!rst_n)coefficient2_21<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_21<=-6'sd32;
7'd4:coefficient2_21<=-6'sd32;
7'd32:coefficient2_21<=-6'sd16;
7'd36:coefficient2_21<=6'sd16;
7'd37:coefficient2_21<=6'sd1;
7'd40:coefficient2_21<=-6'sd2;
7'd41:coefficient2_21<=-6'sd16;
7'd64:coefficient2_21<=6'sd2;
7'd66:coefficient2_21<=-6'sd8;
7'd82:coefficient2_21<=6'sd1;
7'd67:coefficient2_21<=6'sd8;
7'd83:coefficient2_21<=6'sd4;
default:coefficient2_21<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_21<=0;else if(valid_pipe[2])p3_21<=$signed({{5{a2_21[9]}},a2_21})*$signed({{9{coefficient2_21[5]}},coefficient2_21});end
logic signed [9:0] b1_22,a2_22;logic signed [14:0] p3_22;
always @(posedge clk)begin if(!rst_n)begin b1_22<=0;a2_22<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_22<=((-$signed({2'd0,x0[9]}) + $signed({2'd0,x0[10]})) + ($signed({2'd0,x0[15]}) + -$signed({2'd0,x0[16]})));
if(valid_pipe[1])a2_22<=mode_pipe[1]?$signed({2'd0,f1[22]}):b1_22;
end end
logic signed [6:0] coefficient2_22;
always @(posedge clk)begin if(!rst_n)coefficient2_22<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_22<=-7'sd16;
7'd4:coefficient2_22<=-7'sd8;
7'd32:coefficient2_22<=-7'sd16;
7'd33:coefficient2_22<=-7'sd4;
7'd36:coefficient2_22<=-7'sd16;
7'd37:coefficient2_22<=-7'sd8;
7'd40:coefficient2_22<=7'sd4;
7'd41:coefficient2_22<=7'sd32;
7'd65:coefficient2_22<=7'sd16;
7'd81:coefficient2_22<=7'sd1;
7'd66:coefficient2_22<=7'sd16;
7'd82:coefficient2_22<=-7'sd1;
7'd67:coefficient2_22<=7'sd8;
7'd83:coefficient2_22<=7'sd2;
default:coefficient2_22<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_22<=0;else if(valid_pipe[2])p3_22<=$signed({{5{a2_22[9]}},a2_22})*$signed({{8{coefficient2_22[6]}},coefficient2_22});end
logic signed [8:0] b1_23,a2_23;logic signed [14:0] p3_23;
always @(posedge clk)begin if(!rst_n)begin b1_23<=0;a2_23<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_23<=(-$signed({1'd0,x0[10]}) + $signed({1'd0,x0[16]}));
if(valid_pipe[1])a2_23<=mode_pipe[1]?$signed({1'd0,f1[23]}):b1_23;
end end
logic signed [6:0] coefficient2_23;
always @(posedge clk)begin if(!rst_n)coefficient2_23<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_23<=-7'sd16;
7'd4:coefficient2_23<=-7'sd16;
7'd32:coefficient2_23<=-7'sd64;
7'd33:coefficient2_23<=-7'sd32;
7'd36:coefficient2_23<=-7'sd32;
7'd37:coefficient2_23<=7'sd8;
7'd40:coefficient2_23<=7'sd8;
7'd41:coefficient2_23<=7'sd32;
7'd64:coefficient2_23<=-7'sd8;
7'd80:coefficient2_23<=-7'sd4;
7'd65:coefficient2_23<=-7'sd8;
7'd81:coefficient2_23<=7'sd1;
7'd66:coefficient2_23<=7'sd16;
7'd82:coefficient2_23<=-7'sd2;
7'd67:coefficient2_23<=-7'sd8;
7'd83:coefficient2_23<=-7'sd1;
default:coefficient2_23<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_23<=0;else if(valid_pipe[2])p3_23<=$signed({{6{a2_23[8]}},a2_23})*$signed({{8{coefficient2_23[6]}},coefficient2_23});end
logic signed [9:0] b1_24,a2_24;logic signed [14:0] p3_24;
always @(posedge clk)begin if(!rst_n)begin b1_24<=0;a2_24<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_24<=(($signed({2'd0,x0[10]}) + -$signed({2'd0,x0[11]})) + (-$signed({2'd0,x0[16]}) + $signed({2'd0,x0[17]})));
if(valid_pipe[1])a2_24<=mode_pipe[1]?$signed({2'd0,f1[24]}):b1_24;
end end
logic signed [5:0] coefficient2_24;
always @(posedge clk)begin if(!rst_n)coefficient2_24<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_24<=-6'sd4;
7'd4:coefficient2_24<=-6'sd4;
7'd32:coefficient2_24<=-6'sd32;
7'd33:coefficient2_24<=-6'sd32;
7'd36:coefficient2_24<=-6'sd8;
7'd37:coefficient2_24<=6'sd16;
7'd40:coefficient2_24<=6'sd8;
7'd41:coefficient2_24<=-6'sd2;
7'd64:coefficient2_24<=6'sd8;
7'd80:coefficient2_24<=6'sd4;
7'd65:coefficient2_24<=-6'sd4;
7'd81:coefficient2_24<=-6'sd1;
7'd66:coefficient2_24<=6'sd8;
7'd67:coefficient2_24<=6'sd8;
7'd83:coefficient2_24<=6'sd4;
default:coefficient2_24<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_24<=0;else if(valid_pipe[2])p3_24<=$signed({{5{a2_24[9]}},a2_24})*$signed({{9{coefficient2_24[5]}},coefficient2_24});end
logic signed [9:0] b1_25,a2_25;logic signed [14:0] p3_25;
always @(posedge clk)begin if(!rst_n)begin b1_25<=0;a2_25<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_25<=(($signed({2'd0,x0[9]}) + -$signed({2'd0,x0[10]})) + (-$signed({2'd0,x0[21]}) + $signed({2'd0,x0[22]})));
if(valid_pipe[1])a2_25<=mode_pipe[1]?$signed({2'd0,f1[25]}):b1_25;
end end
logic signed [5:0] coefficient2_25;
always @(posedge clk)begin if(!rst_n)coefficient2_25<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_25<=6'sd4;
7'd4:coefficient2_25<=-6'sd4;
7'd32:coefficient2_25<=-6'sd8;
7'd33:coefficient2_25<=-6'sd32;
7'd36:coefficient2_25<=-6'sd16;
7'd37:coefficient2_25<=-6'sd8;
7'd40:coefficient2_25<=6'sd4;
7'd41:coefficient2_25<=6'sd16;
7'd64:coefficient2_25<=-6'sd8;
7'd80:coefficient2_25<=6'sd1;
7'd65:coefficient2_25<=-6'sd2;
7'd81:coefficient2_25<=-6'sd1;
7'd66:coefficient2_25<=-6'sd16;
7'd67:coefficient2_25<=6'sd8;
7'd83:coefficient2_25<=-6'sd1;
default:coefficient2_25<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_25<=0;else if(valid_pipe[2])p3_25<=$signed({{5{a2_25[9]}},a2_25})*$signed({{9{coefficient2_25[5]}},coefficient2_25});end
logic signed [8:0] b1_26,a2_26;logic signed [14:0] p3_26;
always @(posedge clk)begin if(!rst_n)begin b1_26<=0;a2_26<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_26<=($signed({1'd0,x0[10]}) + -$signed({1'd0,x0[22]}));
if(valid_pipe[1])a2_26<=mode_pipe[1]?$signed({1'd0,f1[26]}):b1_26;
end end
logic signed [6:0] coefficient2_26;
always @(posedge clk)begin if(!rst_n)coefficient2_26<=0;else if(valid_pipe[1])begin case(key1)
7'd4:coefficient2_26<=-7'sd8;
7'd32:coefficient2_26<=-7'sd32;
7'd33:coefficient2_26<=-7'sd64;
7'd36:coefficient2_26<=-7'sd8;
7'd37:coefficient2_26<=7'sd2;
7'd40:coefficient2_26<=7'sd4;
7'd41:coefficient2_26<=7'sd8;
7'd64:coefficient2_26<=7'sd2;
7'd66:coefficient2_26<=7'sd8;
7'd82:coefficient2_26<=7'sd1;
7'd67:coefficient2_26<=7'sd8;
default:coefficient2_26<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_26<=0;else if(valid_pipe[2])p3_26<=$signed({{6{a2_26[8]}},a2_26})*$signed({{8{coefficient2_26[6]}},coefficient2_26});end
logic signed [9:0] b1_27,a2_27;logic signed [13:0] p3_27;
always @(posedge clk)begin if(!rst_n)begin b1_27<=0;a2_27<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_27<=((-$signed({2'd0,x0[10]}) + $signed({2'd0,x0[11]})) + ($signed({2'd0,x0[22]}) + -$signed({2'd0,x0[23]})));
if(valid_pipe[1])a2_27<=mode_pipe[1]?$signed({2'd0,f1[27]}):b1_27;
end end
logic signed [4:0] coefficient2_27;
always @(posedge clk)begin if(!rst_n)coefficient2_27<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_27<=-5'sd4;
7'd4:coefficient2_27<=-5'sd4;
7'd32:coefficient2_27<=-5'sd16;
7'd33:coefficient2_27<=-5'sd16;
7'd36:coefficient2_27<=5'sd4;
7'd37:coefficient2_27<=5'sd8;
7'd41:coefficient2_27<=-5'sd8;
7'd64:coefficient2_27<=5'sd2;
7'd80:coefficient2_27<=5'sd1;
7'd65:coefficient2_27<=-5'sd2;
7'd81:coefficient2_27<=-5'sd1;
7'd66:coefficient2_27<=5'sd8;
7'd82:coefficient2_27<=5'sd4;
7'd67:coefficient2_27<=5'sd8;
default:coefficient2_27<=5'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_27<=0;else if(valid_pipe[2])p3_27<=$signed({{4{a2_27[9]}},a2_27})*$signed({{9{coefficient2_27[4]}},coefficient2_27});end
logic signed [9:0] b1_28,a2_28;logic signed [14:0] p3_28;
always @(posedge clk)begin if(!rst_n)begin b1_28<=0;a2_28<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_28<=(($signed({2'd0,x0[18]}) + -$signed({2'd0,x0[20]})) + (-$signed({2'd0,x0[24]}) + $signed({2'd0,x0[26]})));
if(valid_pipe[1])a2_28<=mode_pipe[1]?$signed({2'd0,f1[28]}):b1_28;
end end
logic signed [6:0] coefficient2_28;
always @(posedge clk)begin if(!rst_n)coefficient2_28<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_28<=-7'sd8;
7'd4:coefficient2_28<=7'sd16;
7'd33:coefficient2_28<=7'sd32;
7'd36:coefficient2_28<=-7'sd32;
7'd37:coefficient2_28<=7'sd16;
7'd40:coefficient2_28<=7'sd16;
7'd64:coefficient2_28<=-7'sd4;
7'd80:coefficient2_28<=-7'sd1;
7'd65:coefficient2_28<=7'sd4;
7'd66:coefficient2_28<=7'sd16;
7'd82:coefficient2_28<=-7'sd1;
7'd67:coefficient2_28<=7'sd8;
7'd83:coefficient2_28<=7'sd4;
default:coefficient2_28<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_28<=0;else if(valid_pipe[2])p3_28<=$signed({{5{a2_28[9]}},a2_28})*$signed({{8{coefficient2_28[6]}},coefficient2_28});end
logic signed [9:0] b1_29,a2_29;logic signed [13:0] p3_29;
always @(posedge clk)begin if(!rst_n)begin b1_29<=0;a2_29<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_29<=(($signed({2'd0,x0[19]}) + $signed({2'd0,x0[20]})) + (-$signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})));
if(valid_pipe[1])a2_29<=mode_pipe[1]?$signed({2'd0,f1[29]}):b1_29;
end end
logic signed [5:0] coefficient2_29;
always @(posedge clk)begin if(!rst_n)coefficient2_29<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_29<=6'sd8;
7'd32:coefficient2_29<=-6'sd16;
7'd33:coefficient2_29<=6'sd8;
7'd36:coefficient2_29<=-6'sd8;
7'd37:coefficient2_29<=-6'sd8;
7'd40:coefficient2_29<=6'sd16;
7'd41:coefficient2_29<=6'sd8;
7'd64:coefficient2_29<=6'sd16;
7'd80:coefficient2_29<=-6'sd2;
7'd65:coefficient2_29<=-6'sd8;
7'd66:coefficient2_29<=6'sd2;
default:coefficient2_29<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_29<=0;else if(valid_pipe[2])p3_29<=$signed({{4{a2_29[9]}},a2_29})*$signed({{8{coefficient2_29[5]}},coefficient2_29});end
logic signed [9:0] b1_30,a2_30;logic signed [14:0] p3_30;
always @(posedge clk)begin if(!rst_n)begin b1_30<=0;a2_30<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_30<=((-$signed({2'd0,x0[19]}) + $signed({2'd0,x0[20]})) + ($signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})));
if(valid_pipe[1])a2_30<=mode_pipe[1]?$signed({2'd0,f1[30]}):b1_30;
end end
logic signed [6:0] coefficient2_30;
always @(posedge clk)begin if(!rst_n)coefficient2_30<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_30<=-7'sd8;
7'd4:coefficient2_30<=-7'sd4;
7'd32:coefficient2_30<=-7'sd16;
7'd33:coefficient2_30<=7'sd32;
7'd36:coefficient2_30<=7'sd8;
7'd37:coefficient2_30<=7'sd16;
7'd40:coefficient2_30<=7'sd32;
7'd41:coefficient2_30<=7'sd16;
7'd64:coefficient2_30<=-7'sd4;
7'd80:coefficient2_30<=-7'sd2;
7'd65:coefficient2_30<=-7'sd16;
7'd81:coefficient2_30<=7'sd2;
7'd66:coefficient2_30<=7'sd8;
7'd82:coefficient2_30<=7'sd2;
7'd67:coefficient2_30<=-7'sd8;
7'd83:coefficient2_30<=7'sd1;
default:coefficient2_30<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_30<=0;else if(valid_pipe[2])p3_30<=$signed({{5{a2_30[9]}},a2_30})*$signed({{8{coefficient2_30[6]}},coefficient2_30});end
logic signed [9:0] b1_31,a2_31;logic signed [14:0] p3_31;
always @(posedge clk)begin if(!rst_n)begin b1_31<=0;a2_31<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_31<=(($signed({2'd0,x0[19]}) + -$signed({2'd0,x0[21]})) + (-$signed({2'd0,x0[25]}) + $signed({2'd0,x0[27]})));
if(valid_pipe[1])a2_31<=mode_pipe[1]?$signed({2'd0,f1[31]}):b1_31;
end end
logic signed [6:0] coefficient2_31;
always @(posedge clk)begin if(!rst_n)coefficient2_31<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_31<=7'sd8;
7'd4:coefficient2_31<=-7'sd16;
7'd32:coefficient2_31<=-7'sd32;
7'd33:coefficient2_31<=7'sd16;
7'd36:coefficient2_31<=7'sd32;
7'd37:coefficient2_31<=-7'sd4;
7'd40:coefficient2_31<=7'sd32;
7'd41:coefficient2_31<=7'sd16;
7'd64:coefficient2_31<=7'sd8;
7'd80:coefficient2_31<=-7'sd1;
7'd65:coefficient2_31<=7'sd8;
7'd81:coefficient2_31<=7'sd4;
7'd66:coefficient2_31<=7'sd2;
7'd82:coefficient2_31<=7'sd1;
default:coefficient2_31<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_31<=0;else if(valid_pipe[2])p3_31<=$signed({{5{a2_31[9]}},a2_31})*$signed({{8{coefficient2_31[6]}},coefficient2_31});end
logic signed [8:0] b1_32,a2_32;logic signed [13:0] p3_32;
always @(posedge clk)begin if(!rst_n)begin b1_32<=0;a2_32<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_32<=($signed({1'd0,x0[24]}) + -$signed({1'd0,x0[26]}));
if(valid_pipe[1])a2_32<=mode_pipe[1]?$signed({1'd0,f1[32]}):b1_32;
end end
logic signed [6:0] coefficient2_32;
always @(posedge clk)begin if(!rst_n)coefficient2_32<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_32<=-7'sd8;
7'd4:coefficient2_32<=-7'sd2;
7'd32:coefficient2_32<=-7'sd32;
7'd33:coefficient2_32<=7'sd32;
7'd36:coefficient2_32<=-7'sd32;
7'd37:coefficient2_32<=7'sd8;
7'd40:coefficient2_32<=-7'sd16;
7'd41:coefficient2_32<=-7'sd32;
7'd64:coefficient2_32<=-7'sd8;
7'd80:coefficient2_32<=-7'sd4;
7'd65:coefficient2_32<=-7'sd16;
7'd81:coefficient2_32<=7'sd1;
7'd66:coefficient2_32<=-7'sd16;
7'd67:coefficient2_32<=7'sd16;
7'd83:coefficient2_32<=-7'sd2;
default:coefficient2_32<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_32<=0;else if(valid_pipe[2])p3_32<=$signed({{5{a2_32[8]}},a2_32})*$signed({{7{coefficient2_32[6]}},coefficient2_32});end
logic signed [9:0] b1_33,a2_33;logic signed [15:0] p3_33;
always @(posedge clk)begin if(!rst_n)begin b1_33<=0;a2_33<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_33<=($signed({2'd0,x0[25]}) + $signed({2'd0,x0[26]}));
if(valid_pipe[1])a2_33<=mode_pipe[1]?$signed({2'd0,f1[33]}):b1_33;
end end
logic signed [6:0] coefficient2_33;
always @(posedge clk)begin if(!rst_n)coefficient2_33<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_33<=7'sd16;
7'd4:coefficient2_33<=7'sd2;
7'd32:coefficient2_33<=-7'sd64;
7'd33:coefficient2_33<=7'sd32;
7'd36:coefficient2_33<=7'sd16;
7'd37:coefficient2_33<=-7'sd8;
7'd40:coefficient2_33<=-7'sd16;
7'd41:coefficient2_33<=7'sd32;
7'd64:coefficient2_33<=7'sd16;
7'd80:coefficient2_33<=7'sd2;
7'd65:coefficient2_33<=-7'sd4;
7'd81:coefficient2_33<=-7'sd1;
7'd66:coefficient2_33<=7'sd2;
7'd82:coefficient2_33<=7'sd1;
7'd67:coefficient2_33<=7'sd2;
default:coefficient2_33<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_33<=0;else if(valid_pipe[2])p3_33<=$signed({{6{a2_33[9]}},a2_33})*$signed({{9{coefficient2_33[6]}},coefficient2_33});end
logic signed [8:0] b1_34,a2_34;logic signed [13:0] p3_34;
always @(posedge clk)begin if(!rst_n)begin b1_34<=0;a2_34<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_34<=(-$signed({1'd0,x0[25]}) + $signed({1'd0,x0[26]}));
if(valid_pipe[1])a2_34<=mode_pipe[1]?$signed({1'd0,f1[34]}):b1_34;
end end
logic signed [6:0] coefficient2_34;
always @(posedge clk)begin if(!rst_n)coefficient2_34<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_34<=-7'sd8;
7'd4:coefficient2_34<=-7'sd8;
7'd32:coefficient2_34<=-7'sd32;
7'd33:coefficient2_34<=7'sd32;
7'd36:coefficient2_34<=7'sd16;
7'd37:coefficient2_34<=-7'sd4;
7'd40:coefficient2_34<=7'sd32;
7'd41:coefficient2_34<=-7'sd1;
7'd64:coefficient2_34<=7'sd4;
7'd80:coefficient2_34<=7'sd1;
7'd65:coefficient2_34<=7'sd8;
7'd81:coefficient2_34<=7'sd4;
7'd66:coefficient2_34<=-7'sd8;
7'd82:coefficient2_34<=-7'sd2;
7'd67:coefficient2_34<=7'sd16;
7'd83:coefficient2_34<=7'sd1;
default:coefficient2_34<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_34<=0;else if(valid_pipe[2])p3_34<=$signed({{5{a2_34[8]}},a2_34})*$signed({{7{coefficient2_34[6]}},coefficient2_34});end
logic signed [8:0] b1_35,a2_35;logic signed [14:0] p3_35;
always @(posedge clk)begin if(!rst_n)begin b1_35<=0;a2_35<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_35<=($signed({1'd0,x0[25]}) + -$signed({1'd0,x0[27]}));
if(valid_pipe[1])a2_35<=mode_pipe[1]?$signed({1'd0,f1[35]}):b1_35;
end end
logic signed [7:0] coefficient2_35;
always @(posedge clk)begin if(!rst_n)coefficient2_35<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_35<=8'sd16;
7'd4:coefficient2_35<=-8'sd4;
7'd32:coefficient2_35<=-8'sd64;
7'd33:coefficient2_35<=8'sd32;
7'd36:coefficient2_35<=8'sd64;
7'd37:coefficient2_35<=-8'sd16;
7'd40:coefficient2_35<=8'sd32;
7'd41:coefficient2_35<=8'sd64;
7'd64:coefficient2_35<=-8'sd4;
7'd80:coefficient2_35<=-8'sd1;
7'd65:coefficient2_35<=-8'sd8;
7'd81:coefficient2_35<=-8'sd4;
7'd66:coefficient2_35<=8'sd16;
7'd82:coefficient2_35<=8'sd1;
default:coefficient2_35<=8'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_35<=0;else if(valid_pipe[2])p3_35<=$signed({{6{a2_35[8]}},a2_35})*$signed({{7{coefficient2_35[7]}},coefficient2_35});end
logic signed [9:0] b1_36,a2_36;logic signed [14:0] p3_36;
always @(posedge clk)begin if(!rst_n)begin b1_36<=0;a2_36<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_36<=((-$signed({2'd0,x0[24]}) + $signed({2'd0,x0[26]})) + ($signed({2'd0,x0[30]}) + -$signed({2'd0,x0[32]})));
if(valid_pipe[1])a2_36<=mode_pipe[1]?$signed({2'd0,f1[36]}):b1_36;
end end
logic signed [5:0] coefficient2_36;
always @(posedge clk)begin if(!rst_n)coefficient2_36<=0;else if(valid_pipe[1])begin case(key1)
7'd4:coefficient2_36<=-6'sd16;
7'd32:coefficient2_36<=-6'sd32;
7'd33:coefficient2_36<=6'sd16;
7'd37:coefficient2_36<=-6'sd4;
7'd40:coefficient2_36<=-6'sd32;
7'd41:coefficient2_36<=-6'sd32;
7'd64:coefficient2_36<=-6'sd8;
7'd80:coefficient2_36<=-6'sd2;
7'd65:coefficient2_36<=-6'sd4;
7'd81:coefficient2_36<=-6'sd1;
7'd66:coefficient2_36<=-6'sd8;
7'd82:coefficient2_36<=-6'sd4;
7'd67:coefficient2_36<=-6'sd4;
7'd83:coefficient2_36<=-6'sd2;
default:coefficient2_36<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_36<=0;else if(valid_pipe[2])p3_36<=$signed({{5{a2_36[9]}},a2_36})*$signed({{9{coefficient2_36[5]}},coefficient2_36});end
logic signed [9:0] b1_37,a2_37;logic signed [14:0] p3_37;
always @(posedge clk)begin if(!rst_n)begin b1_37<=0;a2_37<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_37<=((-$signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})) + ($signed({2'd0,x0[31]}) + $signed({2'd0,x0[32]})));
if(valid_pipe[1])a2_37<=mode_pipe[1]?$signed({2'd0,f1[37]}):b1_37;
end end
logic signed [6:0] coefficient2_37;
always @(posedge clk)begin if(!rst_n)coefficient2_37<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_37<=7'sd8;
7'd4:coefficient2_37<=7'sd2;
7'd32:coefficient2_37<=-7'sd32;
7'd33:coefficient2_37<=7'sd16;
7'd36:coefficient2_37<=7'sd32;
7'd37:coefficient2_37<=7'sd1;
7'd40:coefficient2_37<=-7'sd32;
7'd41:coefficient2_37<=7'sd16;
7'd64:coefficient2_37<=-7'sd8;
7'd80:coefficient2_37<=7'sd1;
7'd66:coefficient2_37<=7'sd16;
7'd67:coefficient2_37<=-7'sd2;
default:coefficient2_37<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_37<=0;else if(valid_pipe[2])p3_37<=$signed({{5{a2_37[9]}},a2_37})*$signed({{8{coefficient2_37[6]}},coefficient2_37});end
logic signed [9:0] b1_38,a2_38;logic signed [14:0] p3_38;
always @(posedge clk)begin if(!rst_n)begin b1_38<=0;a2_38<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_38<=(($signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})) + (-$signed({2'd0,x0[31]}) + $signed({2'd0,x0[32]})));
if(valid_pipe[1])a2_38<=mode_pipe[1]?$signed({2'd0,f1[38]}):b1_38;
end end
logic signed [5:0] coefficient2_38;
always @(posedge clk)begin if(!rst_n)coefficient2_38<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_38<=-6'sd2;
7'd4:coefficient2_38<=-6'sd2;
7'd32:coefficient2_38<=-6'sd32;
7'd33:coefficient2_38<=6'sd4;
7'd36:coefficient2_38<=6'sd8;
7'd37:coefficient2_38<=-6'sd16;
7'd41:coefficient2_38<=-6'sd16;
7'd64:coefficient2_38<=-6'sd8;
7'd80:coefficient2_38<=-6'sd4;
7'd65:coefficient2_38<=6'sd8;
7'd81:coefficient2_38<=6'sd2;
7'd66:coefficient2_38<=-6'sd8;
7'd82:coefficient2_38<=-6'sd1;
7'd67:coefficient2_38<=6'sd4;
default:coefficient2_38<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_38<=0;else if(valid_pipe[2])p3_38<=$signed({{5{a2_38[9]}},a2_38})*$signed({{9{coefficient2_38[5]}},coefficient2_38});end
logic signed [9:0] b1_39,a2_39;logic signed [14:0] p3_39;
always @(posedge clk)begin if(!rst_n)begin b1_39<=0;a2_39<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_39<=((-$signed({2'd0,x0[25]}) + $signed({2'd0,x0[27]})) + ($signed({2'd0,x0[31]}) + -$signed({2'd0,x0[33]})));
if(valid_pipe[1])a2_39<=mode_pipe[1]?$signed({2'd0,f1[39]}):b1_39;
end end
logic signed [6:0] coefficient2_39;
always @(posedge clk)begin if(!rst_n)coefficient2_39<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_39<=7'sd8;
7'd4:coefficient2_39<=7'sd16;
7'd32:coefficient2_39<=-7'sd32;
7'd33:coefficient2_39<=7'sd4;
7'd36:coefficient2_39<=7'sd32;
7'd37:coefficient2_39<=-7'sd16;
7'd41:coefficient2_39<=7'sd32;
7'd64:coefficient2_39<=-7'sd16;
7'd65:coefficient2_39<=7'sd8;
7'd81:coefficient2_39<=7'sd2;
7'd66:coefficient2_39<=7'sd8;
7'd82:coefficient2_39<=7'sd2;
7'd67:coefficient2_39<=-7'sd8;
7'd83:coefficient2_39<=-7'sd2;
default:coefficient2_39<=7'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_39<=0;else if(valid_pipe[2])p3_39<=$signed({{5{a2_39[9]}},a2_39})*$signed({{8{coefficient2_39[6]}},coefficient2_39});end
logic signed [9:0] b1_40,a2_40;logic signed [13:0] p3_40;
always @(posedge clk)begin if(!rst_n)begin b1_40<=0;a2_40<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_40<=(($signed({2'd0,x0[21]}) + -$signed({2'd0,x0[22]})) + (-$signed({2'd0,x0[27]}) + $signed({2'd0,x0[28]})));
if(valid_pipe[1])a2_40<=mode_pipe[1]?$signed({2'd0,f1[40]}):b1_40;
end end
logic signed [5:0] coefficient2_40;
always @(posedge clk)begin if(!rst_n)coefficient2_40<=0;else if(valid_pipe[1])begin case(key1)
7'd4:coefficient2_40<=-6'sd2;
7'd32:coefficient2_40<=6'sd16;
7'd33:coefficient2_40<=-6'sd8;
7'd36:coefficient2_40<=-6'sd2;
7'd40:coefficient2_40<=6'sd2;
7'd41:coefficient2_40<=6'sd8;
7'd64:coefficient2_40<=-6'sd4;
7'd65:coefficient2_40<=6'sd8;
7'd81:coefficient2_40<=6'sd2;
7'd66:coefficient2_40<=6'sd16;
7'd82:coefficient2_40<=-6'sd2;
7'd67:coefficient2_40<=-6'sd8;
7'd83:coefficient2_40<=6'sd1;
default:coefficient2_40<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_40<=0;else if(valid_pipe[2])p3_40<=$signed({{4{a2_40[9]}},a2_40})*$signed({{8{coefficient2_40[5]}},coefficient2_40});end
logic signed [8:0] b1_41,a2_41;logic signed [13:0] p3_41;
always @(posedge clk)begin if(!rst_n)begin b1_41<=0;a2_41<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_41<=($signed({1'd0,x0[22]}) + -$signed({1'd0,x0[28]}));
if(valid_pipe[1])a2_41<=mode_pipe[1]?$signed({1'd0,f1[41]}):b1_41;
end end
logic signed [5:0] coefficient2_41;
always @(posedge clk)begin if(!rst_n)coefficient2_41<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_41<=6'sd8;
7'd4:coefficient2_41<=-6'sd8;
7'd32:coefficient2_41<=6'sd16;
7'd33:coefficient2_41<=-6'sd32;
7'd36:coefficient2_41<=-6'sd8;
7'd37:coefficient2_41<=-6'sd8;
7'd40:coefficient2_41<=6'sd16;
7'd41:coefficient2_41<=6'sd16;
7'd64:coefficient2_41<=6'sd8;
7'd65:coefficient2_41<=6'sd8;
7'd81:coefficient2_41<=6'sd2;
7'd66:coefficient2_41<=6'sd8;
7'd82:coefficient2_41<=6'sd2;
7'd67:coefficient2_41<=6'sd8;
7'd83:coefficient2_41<=6'sd1;
default:coefficient2_41<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_41<=0;else if(valid_pipe[2])p3_41<=$signed({{5{a2_41[8]}},a2_41})*$signed({{8{coefficient2_41[5]}},coefficient2_41});end
logic signed [9:0] b1_42,a2_42;logic signed [13:0] p3_42;
always @(posedge clk)begin if(!rst_n)begin b1_42<=0;a2_42<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_42<=((-$signed({2'd0,x0[22]}) + $signed({2'd0,x0[23]})) + ($signed({2'd0,x0[28]}) + -$signed({2'd0,x0[29]})));
if(valid_pipe[1])a2_42<=mode_pipe[1]?$signed({2'd0,f1[42]}):b1_42;
end end
logic signed [5:0] coefficient2_42;
always @(posedge clk)begin if(!rst_n)coefficient2_42<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_42<=6'sd8;
7'd4:coefficient2_42<=-6'sd4;
7'd33:coefficient2_42<=-6'sd16;
7'd36:coefficient2_42<=-6'sd4;
7'd37:coefficient2_42<=-6'sd8;
7'd40:coefficient2_42<=6'sd8;
7'd41:coefficient2_42<=6'sd8;
7'd64:coefficient2_42<=6'sd16;
7'd80:coefficient2_42<=6'sd2;
7'd65:coefficient2_42<=6'sd16;
7'd81:coefficient2_42<=-6'sd1;
7'd67:coefficient2_42<=-6'sd8;
7'd83:coefficient2_42<=6'sd1;
default:coefficient2_42<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_42<=0;else if(valid_pipe[2])p3_42<=$signed({{4{a2_42[9]}},a2_42})*$signed({{8{coefficient2_42[5]}},coefficient2_42});end
logic signed [8:0] b1_43,a2_43;logic signed [12:0] p3_43;
always @(posedge clk)begin if(!rst_n)begin b1_43<=0;a2_43<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_43<=($signed({1'd0,x0[27]}) + -$signed({1'd0,x0[28]}));
if(valid_pipe[1])a2_43<=mode_pipe[1]?$signed({1'd0,f1[43]}):b1_43;
end end
logic signed [5:0] coefficient2_43;
always @(posedge clk)begin if(!rst_n)coefficient2_43<=0;else if(valid_pipe[1])begin case(key1)
7'd4:coefficient2_43<=-6'sd4;
7'd32:coefficient2_43<=6'sd16;
7'd33:coefficient2_43<=-6'sd4;
7'd36:coefficient2_43<=6'sd2;
7'd40:coefficient2_43<=6'sd4;
7'd41:coefficient2_43<=6'sd16;
7'd64:coefficient2_43<=-6'sd16;
7'd80:coefficient2_43<=-6'sd2;
7'd65:coefficient2_43<=6'sd16;
7'd66:coefficient2_43<=-6'sd8;
7'd82:coefficient2_43<=-6'sd2;
7'd67:coefficient2_43<=6'sd8;
7'd83:coefficient2_43<=6'sd2;
default:coefficient2_43<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_43<=0;else if(valid_pipe[2])p3_43<=$signed({{4{a2_43[8]}},a2_43})*$signed({{7{coefficient2_43[5]}},coefficient2_43});end
logic signed [8:0] b1_44,a2_44;logic signed [13:0] p3_44;
always @(posedge clk)begin if(!rst_n)begin b1_44<=0;a2_44<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_44<=$signed({1'd0,x0[28]});
if(valid_pipe[1])a2_44<=mode_pipe[1]?$signed({1'd0,f1[44]}):b1_44;
end end
logic signed [5:0] coefficient2_44;
always @(posedge clk)begin if(!rst_n)coefficient2_44<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_44<=6'sd16;
7'd4:coefficient2_44<=-6'sd2;
7'd32:coefficient2_44<=6'sd16;
7'd33:coefficient2_44<=-6'sd32;
7'd36:coefficient2_44<=-6'sd4;
7'd37:coefficient2_44<=6'sd4;
7'd40:coefficient2_44<=6'sd8;
7'd41:coefficient2_44<=6'sd16;
7'd64:coefficient2_44<=6'sd4;
7'd80:coefficient2_44<=6'sd1;
7'd66:coefficient2_44<=6'sd8;
7'd82:coefficient2_44<=6'sd1;
default:coefficient2_44<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_44<=0;else if(valid_pipe[2])p3_44<=$signed({{5{a2_44[8]}},a2_44})*$signed({{8{coefficient2_44[5]}},coefficient2_44});end
logic signed [8:0] b1_45,a2_45;logic signed [13:0] p3_45;
always @(posedge clk)begin if(!rst_n)begin b1_45<=0;a2_45<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_45<=(-$signed({1'd0,x0[28]}) + $signed({1'd0,x0[29]}));
if(valid_pipe[1])a2_45<=mode_pipe[1]?$signed({1'd0,f1[45]}):b1_45;
end end
logic signed [5:0] coefficient2_45;
always @(posedge clk)begin if(!rst_n)coefficient2_45<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_45<=6'sd16;
7'd4:coefficient2_45<=6'sd2;
7'd33:coefficient2_45<=-6'sd32;
7'd36:coefficient2_45<=-6'sd8;
7'd37:coefficient2_45<=6'sd4;
7'd40:coefficient2_45<=6'sd4;
7'd41:coefficient2_45<=6'sd1;
7'd64:coefficient2_45<=6'sd4;
7'd80:coefficient2_45<=6'sd1;
7'd67:coefficient2_45<=-6'sd8;
7'd83:coefficient2_45<=-6'sd4;
default:coefficient2_45<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_45<=0;else if(valid_pipe[2])p3_45<=$signed({{5{a2_45[8]}},a2_45})*$signed({{8{coefficient2_45[5]}},coefficient2_45});end
logic signed [9:0] b1_46,a2_46;logic signed [13:0] p3_46;
always @(posedge clk)begin if(!rst_n)begin b1_46<=0;a2_46<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_46<=((-$signed({2'd0,x0[27]}) + $signed({2'd0,x0[28]})) + ($signed({2'd0,x0[33]}) + -$signed({2'd0,x0[34]})));
if(valid_pipe[1])a2_46<=mode_pipe[1]?$signed({2'd0,f1[46]}):b1_46;
end end
logic signed [5:0] coefficient2_46;
always @(posedge clk)begin if(!rst_n)coefficient2_46<=0;else if(valid_pipe[1])begin case(key1)
7'd4:coefficient2_46<=-6'sd2;
7'd33:coefficient2_46<=6'sd2;
7'd36:coefficient2_46<=6'sd4;
7'd40:coefficient2_46<=6'sd2;
7'd41:coefficient2_46<=6'sd16;
7'd64:coefficient2_46<=-6'sd4;
7'd80:coefficient2_46<=-6'sd1;
7'd65:coefficient2_46<=6'sd8;
7'd81:coefficient2_46<=-6'sd1;
7'd66:coefficient2_46<=-6'sd4;
7'd82:coefficient2_46<=-6'sd1;
7'd67:coefficient2_46<=6'sd4;
7'd83:coefficient2_46<=6'sd2;
default:coefficient2_46<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_46<=0;else if(valid_pipe[2])p3_46<=$signed({{4{a2_46[9]}},a2_46})*$signed({{8{coefficient2_46[5]}},coefficient2_46});end
logic signed [8:0] b1_47,a2_47;logic signed [12:0] p3_47;
always @(posedge clk)begin if(!rst_n)begin b1_47<=0;a2_47<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_47<=(-$signed({1'd0,x0[28]}) + $signed({1'd0,x0[34]}));
if(valid_pipe[1])a2_47<=mode_pipe[1]?$signed({1'd0,f1[47]}):b1_47;
end end
logic signed [5:0] coefficient2_47;
always @(posedge clk)begin if(!rst_n)coefficient2_47<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_47<=6'sd4;
7'd4:coefficient2_47<=6'sd4;
7'd33:coefficient2_47<=-6'sd16;
7'd36:coefficient2_47<=6'sd2;
7'd37:coefficient2_47<=6'sd16;
7'd40:coefficient2_47<=-6'sd4;
7'd41:coefficient2_47<=6'sd2;
7'd64:coefficient2_47<=-6'sd16;
7'd80:coefficient2_47<=6'sd2;
7'd65:coefficient2_47<=6'sd4;
7'd66:coefficient2_47<=6'sd8;
7'd82:coefficient2_47<=6'sd4;
7'd67:coefficient2_47<=6'sd16;
7'd83:coefficient2_47<=6'sd1;
default:coefficient2_47<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_47<=0;else if(valid_pipe[2])p3_47<=$signed({{4{a2_47[8]}},a2_47})*$signed({{7{coefficient2_47[5]}},coefficient2_47});end
logic signed [9:0] b1_48,a2_48;logic signed [13:0] p3_48;
always @(posedge clk)begin if(!rst_n)begin b1_48<=0;a2_48<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_48<=(($signed({2'd0,x0[28]}) + -$signed({2'd0,x0[29]})) + (-$signed({2'd0,x0[34]}) + $signed({2'd0,x0[35]})));
if(valid_pipe[1])a2_48<=mode_pipe[1]?0:b1_48;
end end
logic signed [5:0] coefficient2_48;
always @(posedge clk)begin if(!rst_n)coefficient2_48<=0;else if(valid_pipe[1])begin case(key1)
7'd0:coefficient2_48<=6'sd4;
7'd4:coefficient2_48<=6'sd8;
7'd33:coefficient2_48<=-6'sd16;
7'd36:coefficient2_48<=-6'sd4;
7'd37:coefficient2_48<=6'sd16;
7'd40:coefficient2_48<=-6'sd8;
7'd41:coefficient2_48<=-6'sd8;
default:coefficient2_48<=6'sd0;endcase end end
always @(posedge clk)begin if(!rst_n)p3_48<=0;else if(valid_pipe[2])p3_48<=$signed({{4{a2_48[9]}},a2_48})*$signed({{8{coefficient2_48[5]}},coefficient2_48});end
logic signed [17:0] h_0_0_0;
logic signed [17:0] h_0_0_1;
logic signed [17:0] h_0_1_0;
logic signed [17:0] h_0_1_1;
logic signed [17:0] h_0_2_0;
logic signed [17:0] h_0_2_1;
logic signed [17:0] h_0_3_0;
logic signed [17:0] h_0_3_1;
logic signed [15:0] h_1_0_0;
logic signed [15:0] h_1_0_1;
logic signed [15:0] h_1_1_0;
logic signed [15:0] h_1_1_1;
logic signed [15:0] h_1_2_0;
logic signed [15:0] h_1_2_1;
logic signed [15:0] h_1_3_0;
logic signed [15:0] h_1_3_1;
logic signed [16:0] h_2_0_0;
logic signed [16:0] h_2_0_1;
logic signed [16:0] h_2_1_0;
logic signed [16:0] h_2_1_1;
logic signed [16:0] h_2_2_0;
logic signed [16:0] h_2_2_1;
logic signed [14:0] h_3_0_0;
logic signed [14:0] h_3_0_1;
logic signed [14:0] h_3_1_0;
logic signed [14:0] h_3_1_1;
logic signed [14:0] h_3_2_0;
logic signed [14:0] h_3_2_1;
logic signed [19:0] z_0_0;
logic signed [18:0] z_0_1;
logic signed [18:0] z_0_2;
logic signed [18:0] z_0_3;
logic signed [17:0] z_1_0;
logic signed [17:0] z_1_1;
logic signed [17:0] z_1_2;
logic signed [17:0] z_1_3;
logic signed [17:0] z_2_0;
logic signed [17:0] z_2_1;
logic signed [17:0] z_2_2;
logic signed [17:0] z_2_3;
logic signed [15:0] z_3_0;
logic signed [15:0] z_3_1;
logic signed [15:0] z_3_2;
logic signed [15:0] z_3_3;
logic signed [13:0] fg4_0;
logic signed [14:0] fg4_1;
logic signed [14:0] fg4_2;
logic signed [14:0] fg4_3;
logic signed [14:0] fg4_4;
logic signed [13:0] fg4_5;
logic signed [14:0] fg4_6;
logic signed [14:0] fg4_7;
logic signed [13:0] fg4_8;
logic signed [14:0] fg4_9;
logic signed [14:0] fg4_10;
logic signed [14:0] fg4_11;
logic signed [13:0] fg4_12;
logic signed [13:0] fg4_13;
logic signed [14:0] fg4_14;
logic signed [13:0] fg4_15;
logic signed [16:0] fg5_0;
logic signed [15:0] fg5_1;
logic signed [16:0] fg5_2;
logic signed [15:0] fg5_3;
always @(posedge clk)begin if(!rst_n)begin
h_0_0_0<=0;
h_0_0_1<=0;
h_0_1_0<=0;
h_0_1_1<=0;
h_0_2_0<=0;
h_0_2_1<=0;
h_0_3_0<=0;
h_0_3_1<=0;
h_1_0_0<=0;
h_1_0_1<=0;
h_1_1_0<=0;
h_1_1_1<=0;
h_1_2_0<=0;
h_1_2_1<=0;
h_1_3_0<=0;
h_1_3_1<=0;
h_2_0_0<=0;
h_2_0_1<=0;
h_2_1_0<=0;
h_2_1_1<=0;
h_2_2_0<=0;
h_2_2_1<=0;
h_3_0_0<=0;
h_3_0_1<=0;
h_3_1_0<=0;
h_3_1_1<=0;
h_3_2_0<=0;
h_3_2_1<=0;
fg4_0<=0;
fg4_1<=0;
fg4_2<=0;
fg4_3<=0;
fg4_4<=0;
fg4_5<=0;
fg4_6<=0;
fg4_7<=0;
fg4_8<=0;
fg4_9<=0;
fg4_10<=0;
fg4_11<=0;
fg4_12<=0;
fg4_13<=0;
fg4_14<=0;
fg4_15<=0;
end else if(valid_pipe[3])begin if(!mode_pipe[3])begin
h_0_0_0<=($signed({{2{p3_0[15]}},p3_0}) + ($signed({{2{p3_1[15]}},p3_1}) + $signed({{2{p3_2[15]}},p3_2})));
h_0_0_1<=($signed({{2{p3_1[15]}},p3_1}) + (-$signed({{2{p3_2[15]}},p3_2}) + -$signed({{3{p3_3[14]}},p3_3})));
h_0_1_0<=($signed({{2{p3_4[15]}},p3_4}) + ($signed({{2{p3_5[15]}},p3_5}) + $signed({{3{p3_6[14]}},p3_6})));
h_0_1_1<=($signed({{2{p3_5[15]}},p3_5}) + (-$signed({{3{p3_6[14]}},p3_6}) + -$signed({{2{p3_7[15]}},p3_7})));
h_0_2_0<=($signed({{2{p3_8[15]}},p3_8}) + ($signed({{2{p3_9[15]}},p3_9}) + $signed({{2{p3_10[15]}},p3_10})));
h_0_2_1<=($signed({{2{p3_9[15]}},p3_9}) + (-$signed({{2{p3_10[15]}},p3_10}) + -$signed({{3{p3_11[14]}},p3_11})));
h_0_3_0<=($signed({{2{p3_12[15]}},p3_12}) + ($signed({{3{p3_13[14]}},p3_13}) + $signed({{2{p3_14[15]}},p3_14})));
h_0_3_1<=($signed({{3{p3_13[14]}},p3_13}) + (-$signed({{2{p3_14[15]}},p3_14}) + -$signed({{2{p3_15[15]}},p3_15})));
h_1_0_0<=($signed({{1{p3_16[14]}},p3_16}) + $signed({{1{p3_17[14]}},p3_17}));
h_1_0_1<=($signed({{1{p3_17[14]}},p3_17}) + $signed({{1{p3_18[14]}},p3_18}));
h_1_1_0<=($signed({{1{p3_19[14]}},p3_19}) + $signed({{1{p3_20[14]}},p3_20}));
h_1_1_1<=($signed({{1{p3_20[14]}},p3_20}) + $signed({{1{p3_21[14]}},p3_21}));
h_1_2_0<=($signed({{1{p3_22[14]}},p3_22}) + $signed({{1{p3_23[14]}},p3_23}));
h_1_2_1<=($signed({{1{p3_23[14]}},p3_23}) + $signed({{1{p3_24[14]}},p3_24}));
h_1_3_0<=($signed({{1{p3_25[14]}},p3_25}) + $signed({{1{p3_26[14]}},p3_26}));
h_1_3_1<=($signed({{1{p3_26[14]}},p3_26}) + $signed({{2{p3_27[13]}},p3_27}));
h_2_0_0<=($signed({{2{p3_28[14]}},p3_28}) + ($signed({{3{p3_29[13]}},p3_29}) + $signed({{2{p3_30[14]}},p3_30})));
h_2_0_1<=($signed({{3{p3_29[13]}},p3_29}) + (-$signed({{2{p3_30[14]}},p3_30}) + -$signed({{2{p3_31[14]}},p3_31})));
h_2_1_0<=($signed({{3{p3_32[13]}},p3_32}) + ($signed({{1{p3_33[15]}},p3_33}) + $signed({{3{p3_34[13]}},p3_34})));
h_2_1_1<=($signed({{1{p3_33[15]}},p3_33}) + (-$signed({{3{p3_34[13]}},p3_34}) + -$signed({{2{p3_35[14]}},p3_35})));
h_2_2_0<=($signed({{2{p3_36[14]}},p3_36}) + ($signed({{2{p3_37[14]}},p3_37}) + $signed({{2{p3_38[14]}},p3_38})));
h_2_2_1<=($signed({{2{p3_37[14]}},p3_37}) + (-$signed({{2{p3_38[14]}},p3_38}) + -$signed({{2{p3_39[14]}},p3_39})));
h_3_0_0<=($signed({{1{p3_40[13]}},p3_40}) + $signed({{1{p3_41[13]}},p3_41}));
h_3_0_1<=($signed({{1{p3_41[13]}},p3_41}) + $signed({{1{p3_42[13]}},p3_42}));
h_3_1_0<=($signed({{2{p3_43[12]}},p3_43}) + $signed({{1{p3_44[13]}},p3_44}));
h_3_1_1<=($signed({{1{p3_44[13]}},p3_44}) + $signed({{1{p3_45[13]}},p3_45}));
h_3_2_0<=($signed({{1{p3_46[13]}},p3_46}) + $signed({{2{p3_47[12]}},p3_47}));
h_3_2_1<=($signed({{2{p3_47[12]}},p3_47}) + $signed({{1{p3_48[13]}},p3_48}));
end else begin
fg4_0<=($signed(p3_0[13:0]) + ($signed(p3_1[13:0]) + $signed(p3_2[13:0])));
fg4_1<=($signed(p3_3) + ($signed(p3_4[14:0]) + $signed(p3_5[14:0])));
fg4_2<=($signed(p3_6) + ($signed(p3_7[14:0]) + $signed(p3_8[14:0])));
fg4_3<=($signed(p3_9[14:0]) + ($signed(p3_10[14:0]) + $signed(p3_11)));
fg4_4<=($signed(p3_12[14:0]) + ($signed(p3_13) + $signed(p3_14[14:0])));
fg4_5<=($signed(p3_15[13:0]) + ($signed(p3_16[13:0]) + $signed(p3_17[13:0])));
fg4_6<=($signed(p3_18) + ($signed(p3_19) + $signed(p3_20)));
fg4_7<=($signed(p3_21) + ($signed(p3_22) + $signed(p3_23)));
fg4_8<=($signed(p3_24[13:0]) + ($signed(p3_25[13:0]) + $signed(p3_26[13:0])));
fg4_9<=($signed({{1{p3_27[13]}},p3_27}) + ($signed(p3_28) + $signed({{1{p3_29[13]}},p3_29})));
fg4_10<=($signed(p3_30) + ($signed(p3_31) + $signed({{1{p3_32[13]}},p3_32})));
fg4_11<=($signed(p3_33[14:0]) + ($signed({{1{p3_34[13]}},p3_34}) + $signed(p3_35)));
fg4_12<=($signed(p3_36[13:0]) + ($signed(p3_37[13:0]) + $signed(p3_38[13:0])));
fg4_13<=($signed(p3_39[13:0]) + ($signed(p3_40) + $signed(p3_41)));
fg4_14<=($signed({{1{p3_42[13]}},p3_42}) + ($signed({{2{p3_43[12]}},p3_43}) + $signed({{1{p3_44[13]}},p3_44})));
fg4_15<=($signed(p3_45) + ($signed(p3_46) + $signed({{1{p3_47[12]}},p3_47})));
end end end
always @(posedge clk)begin if(!rst_n)begin
z_0_0<=0;
z_0_1<=0;
z_0_2<=0;
z_0_3<=0;
z_1_0<=0;
z_1_1<=0;
z_1_2<=0;
z_1_3<=0;
z_2_0<=0;
z_2_1<=0;
z_2_2<=0;
z_2_3<=0;
z_3_0<=0;
z_3_1<=0;
z_3_2<=0;
z_3_3<=0;
fg5_0<=0;
fg5_1<=0;
fg5_2<=0;
fg5_3<=0;
end else if(valid_pipe[4])begin if(!mode_pipe[4])begin
z_0_0<=($signed({{2{h_0_0_0[17]}},h_0_0_0}) + ($signed({{2{h_0_1_0[17]}},h_0_1_0}) + $signed({{2{h_0_2_0[17]}},h_0_2_0})));
z_0_1<=($signed({{1{h_0_0_1[17]}},h_0_0_1}) + ($signed({{1{h_0_1_1[17]}},h_0_1_1}) + $signed({{1{h_0_2_1[17]}},h_0_2_1})));
z_0_2<=($signed({{1{h_0_1_0[17]}},h_0_1_0}) + (-$signed({{1{h_0_2_0[17]}},h_0_2_0}) + -$signed({{1{h_0_3_0[17]}},h_0_3_0})));
z_0_3<=($signed({{1{h_0_1_1[17]}},h_0_1_1}) + (-$signed({{1{h_0_2_1[17]}},h_0_2_1}) + -$signed({{1{h_0_3_1[17]}},h_0_3_1})));
z_1_0<=($signed({{2{h_1_0_0[15]}},h_1_0_0}) + ($signed({{2{h_1_1_0[15]}},h_1_1_0}) + $signed({{2{h_1_2_0[15]}},h_1_2_0})));
z_1_1<=($signed({{2{h_1_0_1[15]}},h_1_0_1}) + ($signed({{2{h_1_1_1[15]}},h_1_1_1}) + $signed({{2{h_1_2_1[15]}},h_1_2_1})));
z_1_2<=($signed({{2{h_1_1_0[15]}},h_1_1_0}) + (-$signed({{2{h_1_2_0[15]}},h_1_2_0}) + -$signed({{2{h_1_3_0[15]}},h_1_3_0})));
z_1_3<=($signed({{2{h_1_1_1[15]}},h_1_1_1}) + (-$signed({{2{h_1_2_1[15]}},h_1_2_1}) + -$signed({{2{h_1_3_1[15]}},h_1_3_1})));
z_2_0<=($signed({{1{h_2_0_0[16]}},h_2_0_0}) + $signed({{1{h_2_1_0[16]}},h_2_1_0}));
z_2_1<=($signed({{1{h_2_0_1[16]}},h_2_0_1}) + $signed({{1{h_2_1_1[16]}},h_2_1_1}));
z_2_2<=($signed({{1{h_2_1_0[16]}},h_2_1_0}) + $signed({{1{h_2_2_0[16]}},h_2_2_0}));
z_2_3<=($signed({{1{h_2_1_1[16]}},h_2_1_1}) + $signed({{1{h_2_2_1[16]}},h_2_2_1}));
z_3_0<=($signed({{1{h_3_0_0[14]}},h_3_0_0}) + $signed({{1{h_3_1_0[14]}},h_3_1_0}));
z_3_1<=($signed({{1{h_3_0_1[14]}},h_3_0_1}) + $signed({{1{h_3_1_1[14]}},h_3_1_1}));
z_3_2<=($signed({{1{h_3_1_0[14]}},h_3_1_0}) + $signed({{1{h_3_2_0[14]}},h_3_2_0}));
z_3_3<=($signed({{1{h_3_1_1[14]}},h_3_1_1}) + $signed({{1{h_3_2_1[14]}},h_3_2_1}));
end else begin
fg5_0<=(($signed({{3{fg4_0[13]}},fg4_0}) + $signed({{2{fg4_1[14]}},fg4_1})) + ($signed({{2{fg4_2[14]}},fg4_2}) + $signed({{2{fg4_3[14]}},fg4_3})));
fg5_1<=(($signed({{1{fg4_4[14]}},fg4_4}) + $signed({{2{fg4_5[13]}},fg4_5})) + ($signed({{1{fg4_6[14]}},fg4_6}) + $signed({{1{fg4_7[14]}},fg4_7})));
fg5_2<=(($signed({{3{fg4_8[13]}},fg4_8}) + $signed({{2{fg4_9[14]}},fg4_9})) + ($signed({{2{fg4_10[14]}},fg4_10}) + $signed({{2{fg4_11[14]}},fg4_11})));
fg5_3<=(($signed({{2{fg4_12[13]}},fg4_12}) + $signed({{2{fg4_13[13]}},fg4_13})) + ($signed({{1{fg4_14[14]}},fg4_14}) + $signed({{2{fg4_15[13]}},fg4_15})));
end end end
always @(posedge clk)begin if(!rst_n)begin conv_y00<=0;conv_y01<=0;conv_y10<=0;conv_y11<=0;fc_sum<=0;end
else if(valid_pipe[5])begin if(!mode_pipe[5])begin
conv_y00<=((($signed({{12{z_0_0[19]}},z_0_0}) >>> 2) + ($signed({{14{z_1_0[17]}},z_1_0}) >>> 1)) + (($signed({{14{z_2_0[17]}},z_2_0}) >>> 1) + ($signed({{16{z_3_0[15]}},z_3_0}) >>> 0)));
conv_y01<=((($signed({{13{z_0_1[18]}},z_0_1}) >>> 2) + ($signed({{14{z_1_1[17]}},z_1_1}) >>> 1)) + (($signed({{14{z_2_1[17]}},z_2_1}) >>> 1) + ($signed({{16{z_3_1[15]}},z_3_1}) >>> 0)));
conv_y10<=((($signed({{13{z_0_2[18]}},z_0_2}) >>> 2) + ($signed({{14{z_1_2[17]}},z_1_2}) >>> 1)) + (($signed({{14{z_2_2[17]}},z_2_2}) >>> 1) + ($signed({{16{z_3_2[15]}},z_3_2}) >>> 0)));
conv_y11<=((($signed({{13{z_0_3[18]}},z_0_3}) >>> 2) + ($signed({{14{z_1_3[17]}},z_1_3}) >>> 1)) + (($signed({{14{z_2_3[17]}},z_2_3}) >>> 1) + ($signed({{16{z_3_3[15]}},z_3_3}) >>> 0)));
end else begin fc_sum<=(($signed({{15{fg5_0[16]}},fg5_0}) + $signed({{16{fg5_1[15]}},fg5_1})) + ($signed({{15{fg5_2[16]}},fg5_2}) + $signed({{16{fg5_3[15]}},fg5_3})));end end end
endmodule
```

## v25_dash/examples/synthetic_only/v25h/mul/v25_dash_top.sv

```systemverilog
`timescale 1ps/1ps
// Derived from V25-H controller, commit 0d345f1. Continuous byte stream; one prime cycle after reset.
// DASH adaptation: four classes, train-derived scales, signed32 bias/score, RNE+U8 saturation.
module v25_dash_top(input logic clk,rst_n,input logic [7:0] data_in,
                   output logic [1:0] decision,output logic valid_out_6,output wire [127:0] logits);
    localparam ST_STREAM = 2'd0;
    localparam ST_FC     = 2'd1;
    localparam ST_DONE   = 2'd2;
    logic [1:0] state;

    // -------------------------------------------------------------------------
    // External input stream storage.
    // Explicit row/col/slot counters replace /28, %28 and %7 address arithmetic.
    // -------------------------------------------------------------------------
    logic [7:0] linebuf [0:6][0:27];
    logic [9:0] pixels_stored;
    logic       capture_primed;
    logic [4:0] cap_row, cap_col;
    logic [2:0] cap_slot;

    // Conv1 local 6x6 sliding window.
    // The engine sees only this register bank, not a dynamic 7x28 column mux.
    logic        [7:0]  c1_window [0:5][0:5];
    logic               c1_window_valid;
    logic [4:0]         c1_new_col;  // two entering columns for next stride-2 tile

    // Pool outputs. V6 retains only seven logical fmap1 rows at a time.
    // V25-H stores post-ReLU pooled values directly as unsigned 8-bit data.
    // Conv1 keeps two physical channels: 2 x 7 x 12 x 8 = 1344 payload bits.
    logic        [7:0] fmap1_ring [0:1][0:6][0:11];
    logic        [7:0] fmap2 [0:2][0:3][0:3];

    // -------------------------------------------------------------------------
    // Conv1 progress.
    // c1_base_slot = (2*c1_issue_pr) mod 7, maintained incrementally.
    // -------------------------------------------------------------------------
    logic [3:0] c1_issue_pr, c1_issue_pc;
    logic       c1_issue_oc;
    logic [2:0] c1_base_slot;
    logic [8:0] c1_issue_count;
    logic [8:0] c1_commit_count;

    // Conv1 writeback pipeline. WB0 registers the four quantized values; the
    // following cycle performs only 4-way max/ReLU and commits to fmap1_ring.
    logic c1_wb_valid;
    logic [2:0] c1_wb_slot;
    logic [3:0] c1_wb_pc;
    logic       c1_wb_oc;
    logic signed [11:0] c1_wb_q00, c1_wb_q01, c1_wb_q10, c1_wb_q11;

    // Conv2 progress.
    logic [1:0] c2_issue_pr, c2_issue_pc;
    logic [1:0] c2_issue_oc;
    logic       c2_issue_ic;
    // Physical ring slot corresponding to logical Conv2 window start row
    // (2*c2_issue_pr) mod 7. Updated only when Conv2 advances to next row.
    logic [2:0] c2_base_slot;
    logic [7:0] c2_issue_count;
    logic [7:0] c2_rsp_count;
    logic signed [31:0] c2_acc00, c2_acc01, c2_acc10, c2_acc11;

    // Conv2 writeback pipeline. the prior critical path ran directly from the
    // engine output register through final channel accumulation, quantization,
    // max-pool/ReLU and into fmap2. V4 cuts that cone into three short stages.
    logic c2_wb0_valid, c2_wb1_valid;
    logic [1:0] c2_wb0_pr, c2_wb0_pc, c2_wb0_oc;
    logic [1:0] c2_wb1_pr, c2_wb1_pc, c2_wb1_oc;
    logic signed [31:0] c2_wb0_sum00, c2_wb0_sum01, c2_wb0_sum10, c2_wb0_sum11;
    logic signed [11:0] c2_wb1_q00, c2_wb1_q01, c2_wb1_q10, c2_wb1_q11;
    logic [5:0] c2_commit_count;

    // FC progress: two temporal PoT1 requests per class implement SP2 exactly.
    logic [3:0] fc_issue_class;
    logic [4:0] fc_issue_count;
    logic       fc_issue_term;
    logic signed [31:0] fc_term0_sum;
    logic signed [31:0] best_score;
    logic [3:0] best_idx;

    // -------------------------------------------------------------------------
    // Helpers.
    // -------------------------------------------------------------------------
    localparam integer C1_RESTORE_SHIFT=0,C2_RESTORE_SHIFT=0;
    localparam integer FC_TWO_PASS=1;
function automatic signed [31:0] get_b1(input integer idx);begin case(idx)
0:get_b1=32'sd0;
1:get_b1=32'sd0;
default:get_b1=0;endcase end endfunction
function automatic signed [31:0] get_b2(input integer idx);begin case(idx)
0:get_b2=32'sd0;
1:get_b2=32'sd0;
2:get_b2=32'sd0;
default:get_b2=0;endcase end endfunction
function automatic signed [31:0] get_fcb(input integer idx);begin case(idx)
0:get_fcb=32'sd0;
1:get_fcb=32'sd0;
2:get_fcb=32'sd0;
3:get_fcb=32'sd0;
default:get_fcb=0;endcase end endfunction
function automatic [7:0] quant_u8(input signed [31:0] raw,input integer shift);
reg signed [63:0] base,rem,half;begin base=$signed(raw)>>>shift;
if(shift>0)begin rem=$signed(raw)-(base<<<shift);half=64'sd1<<<(shift-1);
if(rem>half||(rem==half&&base[0]))base=base+1;end
if(base<0)quant_u8=0;else if(base>255)quant_u8=255;else quant_u8=base[7:0];end endfunction
function automatic signed [11:0] conv1_q(input signed [31:0] raw,bias32);begin conv1_q={4'd0,quant_u8(raw+bias32,4)};end endfunction
function automatic signed [11:0] conv2_q(input signed [31:0] raw,bias32);begin conv2_q={4'd0,quant_u8(raw+bias32,6)};end endfunction
function automatic [7:0] max4_relu_a8(input signed [11:0] a,b,c,d);reg signed [11:0] m;begin
m=a;if(b>m)m=b;if(c>m)m=c;if(d>m)m=d;max4_relu_a8=m[7:0];end endfunction
logic signed [31:0] scores[0:3];integer score_clear;
assign logits={scores[3],scores[2],scores[1],scores[0]};
    function automatic [2:0] add_mod7(
        input logic [2:0] base,
        input integer off
    );
        integer tmp;
        begin
            tmp = base + off;
            if (tmp >= 7) tmp = tmp - 7;
            add_mod7 = tmp[2:0];
        end
    endfunction

    // -------------------------------------------------------------------------
    // Shared V6 engine.
    // -------------------------------------------------------------------------
    logic req_valid, req_is_fc;
    logic [15:0] req_tag;
    logic signed [8:0] req_tile [0:5][0:5];
    logic signed [8:0] req_fc_a [0:47];

    logic rsp_valid, rsp_is_fc;
    logic [15:0] rsp_tag;
    logic signed [31:0] rsp_y00, rsp_y01, rsp_y10, rsp_y11;
    logic signed [31:0] rsp_fc_sum;

    v25_dash_engine u_engine (
        .clk(clk), .rst_n(rst_n),
        .req_valid(req_valid), .req_is_fc(req_is_fc), .req_tag(req_tag),
        .conv_tile(req_tile), .fc_a(req_fc_a),
        .rsp_valid(rsp_valid), .rsp_is_fc(rsp_is_fc), .rsp_tag(rsp_tag),
        .conv_y00(rsp_y00), .conv_y01(rsp_y01),
        .conv_y10(rsp_y10), .conv_y11(rsp_y11),
        .fc_sum(rsp_fc_sum)
    );

    // -------------------------------------------------------------------------
    // Dependency checks.
    // -------------------------------------------------------------------------
    logic c1_tile_ready;
    integer c2_required_commit_idx;
    logic c2_data_ready;

    always_comb begin
        // V6 issues Conv1 only from the local sliding window. The row-start
        // window becomes valid on the same capture edge that makes V6's first
        // tile ready; subsequent horizontal tiles are shifted in-place.
        c1_tile_ready = (c1_issue_count < 9'd288) && c1_window_valid;

        // fmap1 is produced row-major, col-major, then two physical channels.
        // Physical ic0/ic1 map to original Conv1 channels 1/2.
        c2_required_commit_idx = (((c2_issue_pr*2 + 5) * 12
                                 + (c2_issue_pc*2 + 5)) * 2
                                 + c2_issue_ic);
        c2_data_ready = (c2_issue_count < 8'd96)
                     && (c1_commit_count > c2_required_commit_idx);
    end

    // -------------------------------------------------------------------------
    // Dependency-aware request scheduler.
    // Conv1 gets priority so the 7-line input buffer safety proof remains the
    // same as V2. Conv2 uses only otherwise-idle Conv1 cycles until C1 finishes.
    // -------------------------------------------------------------------------
    integer rr, cc, kk, lane, ch, pos;
    logic issue_c1, issue_c2;
    always_comb begin
        req_valid = 1'b0;
        req_is_fc = 1'b0;
        req_tag   = 16'd0;
        issue_c1  = 1'b0;
        issue_c2  = 1'b0;
        kk = 0;
        ch = 0;
        pos = 0;

        for (rr = 0; rr < 6; rr = rr + 1)
            for (cc = 0; cc < 6; cc = cc + 1)
                req_tile[rr][cc] = 9'sd0;

        for (lane = 0; lane < 48; lane = lane + 1) begin
            req_fc_a[lane] = 9'sd0;
        end

        if (state == ST_STREAM) begin
            if (c1_tile_ready) begin
                issue_c1 = 1'b1;
                req_valid = 1'b1;
                req_is_fc = 1'b0;
                req_tag = {1'b0, 3'b000, c1_issue_pr, c1_issue_pc, 1'b0, c1_issue_oc, 2'b00};

                // Fixed/local wiring: no c1_issue_pc-driven 28-column mux.
                for (rr = 0; rr < 6; rr = rr + 1)
                    for (cc = 0; cc < 6; cc = cc + 1)
                        req_tile[rr][cc] = {1'b0,c1_window[rr][cc]};
            end else if (c2_data_ready) begin
                issue_c2 = 1'b1;
                req_valid = 1'b1;
                req_is_fc = 1'b0;
                req_tag = {1'b1, 3'b000, {2'b00,c2_issue_pr},
                           {2'b00,c2_issue_pc}, c2_issue_oc, 1'b0, c2_issue_ic};

                for (rr = 0; rr < 6; rr = rr + 1)
                    for (cc = 0; cc < 6; cc = cc + 1)
                        req_tile[rr][cc] = {1'b0, fmap1_ring[c2_issue_ic]
                            [add_mod7(c2_base_slot,rr)][c2_issue_pc*2+cc]};
            end
        end else if (state == ST_FC && fc_issue_count < 5'd8) begin
            req_valid = 1'b1;
            req_is_fc = 1'b1;
            req_tag = {11'd0,fc_issue_term,fc_issue_class};

            for (lane = 0; lane < 48; lane = lane + 1) begin
                ch  = lane / 16;
                pos = lane % 16;
                req_fc_a[lane] = {1'b0,fmap2[ch][pos/4][pos%4]};
            end
        end
    end

    // -------------------------------------------------------------------------
    // Response decode / fixed-point behavior.
    // -------------------------------------------------------------------------
    wire rsp_layer = rsp_tag[15];
    wire [3:0] rsp_pr = rsp_tag[11:8];
    wire [3:0] rsp_pc = rsp_tag[7:4];
    wire [1:0] rsp_oc = rsp_tag[3:2];
    wire [1:0] rsp_ic = rsp_tag[1:0];
    wire [3:0] rsp_fc_class = rsp_tag[3:0];
    wire       rsp_fc_term  = rsp_tag[4];

    logic signed [11:0] rsp_c1q00, rsp_c1q01, rsp_c1q10, rsp_c1q11;
    logic signed [31:0] rsp_eng20_00, rsp_eng20_01, rsp_eng20_10, rsp_eng20_11;
    logic signed [11:0] c2_wb0_q00, c2_wb0_q01, c2_wb0_q10, c2_wb0_q11;
    logic signed [31:0] fc_score_now;
    logic signed [31:0] fc_class_sum;
    logic [13:0] fc_sum_mod14;
    logic [11:0] fc_base12;
    logic [1:0]  fc_rem2;
    logic signed [8:0] fc_low9;

    always_comb begin
        rsp_c1q00 = conv1_q($signed(rsp_y00) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q01 = conv1_q($signed(rsp_y01) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q10 = conv1_q($signed(rsp_y10) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q11 = conv1_q($signed(rsp_y11) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));

        rsp_eng20_00 = $signed(rsp_y00[31:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_01 = $signed(rsp_y01[31:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_10 = $signed(rsp_y10[31:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_11 = $signed(rsp_y11[31:0]) <<< C2_RESTORE_SHIFT;

        // WB1 quantization is now isolated from engine-output accumulation.
        c2_wb0_q00 = conv2_q(c2_wb0_sum00,get_b2(c2_wb0_oc));
        c2_wb0_q01 = conv2_q(c2_wb0_sum01,get_b2(c2_wb0_oc));
        c2_wb0_q10 = conv2_q(c2_wb0_sum10,get_b2(c2_wb0_oc));
        c2_wb0_q11 = conv2_q(c2_wb0_sum11,get_b2(c2_wb0_oc));

        fc_class_sum = (FC_TWO_PASS ? fc_term0_sum : 32'sd0) + rsp_fc_sum;
        fc_score_now = fc_class_sum + get_fcb(rsp_fc_class);
    end

    // -------------------------------------------------------------------------
    // Main controller.
    // -------------------------------------------------------------------------
    integer c1wr, c1wc;
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= ST_STREAM;
            pixels_stored <= 10'd0;
            capture_primed <= 1'b0;
            cap_row <= 0;
            cap_col <= 0;
            cap_slot <= 0;
            c1_window_valid <= 1'b0;
            c1_new_col <= 5'd6;

            c1_issue_pr <= 0; c1_issue_pc <= 0; c1_issue_oc <= 0;
            c1_base_slot <= 0;
            c1_issue_count <= 0; c1_commit_count <= 0;
            c1_wb_valid <= 1'b0;
            c1_wb_slot <= 0; c1_wb_pc <= 0; c1_wb_oc <= 0;
            c1_wb_q00 <= 0; c1_wb_q01 <= 0;
            c1_wb_q10 <= 0; c1_wb_q11 <= 0;

            c2_issue_pr <= 0; c2_issue_pc <= 0;
            c2_issue_oc <= 0; c2_issue_ic <= 0;
            c2_base_slot <= 0;
            c2_issue_count <= 0; c2_rsp_count <= 0;
            c2_acc00 <= 0; c2_acc01 <= 0; c2_acc10 <= 0; c2_acc11 <= 0;

            c2_wb0_valid <= 1'b0;
            c2_wb1_valid <= 1'b0;
            c2_wb0_pr <= 0; c2_wb0_pc <= 0; c2_wb0_oc <= 0;
            c2_wb1_pr <= 0; c2_wb1_pc <= 0; c2_wb1_oc <= 0;
            c2_wb0_sum00 <= 0; c2_wb0_sum01 <= 0;
            c2_wb0_sum10 <= 0; c2_wb0_sum11 <= 0;
            c2_wb1_q00 <= 0; c2_wb1_q01 <= 0;
            c2_wb1_q10 <= 0; c2_wb1_q11 <= 0;
            c2_commit_count <= 0;

            fc_issue_class <= 0;
            fc_issue_count <= 0;
            fc_issue_term <= 1'b0;
            fc_term0_sum <= 32'sd0;
            best_score <= 32'sh80000000;
            best_idx <= 0;

            for(score_clear=0;score_clear<4;score_clear=score_clear+1)scores[score_clear]<=0;
            decision <= 0;
            valid_out_6 <= 1'b0;
        end else begin
            valid_out_6 <= 1'b0;

            // Conv1 writeback pipeline. The response cycle performs only the
            // fixed-point quantization into WB0. The next cycle performs the
            // max/ReLU and writes one pooled value into the seven-row ring.
            c1_wb_valid <= 1'b0;
            if (c1_wb_valid) begin
                fmap1_ring[c1_wb_oc][c1_wb_slot][c1_wb_pc] <=
                    max4_relu_a8(c1_wb_q00,c1_wb_q01,c1_wb_q10,c1_wb_q11);
                c1_commit_count <= c1_commit_count + 1'b1;
            end

            // Conv2 writeback pipeline advances every cycle.
            c2_wb0_valid <= 1'b0;
            c2_wb1_valid <= c2_wb0_valid;
            if (c2_wb0_valid) begin
                c2_wb1_pr <= c2_wb0_pr;
                c2_wb1_pc <= c2_wb0_pc;
                c2_wb1_oc <= c2_wb0_oc;
                c2_wb1_q00 <= c2_wb0_q00;
                c2_wb1_q01 <= c2_wb0_q01;
                c2_wb1_q10 <= c2_wb0_q10;
                c2_wb1_q11 <= c2_wb0_q11;
            end

            // Commit pooled Conv2 output from the isolated WB1 stage.
            if (c2_wb1_valid) begin
                fmap2[c2_wb1_oc][c2_wb1_pr][c2_wb1_pc] <=
                    max4_relu_a8(c2_wb1_q00,c2_wb1_q01,c2_wb1_q10,c2_wb1_q11);
                c2_commit_count <= c2_commit_count + 1'b1;

                // Start FC only after the 48th pooled fmap2 value is committed.
                if (c2_commit_count == 6'd47) begin
                    state <= ST_FC;
                    fc_issue_class <= 0;
                    fc_issue_count <= 0;
                    fc_issue_term <= 1'b0;
                    fc_term0_sum <= 32'sd0;
                    best_score <= 32'sh80000000;
                    best_idx <= 0;
                end
            end

            // Input capture continues independently of C1/C2 scheduling.
            if (pixels_stored < 10'd784) begin
                if (!capture_primed) begin
                    capture_primed <= 1'b1;
                end else begin
                    linebuf[cap_slot][cap_col] <= data_in;
                    pixels_stored <= pixels_stored + 1'b1;

                    // Row-start preload for the current Conv1 pooled row.
                    // It fires on the exact edge that captures raw column 5 of
                    // the sixth required input row. All other 35 bytes already
                    // reside in the seven-row line buffer; the just-arriving
                    // bottom-right byte bypasses the linebuf NBA write.
                    if (!c1_window_valid &&
                        (c1_issue_pc == 4'd0) &&
                        (c1_issue_oc == 2'd0) &&
                        (cap_col == 5'd5) &&
                        (cap_row == ({c1_issue_pr,1'b0} + 5'd5))) begin
                        for (c1wr = 0; c1wr < 6; c1wr = c1wr + 1) begin
                            for (c1wc = 0; c1wc < 6; c1wc = c1wc + 1) begin
                                if ((c1wr == 5) && (c1wc == 5))
                                    c1_window[c1wr][c1wc] <= data_in;
                                else
                                    c1_window[c1wr][c1wc] <=
                                        linebuf[add_mod7(c1_base_slot,c1wr)][c1wc];
                            end
                        end
                        c1_window_valid <= 1'b1;
                        c1_new_col <= 5'd6;
                    end

                    if (cap_col == 5'd27) begin
                        cap_col <= 0;
                        if (cap_row < 5'd27)
                            cap_row <= cap_row + 1'b1;
                        cap_slot <= (cap_slot == 3'd6) ? 3'd0 : cap_slot + 1'b1;
                    end else begin
                        cap_col <= cap_col + 1'b1;
                    end
                end
            end

            // Request-side progress. Conv1 reuses the same local 6x6 window
            // for the two surviving output channels. After physical channel 1, the
            // window advances by stride 2: four columns are retained and only two entering
            // columns (12 bytes total) are fetched from linebuf.
            if (req_valid && !req_is_fc && issue_c1) begin
                c1_issue_count <= c1_issue_count + 1'b1;
                if (c1_issue_oc == 1'b0) begin
                    c1_issue_oc <= 1'b1;
                end else begin
                    c1_issue_oc <= 0;
                    if (c1_issue_pc < 11) begin
                        for (c1wr = 0; c1wr < 6; c1wr = c1wr + 1) begin
                            c1_window[c1wr][0] <= c1_window[c1wr][2];
                            c1_window[c1wr][1] <= c1_window[c1wr][3];
                            c1_window[c1wr][2] <= c1_window[c1wr][4];
                            c1_window[c1wr][3] <= c1_window[c1wr][5];
                            c1_window[c1wr][4] <=
                                linebuf[add_mod7(c1_base_slot,c1wr)][c1_new_col];
                            // With only two Conv1 channels, the horizontal
                            // window advances one cycle earlier than V24.
                            // The newest bottom-row byte is being captured on
                            // this same edge, so bypass the linebuf NBA write.
                            if ((c1wr == 5) &&
                                (cap_row == ({c1_issue_pr,1'b0} + 5'd5)) &&
                                (cap_col == (c1_new_col + 1'b1)))
                                c1_window[c1wr][5] <= data_in;
                            else
                                c1_window[c1wr][5] <=
                                    linebuf[add_mod7(c1_base_slot,c1wr)][c1_new_col + 1'b1];
                        end
                        c1_new_col <= c1_new_col + 5'd2;
                        c1_issue_pc <= c1_issue_pc + 1'b1;
                    end else begin
                        // Next pooled row starts again at raw columns 0..5.
                        // Its window is reloaded by the input-capture preload
                        // above when the new bottom row reaches column 5.
                        c1_window_valid <= 1'b0;
                        c1_new_col <= 5'd6;
                        c1_issue_pc <= 0;
                        if (c1_issue_pr < 11) begin
                            c1_issue_pr <= c1_issue_pr + 1'b1;
                            c1_base_slot <= add_mod7(c1_base_slot,2);
                        end
                    end
                end
            end

            if (req_valid && !req_is_fc && issue_c2) begin
                c2_issue_count <= c2_issue_count + 1'b1;
                if (c2_issue_ic == 1'b0) begin
                    c2_issue_ic <= 1'b1;
                end else begin
                    c2_issue_ic <= 1'b0;
                    if (c2_issue_oc < 2) begin
                        c2_issue_oc <= c2_issue_oc + 1'b1;
                    end else begin
                        c2_issue_oc <= 0;
                        if (c2_issue_pc < 3) begin
                            c2_issue_pc <= c2_issue_pc + 1'b1;
                        end else begin
                            c2_issue_pc <= 0;
                            if (c2_issue_pr < 3) begin
                                c2_issue_pr <= c2_issue_pr + 1'b1;
                                c2_base_slot <= add_mod7(c2_base_slot,2);
                            end
                        end
                    end
                end
            end

            if(req_valid && req_is_fc && state==ST_FC)begin
                fc_issue_count<=fc_issue_count+1'b1;
                if(FC_TWO_PASS && !fc_issue_term)fc_issue_term<=1'b1;
                else begin fc_issue_term<=0;if(fc_issue_class<3)fc_issue_class<=fc_issue_class+1'b1;end
            end

            // Conv1 response -> WB0 quantization register. Pool/ReLU and the
            // physical ring write occur on the following cycle above.
            if (rsp_valid && !rsp_is_fc && (rsp_layer == 1'b0)) begin
                c1_wb_valid <= 1'b1;
                c1_wb_slot <= add_mod7(3'd0,rsp_pr);
                c1_wb_pc <= rsp_pc;
                c1_wb_oc <= rsp_oc;
                c1_wb_q00 <= rsp_c1q00;
                c1_wb_q01 <= rsp_c1q01;
                c1_wb_q10 <= rsp_c1q10;
                c1_wb_q11 <= rsp_c1q11;
            end

            // Conv2 response -> two-input-channel accumulation.
            // The second input-channel result is captured into WB0 instead of running
            // accumulation + quantization + pool/ReLU in one cycle.
            if (rsp_valid && !rsp_is_fc && (rsp_layer == 1'b1)) begin
                c2_rsp_count <= c2_rsp_count + 1'b1;

                if (rsp_ic == 0) begin
                    c2_acc00 <= rsp_eng20_00;
                    c2_acc01 <= rsp_eng20_01;
                    c2_acc10 <= rsp_eng20_10;
                    c2_acc11 <= rsp_eng20_11;
                end else begin
                    c2_wb0_valid <= 1'b1;
                    c2_wb0_pr <= rsp_pr[1:0];
                    c2_wb0_pc <= rsp_pc[1:0];
                    c2_wb0_oc <= rsp_oc;
                    c2_wb0_sum00 <= c2_acc00 + rsp_eng20_00;
                    c2_wb0_sum01 <= c2_acc01 + rsp_eng20_01;
                    c2_wb0_sum10 <= c2_acc10 + rsp_eng20_10;
                    c2_wb0_sum11 <= c2_acc11 + rsp_eng20_11;

                    c2_acc00 <= 0; c2_acc01 <= 0;
                    c2_acc10 <= 0; c2_acc11 <= 0;
                end
            end

            // FC SP2 is evaluated as two temporal PoT1 passes per class.
            // term0 is buffered; term1 completes the exact SP2 dot product,
            // after which the reduced-width bias/argmax datapath runs.
            if (rsp_valid && rsp_is_fc) begin
                if (FC_TWO_PASS && rsp_fc_term == 1'b0) begin
                    fc_term0_sum <= rsp_fc_sum;
                end else begin
                    scores[rsp_fc_class] <= fc_score_now;
                    if (rsp_fc_class == 0) begin
                        best_score <= fc_score_now;
                        best_idx <= 0;
                    end else if ($signed(fc_score_now) > $signed(best_score)) begin
                        best_score <= fc_score_now;
                        best_idx <= rsp_fc_class;
                    end

                    if (rsp_fc_class == 3) begin
                        if ($signed(fc_score_now) > $signed(best_score))
                            decision <= 2'd3;
                        else
                            decision <= best_idx;
                        valid_out_6 <= 1'b1;
                        state <= ST_DONE;
                    end
                end
            end
        end
    end

endmodule
```

## v25_dash/examples/synthetic_only/v25h/shift/tb_engine.sv

```systemverilog
`timescale 1ps/1ps
module tb_engine;
reg clk=0,rst_n=0,req_valid=0,req_is_fc=0;reg [15:0] req_tag=0;
reg signed [8:0] tile[0:5][0:5],fa[0:47];wire rv,rf;wire [15:0] rt;
wire signed [31:0] y0,y1,y2,y3,fs;
v25_dash_engine dut(clk,rst_n,req_valid,req_is_fc,req_tag,tile,fa,rv,rf,rt,y0,y1,y2,y3,fs);
always #5 clk=~clk;
reg [7:0] xs[0:9215];reg [15:0] tags[0:191];reg fcs[0:191];reg [31:0] ys[0:767];
integer sent=0,received=0,r,c,j,cycle=0,issue_cycle[0:191];
always @(posedge clk)begin
 cycle=cycle+1;
 if(rst_n && req_valid)begin issue_cycle[sent]=cycle;sent=sent+1;end
 #1;
 if(rst_n && rv)begin
  if(received>=sent || rt!==tags[received] || rf!==fcs[received])$fatal(1,"FAIL engine tag/order");
  if(cycle-issue_cycle[received]!=6)$fatal(1,"FAIL engine latency");
  if(rf)begin if(fs!==ys[received*4])$fatal(1,"FAIL FC engine case=%0d got=%0d expected=%0d",received,fs,$signed(ys[received*4]));end
  else if(y0!==ys[received*4]||y1!==ys[received*4+1]||y2!==ys[received*4+2]||y3!==ys[received*4+3])
   $fatal(1,"FAIL Conv engine case=%0d got=%0d,%0d,%0d,%0d expected=%0d,%0d,%0d,%0d",received,y0,y1,y2,y3,$signed(ys[received*4]),$signed(ys[received*4+1]),$signed(ys[received*4+2]),$signed(ys[received*4+3]));
  received=received+1;
 end
end
initial begin
 $readmemh("engine_x.hex",xs);$readmemh("engine_tag.hex",tags);$readmemh("engine_fc.hex",fcs);$readmemh("engine_y.hex",ys);
 repeat(3)@(negedge clk);rst_n=1;
 for(j=0;j<192;j=j+1)begin
  if(j%11==0)begin req_valid=0;@(negedge clk);end
  req_valid=1;req_tag=tags[j];req_is_fc=fcs[j];
  for(r=0;r<6;r=r+1)for(c=0;c<6;c=c+1)tile[r][c]={1'b0,xs[j*48+r*6+c]};
  for(r=0;r<48;r=r+1)fa[r]={1'b0,xs[j*48+r]};
  @(negedge clk);
 end
 req_valid=0;repeat(10)@(negedge clk);
 if(received!=192)$fatal(1,"FAIL missing engine results");
 $display("PASS engine: 192 requests, all coefficient tags, bubbles, II=1, latency=6");$finish;
end
endmodule
```

## v25_dash/examples/synthetic_only/v25h/shift/tb_top.sv

```systemverilog
`timescale 1ps/1ps
module tb_top;
reg clk=0,rst_n=0;reg [7:0] data_in=0;wire [1:0] decision;wire valid_out_6;wire [127:0] logits;
v25_dash_top dut(clk,rst_n,data_in,decision,valid_out_6,logits);
always #5 clk=~clk;
reg [7:0] pixels[0:5487],p1[0:2015],p2[0:335];
reg [31:0] scores[0:27];reg [1:0] decisions[0:6];
integer n,j,c,r,col,cycles;
always @(posedge clk)begin
 if(rst_n)begin
  if(dut.c1_wb_valid)begin
   r=dut.c1_commit_count/24;c=dut.c1_wb_oc;col=dut.c1_wb_pc;
   if(dut.max4_relu_a8(dut.c1_wb_q00,dut.c1_wb_q01,dut.c1_wb_q10,dut.c1_wb_q11)!==p1[n*288+c*144+r*12+col])
    $fatal(1,"FAIL pool1 case=%0d channel=%0d row=%0d col=%0d",n,c,r,col);
  end
 end
end
task reset_patch;begin rst_n=0;data_in=0;repeat(3)@(negedge clk);rst_n=1;@(negedge clk);end endtask
initial begin
 $readmemh("pixels.hex",pixels);$readmemh("scores.hex",scores);$readmemh("pool1.hex",p1);$readmemh("pool2.hex",p2);$readmemh("decision.hex",decisions);
 for(n=0;n<7;n=n+1)begin
  reset_patch();
  for(j=0;j<784;j=j+1)begin data_in=pixels[n*784+j];@(negedge clk);end
  data_in=0;cycles=784;
  while(!valid_out_6 && cycles<2000)begin @(negedge clk);cycles=cycles+1;end
  if(!valid_out_6)$fatal(1,"FAIL top timeout");
  for(c=0;c<4;c=c+1)if(logits[c*32+:32]!==scores[n*4+c])$fatal(1,"FAIL score case=%0d class=%0d got=%0d expected=%0d",n,c,$signed(logits[c*32+:32]),$signed(scores[n*4+c]));
  if(decision!==decisions[n])$fatal(1,"FAIL decision");
  for(c=0;c<3;c=c+1)for(r=0;r<4;r=r+1)for(col=0;col<4;col=col+1)
   if(dut.fmap2[c][r][col]!==p2[n*48+c*16+r*4+col])$fatal(1,"FAIL pool2");
  if(dut.c1_commit_count!=288||dut.c2_commit_count!=48)$fatal(1,"FAIL commit count");
  $display("PASS top case=%0d class=%0d input_start_to_result_cycles=%0d",n,decision,cycles);
  repeat(3)begin @(negedge clk);if(valid_out_6)$fatal(1,"FAIL repeated valid");end
 end
 // Interrupt a fresh patch, reset, then reproduce case zero to catch stale ring/valid state.
 n=0;reset_patch();for(j=0;j<97;j=j+1)begin data_in=pixels[j];@(negedge clk);end
 reset_patch();for(j=0;j<784;j=j+1)begin data_in=pixels[j];@(negedge clk);end
 cycles=784;while(!valid_out_6&&cycles<2000)begin @(negedge clk);cycles=cycles+1;end
 if(!valid_out_6||decision!==decisions[0])$fatal(1,"FAIL mid-patch reset");
 for(c=0;c<4;c=c+1)if(logits[c*32+:32]!==scores[c])$fatal(1,"FAIL reset score");
 $display("PASS top: all four scores, both pooled maps, U8 extremes, repeat reset, mid-patch reset");$finish;
end
endmodule
```

## v25_dash/examples/synthetic_only/v25h/shift/v25_dash_engine.sv

```systemverilog
`timescale 1ps/1ps
// V25-derived 49-lane coefficient-specific shared pipeline; generated for DASH.
// mode=v25h, backend=shift; P0 request -> P6 response, II=1.
module v25_dash_engine(input logic clk,rst_n,req_valid,req_is_fc, input logic [15:0] req_tag,
input wire signed [8:0] conv_tile[0:5][0:5], input wire signed [8:0] fc_a[0:47],
output logic rsp_valid,rsp_is_fc, output logic [15:0] rsp_tag,
output logic signed [31:0] conv_y00,conv_y01,conv_y10,conv_y11,fc_sum);
logic [6:0] valid_pipe,mode_pipe; logic [15:0] tag_pipe[0:6]; integer k;
always @(posedge clk) begin if(!rst_n)begin valid_pipe<=0;mode_pipe<=0;for(k=0;k<7;k=k+1)tag_pipe[k]<=0;end
else begin valid_pipe<={valid_pipe[5:0],req_valid};mode_pipe<={mode_pipe[5:0],req_is_fc};
tag_pipe[0]<=req_tag;for(k=1;k<7;k=k+1)tag_pipe[k]<=tag_pipe[k-1];end end
assign rsp_valid=valid_pipe[6];assign rsp_is_fc=mode_pipe[6];assign rsp_tag=tag_pipe[6];
logic [7:0] x0[0:35],f0[0:47],f1[0:47];integer r,c;
always @(posedge clk)begin if(!rst_n)begin for(r=0;r<36;r=r+1)x0[r]<=0;
for(r=0;r<48;r=r+1)begin f0[r]<=0;f1[r]<=0;end end else begin
if(req_valid)begin if(req_is_fc)begin for(r=0;r<48;r=r+1)f0[r]<=fc_a[r][7:0];end
else begin for(r=0;r<6;r=r+1)for(c=0;c<6;c=c+1)x0[r*6+c]<=conv_tile[r][c][7:0];end end
if(valid_pipe[0]&&mode_pipe[0])for(r=0;r<48;r=r+1)f1[r]<=f0[r];end end
wire [6:0] key1={mode_pipe[1],tag_pipe[1][15],(mode_pipe[1]?tag_pipe[1][4]:1'b0),tag_pipe[1][3:0]};
wire [6:0] key2={mode_pipe[2],tag_pipe[2][15],(mode_pipe[2]?tag_pipe[2][4]:1'b0),tag_pipe[2][3:0]};
logic signed [9:0] b1_0,a2_0;logic signed [15:0] p3_0;
always @(posedge clk)begin if(!rst_n)begin b1_0<=0;a2_0<=0;p3_0<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_0<=(($signed({2'd0,x0[0]}) + -$signed({2'd0,x0[2]})) + (-$signed({2'd0,x0[12]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_0<=mode_pipe[1]?$signed({2'd0,f1[0]}):b1_0;
if(valid_pipe[2])begin case(key2)
7'd0,7'd4,7'd33:p3_0<=-($signed({{6{a2_0[9]}},a2_0}) <<< 5);
7'd37,7'd40:p3_0<=($signed({{6{a2_0[9]}},a2_0}) <<< 5);
7'd41:p3_0<=($signed({{6{a2_0[9]}},a2_0}) <<< 6);
7'd64:p3_0<=($signed({{6{a2_0[9]}},a2_0}) <<< 2);
7'd65,7'd67:p3_0<=-($signed({{6{a2_0[9]}},a2_0}) <<< 4);
7'd66:p3_0<=-($signed({{6{a2_0[9]}},a2_0}) <<< 3);
7'd82:p3_0<=-($signed({{6{a2_0[9]}},a2_0}) <<< 2);
default:p3_0<=16'sd0;endcase end end end
logic signed [9:0] b1_1,a2_1;logic signed [15:0] p3_1;
always @(posedge clk)begin if(!rst_n)begin b1_1<=0;a2_1<=0;p3_1<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_1<=(($signed({2'd0,x0[1]}) + $signed({2'd0,x0[2]})) + (-$signed({2'd0,x0[13]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_1<=mode_pipe[1]?$signed({2'd0,f1[1]}):b1_1;
if(valid_pipe[2])begin case(key2)
7'd0:p3_1<=-($signed({{6{a2_1[9]}},a2_1}) <<< 4);
7'd4,7'd65:p3_1<=-($signed({{6{a2_1[9]}},a2_1}) <<< 2);
7'd32,7'd40:p3_1<=-($signed({{6{a2_1[9]}},a2_1}) <<< 3);
7'd33:p3_1<=-($signed({{6{a2_1[9]}},a2_1}) <<< 6);
7'd36,7'd64,7'd67:p3_1<=($signed({{6{a2_1[9]}},a2_1}) <<< 3);
7'd37:p3_1<=($signed({{6{a2_1[9]}},a2_1}) <<< 5);
7'd41:p3_1<=($signed({{6{a2_1[9]}},a2_1}) <<< 4);
7'd80,7'd66:p3_1<=($signed({{6{a2_1[9]}},a2_1}) <<< 2);
7'd81:p3_1<=-($signed({{6{a2_1[9]}},a2_1}) <<< 1);
7'd83:p3_1<=($signed({{6{a2_1[9]}},a2_1}) <<< 1);
default:p3_1<=16'sd0;endcase end end end
logic signed [9:0] b1_2,a2_2;logic signed [15:0] p3_2;
always @(posedge clk)begin if(!rst_n)begin b1_2<=0;a2_2<=0;p3_2<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_2<=((-$signed({2'd0,x0[1]}) + $signed({2'd0,x0[2]})) + ($signed({2'd0,x0[13]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_2<=mode_pipe[1]?$signed({2'd0,f1[2]}):b1_2;
if(valid_pipe[2])begin case(key2)
7'd0,7'd67:p3_2<=($signed({{6{a2_2[9]}},a2_2}) <<< 2);
7'd4,7'd32:p3_2<=-($signed({{6{a2_2[9]}},a2_2}) <<< 5);
7'd33,7'd64,7'd65:p3_2<=($signed({{6{a2_2[9]}},a2_2}) <<< 3);
7'd36,7'd40:p3_2<=($signed({{6{a2_2[9]}},a2_2}) <<< 5);
7'd37:p3_2<=-($signed({{6{a2_2[9]}},a2_2}) <<< 3);
7'd41:p3_2<=($signed({{6{a2_2[9]}},a2_2}) <<< 6);
7'd80:p3_2<=($signed({{6{a2_2[9]}},a2_2}) <<< 0);
7'd81,7'd83:p3_2<=($signed({{6{a2_2[9]}},a2_2}) <<< 1);
7'd66:p3_2<=-($signed({{6{a2_2[9]}},a2_2}) <<< 2);
default:p3_2<=16'sd0;endcase end end end
logic signed [9:0] b1_3,a2_3;logic signed [14:0] p3_3;
always @(posedge clk)begin if(!rst_n)begin b1_3<=0;a2_3<=0;p3_3<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_3<=(($signed({2'd0,x0[1]}) + -$signed({2'd0,x0[3]})) + (-$signed({2'd0,x0[13]}) + $signed({2'd0,x0[15]})));
if(valid_pipe[1])a2_3<=mode_pipe[1]?$signed({2'd0,f1[3]}):b1_3;
if(valid_pipe[2])begin case(key2)
7'd0,7'd66:p3_3<=($signed({{5{a2_3[9]}},a2_3}) <<< 4);
7'd4:p3_3<=-($signed({{5{a2_3[9]}},a2_3}) <<< 4);
7'd32:p3_3<=-($signed({{5{a2_3[9]}},a2_3}) <<< 5);
7'd36:p3_3<=($signed({{5{a2_3[9]}},a2_3}) <<< 5);
7'd37,7'd40:p3_3<=-($signed({{5{a2_3[9]}},a2_3}) <<< 3);
7'd41,7'd65,7'd67:p3_3<=($signed({{5{a2_3[9]}},a2_3}) <<< 3);
7'd64:p3_3<=($signed({{5{a2_3[9]}},a2_3}) <<< 2);
7'd80,7'd81:p3_3<=($signed({{5{a2_3[9]}},a2_3}) <<< 1);
7'd82:p3_3<=($signed({{5{a2_3[9]}},a2_3}) <<< 0);
default:p3_3<=15'sd0;endcase end end end
logic signed [9:0] b1_4,a2_4;logic signed [15:0] p3_4;
always @(posedge clk)begin if(!rst_n)begin b1_4<=0;a2_4<=0;p3_4<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_4<=(($signed({2'd0,x0[6]}) + -$signed({2'd0,x0[8]})) + ($signed({2'd0,x0[12]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_4<=mode_pipe[1]?$signed({2'd0,f1[4]}):b1_4;
if(valid_pipe[2])begin case(key2)
7'd0,7'd82:p3_4<=-($signed({{6{a2_4[9]}},a2_4}) <<< 1);
7'd4,7'd37:p3_4<=($signed({{6{a2_4[9]}},a2_4}) <<< 3);
7'd32:p3_4<=-($signed({{6{a2_4[9]}},a2_4}) <<< 5);
7'd33,7'd40,7'd67:p3_4<=($signed({{6{a2_4[9]}},a2_4}) <<< 4);
7'd36:p3_4<=($signed({{6{a2_4[9]}},a2_4}) <<< 5);
7'd41:p3_4<=($signed({{6{a2_4[9]}},a2_4}) <<< 6);
7'd64:p3_4<=($signed({{6{a2_4[9]}},a2_4}) <<< 2);
7'd80:p3_4<=($signed({{6{a2_4[9]}},a2_4}) <<< 1);
7'd66:p3_4<=-($signed({{6{a2_4[9]}},a2_4}) <<< 4);
7'd83:p3_4<=-($signed({{6{a2_4[9]}},a2_4}) <<< 0);
default:p3_4<=16'sd0;endcase end end end
logic signed [10:0] b1_5,a2_5;logic signed [15:0] p3_5;
always @(posedge clk)begin if(!rst_n)begin b1_5<=0;a2_5<=0;p3_5<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_5<=(($signed({3'd0,x0[7]}) + $signed({3'd0,x0[8]})) + ($signed({3'd0,x0[13]}) + $signed({3'd0,x0[14]})));
if(valid_pipe[1])a2_5<=mode_pipe[1]?$signed({3'd0,f1[5]}):b1_5;
if(valid_pipe[2])begin case(key2)
7'd0,7'd36,7'd37,7'd40:p3_5<=-($signed({{5{a2_5[10]}},a2_5}) <<< 4);
7'd4,7'd65:p3_5<=($signed({{5{a2_5[10]}},a2_5}) <<< 4);
7'd32:p3_5<=($signed({{5{a2_5[10]}},a2_5}) <<< 2);
7'd33:p3_5<=($signed({{5{a2_5[10]}},a2_5}) <<< 3);
7'd41:p3_5<=($signed({{5{a2_5[10]}},a2_5}) <<< 5);
7'd64:p3_5<=-($signed({{5{a2_5[10]}},a2_5}) <<< 3);
7'd81,7'd83:p3_5<=-($signed({{5{a2_5[10]}},a2_5}) <<< 0);
7'd66:p3_5<=-($signed({{5{a2_5[10]}},a2_5}) <<< 2);
7'd82,7'd67:p3_5<=-($signed({{5{a2_5[10]}},a2_5}) <<< 1);
default:p3_5<=16'sd0;endcase end end end
logic signed [9:0] b1_6,a2_6;logic signed [14:0] p3_6;
always @(posedge clk)begin if(!rst_n)begin b1_6<=0;a2_6<=0;p3_6<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_6<=((-$signed({2'd0,x0[7]}) + $signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[13]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_6<=mode_pipe[1]?$signed({2'd0,f1[6]}):b1_6;
if(valid_pipe[2])begin case(key2)
7'd0:p3_6<=($signed({{5{a2_6[9]}},a2_6}) <<< 2);
7'd4:p3_6<=-($signed({{5{a2_6[9]}},a2_6}) <<< 2);
7'd32:p3_6<=-($signed({{5{a2_6[9]}},a2_6}) <<< 5);
7'd33,7'd37,7'd41:p3_6<=($signed({{5{a2_6[9]}},a2_6}) <<< 5);
7'd36,7'd65:p3_6<=($signed({{5{a2_6[9]}},a2_6}) <<< 3);
7'd40:p3_6<=-($signed({{5{a2_6[9]}},a2_6}) <<< 4);
7'd64:p3_6<=($signed({{5{a2_6[9]}},a2_6}) <<< 4);
7'd80:p3_6<=-($signed({{5{a2_6[9]}},a2_6}) <<< 1);
7'd81,7'd66,7'd67:p3_6<=($signed({{5{a2_6[9]}},a2_6}) <<< 1);
7'd82:p3_6<=($signed({{5{a2_6[9]}},a2_6}) <<< 0);
default:p3_6<=15'sd0;endcase end end end
logic signed [9:0] b1_7,a2_7;logic signed [15:0] p3_7;
always @(posedge clk)begin if(!rst_n)begin b1_7<=0;a2_7<=0;p3_7<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_7<=(($signed({2'd0,x0[7]}) + -$signed({2'd0,x0[9]})) + ($signed({2'd0,x0[13]}) + -$signed({2'd0,x0[15]})));
if(valid_pipe[1])a2_7<=mode_pipe[1]?$signed({2'd0,f1[7]}):b1_7;
if(valid_pipe[2])begin case(key2)
7'd0,7'd67:p3_7<=-($signed({{6{a2_7[9]}},a2_7}) <<< 2);
7'd4,7'd41:p3_7<=($signed({{6{a2_7[9]}},a2_7}) <<< 2);
7'd32:p3_7<=-($signed({{6{a2_7[9]}},a2_7}) <<< 1);
7'd33:p3_7<=($signed({{6{a2_7[9]}},a2_7}) <<< 4);
7'd36:p3_7<=-($signed({{6{a2_7[9]}},a2_7}) <<< 5);
7'd40:p3_7<=-($signed({{6{a2_7[9]}},a2_7}) <<< 6);
7'd64:p3_7<=-($signed({{6{a2_7[9]}},a2_7}) <<< 4);
7'd80,7'd82:p3_7<=($signed({{6{a2_7[9]}},a2_7}) <<< 1);
7'd66:p3_7<=($signed({{6{a2_7[9]}},a2_7}) <<< 3);
default:p3_7<=16'sd0;endcase end end end
logic signed [9:0] b1_8,a2_8;logic signed [15:0] p3_8;
always @(posedge clk)begin if(!rst_n)begin b1_8<=0;a2_8<=0;p3_8<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_8<=((-$signed({2'd0,x0[6]}) + $signed({2'd0,x0[8]})) + ($signed({2'd0,x0[12]}) + -$signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_8<=mode_pipe[1]?$signed({2'd0,f1[8]}):b1_8;
if(valid_pipe[2])begin case(key2)
7'd0,7'd33,7'd80:p3_8<=-($signed({{6{a2_8[9]}},a2_8}) <<< 1);
7'd4,7'd32:p3_8<=-($signed({{6{a2_8[9]}},a2_8}) <<< 5);
7'd36:p3_8<=($signed({{6{a2_8[9]}},a2_8}) <<< 5);
7'd37:p3_8<=($signed({{6{a2_8[9]}},a2_8}) <<< 6);
7'd40,7'd64:p3_8<=($signed({{6{a2_8[9]}},a2_8}) <<< 4);
7'd65,7'd66,7'd67:p3_8<=-($signed({{6{a2_8[9]}},a2_8}) <<< 2);
7'd81,7'd83:p3_8<=-($signed({{6{a2_8[9]}},a2_8}) <<< 0);
default:p3_8<=16'sd0;endcase end end end
logic signed [9:0] b1_9,a2_9;logic signed [15:0] p3_9;
always @(posedge clk)begin if(!rst_n)begin b1_9<=0;a2_9<=0;p3_9<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_9<=((-$signed({2'd0,x0[7]}) + -$signed({2'd0,x0[8]})) + ($signed({2'd0,x0[13]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_9<=mode_pipe[1]?$signed({2'd0,f1[9]}):b1_9;
if(valid_pipe[2])begin case(key2)
7'd0:p3_9<=($signed({{6{a2_9[9]}},a2_9}) <<< 0);
7'd4:p3_9<=-($signed({{6{a2_9[9]}},a2_9}) <<< 3);
7'd32,7'd64:p3_9<=($signed({{6{a2_9[9]}},a2_9}) <<< 3);
7'd33,7'd40,7'd66:p3_9<=-($signed({{6{a2_9[9]}},a2_9}) <<< 4);
7'd36:p3_9<=($signed({{6{a2_9[9]}},a2_9}) <<< 5);
7'd37:p3_9<=($signed({{6{a2_9[9]}},a2_9}) <<< 6);
7'd41,7'd82,7'd83:p3_9<=-($signed({{6{a2_9[9]}},a2_9}) <<< 1);
7'd65,7'd67:p3_9<=($signed({{6{a2_9[9]}},a2_9}) <<< 4);
7'd81:p3_9<=-($signed({{6{a2_9[9]}},a2_9}) <<< 0);
default:p3_9<=16'sd0;endcase end end end
logic signed [9:0] b1_10,a2_10;logic signed [15:0] p3_10;
always @(posedge clk)begin if(!rst_n)begin b1_10<=0;a2_10<=0;p3_10<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_10<=(($signed({2'd0,x0[7]}) + -$signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[13]}) + $signed({2'd0,x0[14]})));
if(valid_pipe[1])a2_10<=mode_pipe[1]?$signed({2'd0,f1[10]}):b1_10;
if(valid_pipe[2])begin case(key2)
7'd0,7'd37:p3_10<=($signed({{6{a2_10[9]}},a2_10}) <<< 5);
7'd4:p3_10<=-($signed({{6{a2_10[9]}},a2_10}) <<< 6);
7'd32,7'd41:p3_10<=-($signed({{6{a2_10[9]}},a2_10}) <<< 5);
7'd33,7'd64,7'd66:p3_10<=-($signed({{6{a2_10[9]}},a2_10}) <<< 2);
7'd36:p3_10<=($signed({{6{a2_10[9]}},a2_10}) <<< 1);
7'd40:p3_10<=($signed({{6{a2_10[9]}},a2_10}) <<< 4);
7'd80:p3_10<=-($signed({{6{a2_10[9]}},a2_10}) <<< 0);
7'd65,7'd83:p3_10<=-($signed({{6{a2_10[9]}},a2_10}) <<< 1);
7'd67:p3_10<=-($signed({{6{a2_10[9]}},a2_10}) <<< 4);
default:p3_10<=16'sd0;endcase end end end
logic signed [9:0] b1_11,a2_11;logic signed [14:0] p3_11;
always @(posedge clk)begin if(!rst_n)begin b1_11<=0;a2_11<=0;p3_11<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_11<=((-$signed({2'd0,x0[7]}) + $signed({2'd0,x0[9]})) + ($signed({2'd0,x0[13]}) + -$signed({2'd0,x0[15]})));
if(valid_pipe[1])a2_11<=mode_pipe[1]?$signed({2'd0,f1[11]}):b1_11;
if(valid_pipe[2])begin case(key2)
7'd0,7'd37:p3_11<=($signed({{5{a2_11[9]}},a2_11}) <<< 5);
7'd4,7'd41:p3_11<=-($signed({{5{a2_11[9]}},a2_11}) <<< 5);
7'd32:p3_11<=-($signed({{5{a2_11[9]}},a2_11}) <<< 1);
7'd33:p3_11<=-($signed({{5{a2_11[9]}},a2_11}) <<< 4);
7'd36,7'd65:p3_11<=($signed({{5{a2_11[9]}},a2_11}) <<< 3);
7'd40,7'd64,7'd67:p3_11<=-($signed({{5{a2_11[9]}},a2_11}) <<< 3);
7'd80:p3_11<=-($signed({{5{a2_11[9]}},a2_11}) <<< 2);
7'd83:p3_11<=($signed({{5{a2_11[9]}},a2_11}) <<< 0);
default:p3_11<=15'sd0;endcase end end end
logic signed [9:0] b1_12,a2_12;logic signed [15:0] p3_12;
always @(posedge clk)begin if(!rst_n)begin b1_12<=0;a2_12<=0;p3_12<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_12<=(($signed({2'd0,x0[6]}) + -$signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[18]}) + $signed({2'd0,x0[20]})));
if(valid_pipe[1])a2_12<=mode_pipe[1]?$signed({2'd0,f1[12]}):b1_12;
if(valid_pipe[2])begin case(key2)
7'd0,7'd37:p3_12<=($signed({{6{a2_12[9]}},a2_12}) <<< 5);
7'd32:p3_12<=-($signed({{6{a2_12[9]}},a2_12}) <<< 6);
7'd33,7'd36:p3_12<=($signed({{6{a2_12[9]}},a2_12}) <<< 6);
7'd64:p3_12<=-($signed({{6{a2_12[9]}},a2_12}) <<< 2);
7'd80:p3_12<=-($signed({{6{a2_12[9]}},a2_12}) <<< 0);
7'd65:p3_12<=($signed({{6{a2_12[9]}},a2_12}) <<< 3);
7'd67:p3_12<=-($signed({{6{a2_12[9]}},a2_12}) <<< 3);
7'd83:p3_12<=-($signed({{6{a2_12[9]}},a2_12}) <<< 1);
default:p3_12<=16'sd0;endcase end end end
logic signed [9:0] b1_13,a2_13;logic signed [14:0] p3_13;
always @(posedge clk)begin if(!rst_n)begin b1_13<=0;a2_13<=0;p3_13<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_13<=(($signed({2'd0,x0[7]}) + $signed({2'd0,x0[8]})) + (-$signed({2'd0,x0[19]}) + -$signed({2'd0,x0[20]})));
if(valid_pipe[1])a2_13<=mode_pipe[1]?$signed({2'd0,f1[13]}):b1_13;
if(valid_pipe[2])begin case(key2)
7'd0,7'd36,7'd37:p3_13<=($signed({{5{a2_13[9]}},a2_13}) <<< 3);
7'd4,7'd41,7'd67:p3_13<=($signed({{5{a2_13[9]}},a2_13}) <<< 4);
7'd32,7'd33:p3_13<=($signed({{5{a2_13[9]}},a2_13}) <<< 5);
7'd40:p3_13<=-($signed({{5{a2_13[9]}},a2_13}) <<< 5);
7'd64,7'd65,7'd66:p3_13<=-($signed({{5{a2_13[9]}},a2_13}) <<< 3);
7'd81:p3_13<=-($signed({{5{a2_13[9]}},a2_13}) <<< 1);
7'd82:p3_13<=-($signed({{5{a2_13[9]}},a2_13}) <<< 0);
7'd83:p3_13<=($signed({{5{a2_13[9]}},a2_13}) <<< 1);
default:p3_13<=15'sd0;endcase end end end
logic signed [9:0] b1_14,a2_14;logic signed [15:0] p3_14;
always @(posedge clk)begin if(!rst_n)begin b1_14<=0;a2_14<=0;p3_14<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_14<=((-$signed({2'd0,x0[7]}) + $signed({2'd0,x0[8]})) + ($signed({2'd0,x0[19]}) + -$signed({2'd0,x0[20]})));
if(valid_pipe[1])a2_14<=mode_pipe[1]?$signed({2'd0,f1[14]}):b1_14;
if(valid_pipe[2])begin case(key2)
7'd0:p3_14<=($signed({{6{a2_14[9]}},a2_14}) <<< 5);
7'd4:p3_14<=-($signed({{6{a2_14[9]}},a2_14}) <<< 4);
7'd32,7'd36,7'd40:p3_14<=-($signed({{6{a2_14[9]}},a2_14}) <<< 5);
7'd33,7'd64:p3_14<=($signed({{6{a2_14[9]}},a2_14}) <<< 3);
7'd37:p3_14<=($signed({{6{a2_14[9]}},a2_14}) <<< 6);
7'd41:p3_14<=-($signed({{6{a2_14[9]}},a2_14}) <<< 6);
7'd65:p3_14<=($signed({{6{a2_14[9]}},a2_14}) <<< 4);
7'd81,7'd82:p3_14<=-($signed({{6{a2_14[9]}},a2_14}) <<< 0);
7'd66:p3_14<=-($signed({{6{a2_14[9]}},a2_14}) <<< 2);
7'd67:p3_14<=($signed({{6{a2_14[9]}},a2_14}) <<< 2);
default:p3_14<=16'sd0;endcase end end end
logic signed [9:0] b1_15,a2_15;logic signed [15:0] p3_15;
always @(posedge clk)begin if(!rst_n)begin b1_15<=0;a2_15<=0;p3_15<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_15<=(($signed({2'd0,x0[7]}) + -$signed({2'd0,x0[9]})) + (-$signed({2'd0,x0[19]}) + $signed({2'd0,x0[21]})));
if(valid_pipe[1])a2_15<=mode_pipe[1]?$signed({2'd0,f1[15]}):b1_15;
if(valid_pipe[2])begin case(key2)
7'd0:p3_15<=($signed({{6{a2_15[9]}},a2_15}) <<< 4);
7'd32:p3_15<=($signed({{6{a2_15[9]}},a2_15}) <<< 5);
7'd36,7'd40:p3_15<=-($signed({{6{a2_15[9]}},a2_15}) <<< 6);
7'd37:p3_15<=($signed({{6{a2_15[9]}},a2_15}) <<< 6);
7'd41:p3_15<=-($signed({{6{a2_15[9]}},a2_15}) <<< 5);
7'd65,7'd67:p3_15<=-($signed({{6{a2_15[9]}},a2_15}) <<< 3);
7'd81,7'd83:p3_15<=($signed({{6{a2_15[9]}},a2_15}) <<< 0);
7'd66:p3_15<=($signed({{6{a2_15[9]}},a2_15}) <<< 2);
7'd82:p3_15<=($signed({{6{a2_15[9]}},a2_15}) <<< 1);
default:p3_15<=16'sd0;endcase end end end
logic signed [9:0] b1_16,a2_16;logic signed [14:0] p3_16;
always @(posedge clk)begin if(!rst_n)begin b1_16<=0;a2_16<=0;p3_16<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_16<=(($signed({2'd0,x0[3]}) + -$signed({2'd0,x0[4]})) + (-$signed({2'd0,x0[15]}) + $signed({2'd0,x0[16]})));
if(valid_pipe[1])a2_16<=mode_pipe[1]?$signed({2'd0,f1[16]}):b1_16;
if(valid_pipe[2])begin case(key2)
7'd0:p3_16<=-($signed({{5{a2_16[9]}},a2_16}) <<< 4);
7'd4,7'd37,7'd67:p3_16<=-($signed({{5{a2_16[9]}},a2_16}) <<< 3);
7'd33,7'd40,7'd66,7'd83:p3_16<=-($signed({{5{a2_16[9]}},a2_16}) <<< 2);
7'd36,7'd64:p3_16<=($signed({{5{a2_16[9]}},a2_16}) <<< 3);
7'd41:p3_16<=($signed({{5{a2_16[9]}},a2_16}) <<< 5);
7'd80:p3_16<=($signed({{5{a2_16[9]}},a2_16}) <<< 1);
default:p3_16<=15'sd0;endcase end end end
logic signed [8:0] b1_17,a2_17;logic signed [14:0] p3_17;
always @(posedge clk)begin if(!rst_n)begin b1_17<=0;a2_17<=0;p3_17<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_17<=($signed({1'd0,x0[4]}) + -$signed({1'd0,x0[16]}));
if(valid_pipe[1])a2_17<=mode_pipe[1]?$signed({1'd0,f1[17]}):b1_17;
if(valid_pipe[2])begin case(key2)
7'd0:p3_17<=-($signed({{6{a2_17[8]}},a2_17}) <<< 6);
7'd4,7'd32:p3_17<=-($signed({{6{a2_17[8]}},a2_17}) <<< 5);
7'd33,7'd66:p3_17<=-($signed({{6{a2_17[8]}},a2_17}) <<< 4);
7'd36,7'd41,7'd65:p3_17<=($signed({{6{a2_17[8]}},a2_17}) <<< 4);
7'd37,7'd40,7'd82:p3_17<=-($signed({{6{a2_17[8]}},a2_17}) <<< 1);
7'd64:p3_17<=-($signed({{6{a2_17[8]}},a2_17}) <<< 3);
7'd80,7'd81:p3_17<=-($signed({{6{a2_17[8]}},a2_17}) <<< 0);
default:p3_17<=15'sd0;endcase end end end
logic signed [9:0] b1_18,a2_18;logic signed [14:0] p3_18;
always @(posedge clk)begin if(!rst_n)begin b1_18<=0;a2_18<=0;p3_18<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_18<=((-$signed({2'd0,x0[4]}) + $signed({2'd0,x0[5]})) + ($signed({2'd0,x0[16]}) + -$signed({2'd0,x0[17]})));
if(valid_pipe[1])a2_18<=mode_pipe[1]?$signed({2'd0,f1[18]}):b1_18;
if(valid_pipe[2])begin case(key2)
7'd0,7'd32:p3_18<=-($signed({{5{a2_18[9]}},a2_18}) <<< 5);
7'd4,7'd33,7'd64,7'd66:p3_18<=-($signed({{5{a2_18[9]}},a2_18}) <<< 4);
7'd36,7'd37,7'd67:p3_18<=($signed({{5{a2_18[9]}},a2_18}) <<< 3);
7'd40:p3_18<=($signed({{5{a2_18[9]}},a2_18}) <<< 2);
7'd41:p3_18<=-($signed({{5{a2_18[9]}},a2_18}) <<< 3);
7'd80:p3_18<=-($signed({{5{a2_18[9]}},a2_18}) <<< 0);
7'd65:p3_18<=-($signed({{5{a2_18[9]}},a2_18}) <<< 1);
7'd82,7'd83:p3_18<=($signed({{5{a2_18[9]}},a2_18}) <<< 1);
default:p3_18<=15'sd0;endcase end end end
logic signed [9:0] b1_19,a2_19;logic signed [14:0] p3_19;
always @(posedge clk)begin if(!rst_n)begin b1_19<=0;a2_19<=0;p3_19<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_19<=(($signed({2'd0,x0[9]}) + -$signed({2'd0,x0[10]})) + ($signed({2'd0,x0[15]}) + -$signed({2'd0,x0[16]})));
if(valid_pipe[1])a2_19<=mode_pipe[1]?$signed({2'd0,f1[19]}):b1_19;
if(valid_pipe[2])begin case(key2)
7'd0,7'd40,7'd80,7'd66:p3_19<=-($signed({{5{a2_19[9]}},a2_19}) <<< 2);
7'd4,7'd37,7'd64:p3_19<=-($signed({{5{a2_19[9]}},a2_19}) <<< 3);
7'd32:p3_19<=($signed({{5{a2_19[9]}},a2_19}) <<< 1);
7'd33:p3_19<=-($signed({{5{a2_19[9]}},a2_19}) <<< 5);
7'd36,7'd41:p3_19<=($signed({{5{a2_19[9]}},a2_19}) <<< 3);
7'd65,7'd67:p3_19<=-($signed({{5{a2_19[9]}},a2_19}) <<< 4);
7'd82:p3_19<=-($signed({{5{a2_19[9]}},a2_19}) <<< 1);
7'd83:p3_19<=-($signed({{5{a2_19[9]}},a2_19}) <<< 0);
default:p3_19<=15'sd0;endcase end end end
logic signed [9:0] b1_20,a2_20;logic signed [14:0] p3_20;
always @(posedge clk)begin if(!rst_n)begin b1_20<=0;a2_20<=0;p3_20<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_20<=($signed({2'd0,x0[10]}) + $signed({2'd0,x0[16]}));
if(valid_pipe[1])a2_20<=mode_pipe[1]?$signed({2'd0,f1[20]}):b1_20;
if(valid_pipe[2])begin case(key2)
7'd0,7'd4,7'd33:p3_20<=-($signed({{5{a2_20[9]}},a2_20}) <<< 5);
7'd32,7'd64:p3_20<=-($signed({{5{a2_20[9]}},a2_20}) <<< 4);
7'd36:p3_20<=($signed({{5{a2_20[9]}},a2_20}) <<< 5);
7'd37,7'd40,7'd41:p3_20<=-($signed({{5{a2_20[9]}},a2_20}) <<< 3);
7'd65,7'd66,7'd83:p3_20<=($signed({{5{a2_20[9]}},a2_20}) <<< 2);
7'd81,7'd82:p3_20<=($signed({{5{a2_20[9]}},a2_20}) <<< 0);
7'd67:p3_20<=($signed({{5{a2_20[9]}},a2_20}) <<< 3);
default:p3_20<=15'sd0;endcase end end end
logic signed [9:0] b1_21,a2_21;logic signed [14:0] p3_21;
always @(posedge clk)begin if(!rst_n)begin b1_21<=0;a2_21<=0;p3_21<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_21<=((-$signed({2'd0,x0[10]}) + $signed({2'd0,x0[11]})) + (-$signed({2'd0,x0[16]}) + $signed({2'd0,x0[17]})));
if(valid_pipe[1])a2_21<=mode_pipe[1]?$signed({2'd0,f1[21]}):b1_21;
if(valid_pipe[2])begin case(key2)
7'd0,7'd4:p3_21<=-($signed({{5{a2_21[9]}},a2_21}) <<< 5);
7'd32,7'd41:p3_21<=-($signed({{5{a2_21[9]}},a2_21}) <<< 4);
7'd36:p3_21<=($signed({{5{a2_21[9]}},a2_21}) <<< 4);
7'd37,7'd82:p3_21<=($signed({{5{a2_21[9]}},a2_21}) <<< 0);
7'd40:p3_21<=-($signed({{5{a2_21[9]}},a2_21}) <<< 1);
7'd64:p3_21<=($signed({{5{a2_21[9]}},a2_21}) <<< 1);
7'd66:p3_21<=-($signed({{5{a2_21[9]}},a2_21}) <<< 3);
7'd67:p3_21<=($signed({{5{a2_21[9]}},a2_21}) <<< 3);
7'd83:p3_21<=($signed({{5{a2_21[9]}},a2_21}) <<< 2);
default:p3_21<=15'sd0;endcase end end end
logic signed [9:0] b1_22,a2_22;logic signed [14:0] p3_22;
always @(posedge clk)begin if(!rst_n)begin b1_22<=0;a2_22<=0;p3_22<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_22<=((-$signed({2'd0,x0[9]}) + $signed({2'd0,x0[10]})) + ($signed({2'd0,x0[15]}) + -$signed({2'd0,x0[16]})));
if(valid_pipe[1])a2_22<=mode_pipe[1]?$signed({2'd0,f1[22]}):b1_22;
if(valid_pipe[2])begin case(key2)
7'd0,7'd32,7'd36:p3_22<=-($signed({{5{a2_22[9]}},a2_22}) <<< 4);
7'd4,7'd37:p3_22<=-($signed({{5{a2_22[9]}},a2_22}) <<< 3);
7'd33:p3_22<=-($signed({{5{a2_22[9]}},a2_22}) <<< 2);
7'd40:p3_22<=($signed({{5{a2_22[9]}},a2_22}) <<< 2);
7'd41:p3_22<=($signed({{5{a2_22[9]}},a2_22}) <<< 5);
7'd65,7'd66:p3_22<=($signed({{5{a2_22[9]}},a2_22}) <<< 4);
7'd81:p3_22<=($signed({{5{a2_22[9]}},a2_22}) <<< 0);
7'd82:p3_22<=-($signed({{5{a2_22[9]}},a2_22}) <<< 0);
7'd67:p3_22<=($signed({{5{a2_22[9]}},a2_22}) <<< 3);
7'd83:p3_22<=($signed({{5{a2_22[9]}},a2_22}) <<< 1);
default:p3_22<=15'sd0;endcase end end end
logic signed [8:0] b1_23,a2_23;logic signed [14:0] p3_23;
always @(posedge clk)begin if(!rst_n)begin b1_23<=0;a2_23<=0;p3_23<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_23<=(-$signed({1'd0,x0[10]}) + $signed({1'd0,x0[16]}));
if(valid_pipe[1])a2_23<=mode_pipe[1]?$signed({1'd0,f1[23]}):b1_23;
if(valid_pipe[2])begin case(key2)
7'd0,7'd4:p3_23<=-($signed({{6{a2_23[8]}},a2_23}) <<< 4);
7'd32:p3_23<=-($signed({{6{a2_23[8]}},a2_23}) <<< 6);
7'd33,7'd36:p3_23<=-($signed({{6{a2_23[8]}},a2_23}) <<< 5);
7'd37,7'd40:p3_23<=($signed({{6{a2_23[8]}},a2_23}) <<< 3);
7'd41:p3_23<=($signed({{6{a2_23[8]}},a2_23}) <<< 5);
7'd64,7'd65,7'd67:p3_23<=-($signed({{6{a2_23[8]}},a2_23}) <<< 3);
7'd80:p3_23<=-($signed({{6{a2_23[8]}},a2_23}) <<< 2);
7'd81:p3_23<=($signed({{6{a2_23[8]}},a2_23}) <<< 0);
7'd66:p3_23<=($signed({{6{a2_23[8]}},a2_23}) <<< 4);
7'd82:p3_23<=-($signed({{6{a2_23[8]}},a2_23}) <<< 1);
7'd83:p3_23<=-($signed({{6{a2_23[8]}},a2_23}) <<< 0);
default:p3_23<=15'sd0;endcase end end end
logic signed [9:0] b1_24,a2_24;logic signed [14:0] p3_24;
always @(posedge clk)begin if(!rst_n)begin b1_24<=0;a2_24<=0;p3_24<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_24<=(($signed({2'd0,x0[10]}) + -$signed({2'd0,x0[11]})) + (-$signed({2'd0,x0[16]}) + $signed({2'd0,x0[17]})));
if(valid_pipe[1])a2_24<=mode_pipe[1]?$signed({2'd0,f1[24]}):b1_24;
if(valid_pipe[2])begin case(key2)
7'd0,7'd4,7'd65:p3_24<=-($signed({{5{a2_24[9]}},a2_24}) <<< 2);
7'd32,7'd33:p3_24<=-($signed({{5{a2_24[9]}},a2_24}) <<< 5);
7'd36:p3_24<=-($signed({{5{a2_24[9]}},a2_24}) <<< 3);
7'd37:p3_24<=($signed({{5{a2_24[9]}},a2_24}) <<< 4);
7'd40,7'd64,7'd66,7'd67:p3_24<=($signed({{5{a2_24[9]}},a2_24}) <<< 3);
7'd41:p3_24<=-($signed({{5{a2_24[9]}},a2_24}) <<< 1);
7'd80,7'd83:p3_24<=($signed({{5{a2_24[9]}},a2_24}) <<< 2);
7'd81:p3_24<=-($signed({{5{a2_24[9]}},a2_24}) <<< 0);
default:p3_24<=15'sd0;endcase end end end
logic signed [9:0] b1_25,a2_25;logic signed [14:0] p3_25;
always @(posedge clk)begin if(!rst_n)begin b1_25<=0;a2_25<=0;p3_25<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_25<=(($signed({2'd0,x0[9]}) + -$signed({2'd0,x0[10]})) + (-$signed({2'd0,x0[21]}) + $signed({2'd0,x0[22]})));
if(valid_pipe[1])a2_25<=mode_pipe[1]?$signed({2'd0,f1[25]}):b1_25;
if(valid_pipe[2])begin case(key2)
7'd0,7'd40:p3_25<=($signed({{5{a2_25[9]}},a2_25}) <<< 2);
7'd4:p3_25<=-($signed({{5{a2_25[9]}},a2_25}) <<< 2);
7'd32,7'd37,7'd64:p3_25<=-($signed({{5{a2_25[9]}},a2_25}) <<< 3);
7'd33:p3_25<=-($signed({{5{a2_25[9]}},a2_25}) <<< 5);
7'd36,7'd66:p3_25<=-($signed({{5{a2_25[9]}},a2_25}) <<< 4);
7'd41:p3_25<=($signed({{5{a2_25[9]}},a2_25}) <<< 4);
7'd80:p3_25<=($signed({{5{a2_25[9]}},a2_25}) <<< 0);
7'd65:p3_25<=-($signed({{5{a2_25[9]}},a2_25}) <<< 1);
7'd81,7'd83:p3_25<=-($signed({{5{a2_25[9]}},a2_25}) <<< 0);
7'd67:p3_25<=($signed({{5{a2_25[9]}},a2_25}) <<< 3);
default:p3_25<=15'sd0;endcase end end end
logic signed [8:0] b1_26,a2_26;logic signed [14:0] p3_26;
always @(posedge clk)begin if(!rst_n)begin b1_26<=0;a2_26<=0;p3_26<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_26<=($signed({1'd0,x0[10]}) + -$signed({1'd0,x0[22]}));
if(valid_pipe[1])a2_26<=mode_pipe[1]?$signed({1'd0,f1[26]}):b1_26;
if(valid_pipe[2])begin case(key2)
7'd4,7'd36:p3_26<=-($signed({{6{a2_26[8]}},a2_26}) <<< 3);
7'd32:p3_26<=-($signed({{6{a2_26[8]}},a2_26}) <<< 5);
7'd33:p3_26<=-($signed({{6{a2_26[8]}},a2_26}) <<< 6);
7'd37,7'd64:p3_26<=($signed({{6{a2_26[8]}},a2_26}) <<< 1);
7'd40:p3_26<=($signed({{6{a2_26[8]}},a2_26}) <<< 2);
7'd41,7'd66,7'd67:p3_26<=($signed({{6{a2_26[8]}},a2_26}) <<< 3);
7'd82:p3_26<=($signed({{6{a2_26[8]}},a2_26}) <<< 0);
default:p3_26<=15'sd0;endcase end end end
logic signed [9:0] b1_27,a2_27;logic signed [13:0] p3_27;
always @(posedge clk)begin if(!rst_n)begin b1_27<=0;a2_27<=0;p3_27<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_27<=((-$signed({2'd0,x0[10]}) + $signed({2'd0,x0[11]})) + ($signed({2'd0,x0[22]}) + -$signed({2'd0,x0[23]})));
if(valid_pipe[1])a2_27<=mode_pipe[1]?$signed({2'd0,f1[27]}):b1_27;
if(valid_pipe[2])begin case(key2)
7'd0,7'd4:p3_27<=-($signed({{4{a2_27[9]}},a2_27}) <<< 2);
7'd32,7'd33:p3_27<=-($signed({{4{a2_27[9]}},a2_27}) <<< 4);
7'd36,7'd82:p3_27<=($signed({{4{a2_27[9]}},a2_27}) <<< 2);
7'd37,7'd66,7'd67:p3_27<=($signed({{4{a2_27[9]}},a2_27}) <<< 3);
7'd41:p3_27<=-($signed({{4{a2_27[9]}},a2_27}) <<< 3);
7'd64:p3_27<=($signed({{4{a2_27[9]}},a2_27}) <<< 1);
7'd80:p3_27<=($signed({{4{a2_27[9]}},a2_27}) <<< 0);
7'd65:p3_27<=-($signed({{4{a2_27[9]}},a2_27}) <<< 1);
7'd81:p3_27<=-($signed({{4{a2_27[9]}},a2_27}) <<< 0);
default:p3_27<=14'sd0;endcase end end end
logic signed [9:0] b1_28,a2_28;logic signed [14:0] p3_28;
always @(posedge clk)begin if(!rst_n)begin b1_28<=0;a2_28<=0;p3_28<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_28<=(($signed({2'd0,x0[18]}) + -$signed({2'd0,x0[20]})) + (-$signed({2'd0,x0[24]}) + $signed({2'd0,x0[26]})));
if(valid_pipe[1])a2_28<=mode_pipe[1]?$signed({2'd0,f1[28]}):b1_28;
if(valid_pipe[2])begin case(key2)
7'd0:p3_28<=-($signed({{5{a2_28[9]}},a2_28}) <<< 3);
7'd4,7'd37,7'd40,7'd66:p3_28<=($signed({{5{a2_28[9]}},a2_28}) <<< 4);
7'd33:p3_28<=($signed({{5{a2_28[9]}},a2_28}) <<< 5);
7'd36:p3_28<=-($signed({{5{a2_28[9]}},a2_28}) <<< 5);
7'd64:p3_28<=-($signed({{5{a2_28[9]}},a2_28}) <<< 2);
7'd80,7'd82:p3_28<=-($signed({{5{a2_28[9]}},a2_28}) <<< 0);
7'd65,7'd83:p3_28<=($signed({{5{a2_28[9]}},a2_28}) <<< 2);
7'd67:p3_28<=($signed({{5{a2_28[9]}},a2_28}) <<< 3);
default:p3_28<=15'sd0;endcase end end end
logic signed [9:0] b1_29,a2_29;logic signed [13:0] p3_29;
always @(posedge clk)begin if(!rst_n)begin b1_29<=0;a2_29<=0;p3_29<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_29<=(($signed({2'd0,x0[19]}) + $signed({2'd0,x0[20]})) + (-$signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})));
if(valid_pipe[1])a2_29<=mode_pipe[1]?$signed({2'd0,f1[29]}):b1_29;
if(valid_pipe[2])begin case(key2)
7'd0,7'd33,7'd41:p3_29<=($signed({{4{a2_29[9]}},a2_29}) <<< 3);
7'd32:p3_29<=-($signed({{4{a2_29[9]}},a2_29}) <<< 4);
7'd36,7'd37,7'd65:p3_29<=-($signed({{4{a2_29[9]}},a2_29}) <<< 3);
7'd40,7'd64:p3_29<=($signed({{4{a2_29[9]}},a2_29}) <<< 4);
7'd80:p3_29<=-($signed({{4{a2_29[9]}},a2_29}) <<< 1);
7'd66:p3_29<=($signed({{4{a2_29[9]}},a2_29}) <<< 1);
default:p3_29<=14'sd0;endcase end end end
logic signed [9:0] b1_30,a2_30;logic signed [14:0] p3_30;
always @(posedge clk)begin if(!rst_n)begin b1_30<=0;a2_30<=0;p3_30<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_30<=((-$signed({2'd0,x0[19]}) + $signed({2'd0,x0[20]})) + ($signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})));
if(valid_pipe[1])a2_30<=mode_pipe[1]?$signed({2'd0,f1[30]}):b1_30;
if(valid_pipe[2])begin case(key2)
7'd0,7'd67:p3_30<=-($signed({{5{a2_30[9]}},a2_30}) <<< 3);
7'd4,7'd64:p3_30<=-($signed({{5{a2_30[9]}},a2_30}) <<< 2);
7'd32,7'd65:p3_30<=-($signed({{5{a2_30[9]}},a2_30}) <<< 4);
7'd33,7'd40:p3_30<=($signed({{5{a2_30[9]}},a2_30}) <<< 5);
7'd36,7'd66:p3_30<=($signed({{5{a2_30[9]}},a2_30}) <<< 3);
7'd37,7'd41:p3_30<=($signed({{5{a2_30[9]}},a2_30}) <<< 4);
7'd80:p3_30<=-($signed({{5{a2_30[9]}},a2_30}) <<< 1);
7'd81,7'd82:p3_30<=($signed({{5{a2_30[9]}},a2_30}) <<< 1);
7'd83:p3_30<=($signed({{5{a2_30[9]}},a2_30}) <<< 0);
default:p3_30<=15'sd0;endcase end end end
logic signed [9:0] b1_31,a2_31;logic signed [14:0] p3_31;
always @(posedge clk)begin if(!rst_n)begin b1_31<=0;a2_31<=0;p3_31<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_31<=(($signed({2'd0,x0[19]}) + -$signed({2'd0,x0[21]})) + (-$signed({2'd0,x0[25]}) + $signed({2'd0,x0[27]})));
if(valid_pipe[1])a2_31<=mode_pipe[1]?$signed({2'd0,f1[31]}):b1_31;
if(valid_pipe[2])begin case(key2)
7'd0,7'd64,7'd65:p3_31<=($signed({{5{a2_31[9]}},a2_31}) <<< 3);
7'd4:p3_31<=-($signed({{5{a2_31[9]}},a2_31}) <<< 4);
7'd32:p3_31<=-($signed({{5{a2_31[9]}},a2_31}) <<< 5);
7'd33,7'd41:p3_31<=($signed({{5{a2_31[9]}},a2_31}) <<< 4);
7'd36,7'd40:p3_31<=($signed({{5{a2_31[9]}},a2_31}) <<< 5);
7'd37:p3_31<=-($signed({{5{a2_31[9]}},a2_31}) <<< 2);
7'd80:p3_31<=-($signed({{5{a2_31[9]}},a2_31}) <<< 0);
7'd81:p3_31<=($signed({{5{a2_31[9]}},a2_31}) <<< 2);
7'd66:p3_31<=($signed({{5{a2_31[9]}},a2_31}) <<< 1);
7'd82:p3_31<=($signed({{5{a2_31[9]}},a2_31}) <<< 0);
default:p3_31<=15'sd0;endcase end end end
logic signed [8:0] b1_32,a2_32;logic signed [13:0] p3_32;
always @(posedge clk)begin if(!rst_n)begin b1_32<=0;a2_32<=0;p3_32<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_32<=($signed({1'd0,x0[24]}) + -$signed({1'd0,x0[26]}));
if(valid_pipe[1])a2_32<=mode_pipe[1]?$signed({1'd0,f1[32]}):b1_32;
if(valid_pipe[2])begin case(key2)
7'd0,7'd64:p3_32<=-($signed({{5{a2_32[8]}},a2_32}) <<< 3);
7'd4,7'd83:p3_32<=-($signed({{5{a2_32[8]}},a2_32}) <<< 1);
7'd32,7'd36,7'd41:p3_32<=-($signed({{5{a2_32[8]}},a2_32}) <<< 5);
7'd33:p3_32<=($signed({{5{a2_32[8]}},a2_32}) <<< 5);
7'd37:p3_32<=($signed({{5{a2_32[8]}},a2_32}) <<< 3);
7'd40,7'd65,7'd66:p3_32<=-($signed({{5{a2_32[8]}},a2_32}) <<< 4);
7'd80:p3_32<=-($signed({{5{a2_32[8]}},a2_32}) <<< 2);
7'd81:p3_32<=($signed({{5{a2_32[8]}},a2_32}) <<< 0);
7'd67:p3_32<=($signed({{5{a2_32[8]}},a2_32}) <<< 4);
default:p3_32<=14'sd0;endcase end end end
logic signed [9:0] b1_33,a2_33;logic signed [15:0] p3_33;
always @(posedge clk)begin if(!rst_n)begin b1_33<=0;a2_33<=0;p3_33<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_33<=($signed({2'd0,x0[25]}) + $signed({2'd0,x0[26]}));
if(valid_pipe[1])a2_33<=mode_pipe[1]?$signed({2'd0,f1[33]}):b1_33;
if(valid_pipe[2])begin case(key2)
7'd0,7'd36,7'd64:p3_33<=($signed({{6{a2_33[9]}},a2_33}) <<< 4);
7'd4,7'd80,7'd66,7'd67:p3_33<=($signed({{6{a2_33[9]}},a2_33}) <<< 1);
7'd32:p3_33<=-($signed({{6{a2_33[9]}},a2_33}) <<< 6);
7'd33,7'd41:p3_33<=($signed({{6{a2_33[9]}},a2_33}) <<< 5);
7'd37:p3_33<=-($signed({{6{a2_33[9]}},a2_33}) <<< 3);
7'd40:p3_33<=-($signed({{6{a2_33[9]}},a2_33}) <<< 4);
7'd65:p3_33<=-($signed({{6{a2_33[9]}},a2_33}) <<< 2);
7'd81:p3_33<=-($signed({{6{a2_33[9]}},a2_33}) <<< 0);
7'd82:p3_33<=($signed({{6{a2_33[9]}},a2_33}) <<< 0);
default:p3_33<=16'sd0;endcase end end end
logic signed [8:0] b1_34,a2_34;logic signed [13:0] p3_34;
always @(posedge clk)begin if(!rst_n)begin b1_34<=0;a2_34<=0;p3_34<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_34<=(-$signed({1'd0,x0[25]}) + $signed({1'd0,x0[26]}));
if(valid_pipe[1])a2_34<=mode_pipe[1]?$signed({1'd0,f1[34]}):b1_34;
if(valid_pipe[2])begin case(key2)
7'd0,7'd4,7'd66:p3_34<=-($signed({{5{a2_34[8]}},a2_34}) <<< 3);
7'd32:p3_34<=-($signed({{5{a2_34[8]}},a2_34}) <<< 5);
7'd33,7'd40:p3_34<=($signed({{5{a2_34[8]}},a2_34}) <<< 5);
7'd36,7'd67:p3_34<=($signed({{5{a2_34[8]}},a2_34}) <<< 4);
7'd37:p3_34<=-($signed({{5{a2_34[8]}},a2_34}) <<< 2);
7'd41:p3_34<=-($signed({{5{a2_34[8]}},a2_34}) <<< 0);
7'd64,7'd81:p3_34<=($signed({{5{a2_34[8]}},a2_34}) <<< 2);
7'd80,7'd83:p3_34<=($signed({{5{a2_34[8]}},a2_34}) <<< 0);
7'd65:p3_34<=($signed({{5{a2_34[8]}},a2_34}) <<< 3);
7'd82:p3_34<=-($signed({{5{a2_34[8]}},a2_34}) <<< 1);
default:p3_34<=14'sd0;endcase end end end
logic signed [8:0] b1_35,a2_35;logic signed [14:0] p3_35;
always @(posedge clk)begin if(!rst_n)begin b1_35<=0;a2_35<=0;p3_35<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_35<=($signed({1'd0,x0[25]}) + -$signed({1'd0,x0[27]}));
if(valid_pipe[1])a2_35<=mode_pipe[1]?$signed({1'd0,f1[35]}):b1_35;
if(valid_pipe[2])begin case(key2)
7'd0,7'd66:p3_35<=($signed({{6{a2_35[8]}},a2_35}) <<< 4);
7'd4,7'd64,7'd81:p3_35<=-($signed({{6{a2_35[8]}},a2_35}) <<< 2);
7'd32:p3_35<=-($signed({{6{a2_35[8]}},a2_35}) <<< 6);
7'd33,7'd40:p3_35<=($signed({{6{a2_35[8]}},a2_35}) <<< 5);
7'd36,7'd41:p3_35<=($signed({{6{a2_35[8]}},a2_35}) <<< 6);
7'd37:p3_35<=-($signed({{6{a2_35[8]}},a2_35}) <<< 4);
7'd80:p3_35<=-($signed({{6{a2_35[8]}},a2_35}) <<< 0);
7'd65:p3_35<=-($signed({{6{a2_35[8]}},a2_35}) <<< 3);
7'd82:p3_35<=($signed({{6{a2_35[8]}},a2_35}) <<< 0);
default:p3_35<=15'sd0;endcase end end end
logic signed [9:0] b1_36,a2_36;logic signed [14:0] p3_36;
always @(posedge clk)begin if(!rst_n)begin b1_36<=0;a2_36<=0;p3_36<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_36<=((-$signed({2'd0,x0[24]}) + $signed({2'd0,x0[26]})) + ($signed({2'd0,x0[30]}) + -$signed({2'd0,x0[32]})));
if(valid_pipe[1])a2_36<=mode_pipe[1]?$signed({2'd0,f1[36]}):b1_36;
if(valid_pipe[2])begin case(key2)
7'd4:p3_36<=-($signed({{5{a2_36[9]}},a2_36}) <<< 4);
7'd32,7'd40,7'd41:p3_36<=-($signed({{5{a2_36[9]}},a2_36}) <<< 5);
7'd33:p3_36<=($signed({{5{a2_36[9]}},a2_36}) <<< 4);
7'd37,7'd65,7'd82,7'd67:p3_36<=-($signed({{5{a2_36[9]}},a2_36}) <<< 2);
7'd64,7'd66:p3_36<=-($signed({{5{a2_36[9]}},a2_36}) <<< 3);
7'd80,7'd83:p3_36<=-($signed({{5{a2_36[9]}},a2_36}) <<< 1);
7'd81:p3_36<=-($signed({{5{a2_36[9]}},a2_36}) <<< 0);
default:p3_36<=15'sd0;endcase end end end
logic signed [9:0] b1_37,a2_37;logic signed [14:0] p3_37;
always @(posedge clk)begin if(!rst_n)begin b1_37<=0;a2_37<=0;p3_37<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_37<=((-$signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})) + ($signed({2'd0,x0[31]}) + $signed({2'd0,x0[32]})));
if(valid_pipe[1])a2_37<=mode_pipe[1]?$signed({2'd0,f1[37]}):b1_37;
if(valid_pipe[2])begin case(key2)
7'd0:p3_37<=($signed({{5{a2_37[9]}},a2_37}) <<< 3);
7'd4:p3_37<=($signed({{5{a2_37[9]}},a2_37}) <<< 1);
7'd32,7'd40:p3_37<=-($signed({{5{a2_37[9]}},a2_37}) <<< 5);
7'd33,7'd41,7'd66:p3_37<=($signed({{5{a2_37[9]}},a2_37}) <<< 4);
7'd36:p3_37<=($signed({{5{a2_37[9]}},a2_37}) <<< 5);
7'd37,7'd80:p3_37<=($signed({{5{a2_37[9]}},a2_37}) <<< 0);
7'd64:p3_37<=-($signed({{5{a2_37[9]}},a2_37}) <<< 3);
7'd67:p3_37<=-($signed({{5{a2_37[9]}},a2_37}) <<< 1);
default:p3_37<=15'sd0;endcase end end end
logic signed [9:0] b1_38,a2_38;logic signed [14:0] p3_38;
always @(posedge clk)begin if(!rst_n)begin b1_38<=0;a2_38<=0;p3_38<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_38<=(($signed({2'd0,x0[25]}) + -$signed({2'd0,x0[26]})) + (-$signed({2'd0,x0[31]}) + $signed({2'd0,x0[32]})));
if(valid_pipe[1])a2_38<=mode_pipe[1]?$signed({2'd0,f1[38]}):b1_38;
if(valid_pipe[2])begin case(key2)
7'd0,7'd4:p3_38<=-($signed({{5{a2_38[9]}},a2_38}) <<< 1);
7'd32:p3_38<=-($signed({{5{a2_38[9]}},a2_38}) <<< 5);
7'd33,7'd67:p3_38<=($signed({{5{a2_38[9]}},a2_38}) <<< 2);
7'd36,7'd65:p3_38<=($signed({{5{a2_38[9]}},a2_38}) <<< 3);
7'd37,7'd41:p3_38<=-($signed({{5{a2_38[9]}},a2_38}) <<< 4);
7'd64,7'd66:p3_38<=-($signed({{5{a2_38[9]}},a2_38}) <<< 3);
7'd80:p3_38<=-($signed({{5{a2_38[9]}},a2_38}) <<< 2);
7'd81:p3_38<=($signed({{5{a2_38[9]}},a2_38}) <<< 1);
7'd82:p3_38<=-($signed({{5{a2_38[9]}},a2_38}) <<< 0);
default:p3_38<=15'sd0;endcase end end end
logic signed [9:0] b1_39,a2_39;logic signed [14:0] p3_39;
always @(posedge clk)begin if(!rst_n)begin b1_39<=0;a2_39<=0;p3_39<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_39<=((-$signed({2'd0,x0[25]}) + $signed({2'd0,x0[27]})) + ($signed({2'd0,x0[31]}) + -$signed({2'd0,x0[33]})));
if(valid_pipe[1])a2_39<=mode_pipe[1]?$signed({2'd0,f1[39]}):b1_39;
if(valid_pipe[2])begin case(key2)
7'd0,7'd65,7'd66:p3_39<=($signed({{5{a2_39[9]}},a2_39}) <<< 3);
7'd4:p3_39<=($signed({{5{a2_39[9]}},a2_39}) <<< 4);
7'd32:p3_39<=-($signed({{5{a2_39[9]}},a2_39}) <<< 5);
7'd33:p3_39<=($signed({{5{a2_39[9]}},a2_39}) <<< 2);
7'd36,7'd41:p3_39<=($signed({{5{a2_39[9]}},a2_39}) <<< 5);
7'd37,7'd64:p3_39<=-($signed({{5{a2_39[9]}},a2_39}) <<< 4);
7'd81,7'd82:p3_39<=($signed({{5{a2_39[9]}},a2_39}) <<< 1);
7'd67:p3_39<=-($signed({{5{a2_39[9]}},a2_39}) <<< 3);
7'd83:p3_39<=-($signed({{5{a2_39[9]}},a2_39}) <<< 1);
default:p3_39<=15'sd0;endcase end end end
logic signed [9:0] b1_40,a2_40;logic signed [13:0] p3_40;
always @(posedge clk)begin if(!rst_n)begin b1_40<=0;a2_40<=0;p3_40<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_40<=(($signed({2'd0,x0[21]}) + -$signed({2'd0,x0[22]})) + (-$signed({2'd0,x0[27]}) + $signed({2'd0,x0[28]})));
if(valid_pipe[1])a2_40<=mode_pipe[1]?$signed({2'd0,f1[40]}):b1_40;
if(valid_pipe[2])begin case(key2)
7'd4,7'd36,7'd82:p3_40<=-($signed({{4{a2_40[9]}},a2_40}) <<< 1);
7'd32,7'd66:p3_40<=($signed({{4{a2_40[9]}},a2_40}) <<< 4);
7'd33,7'd67:p3_40<=-($signed({{4{a2_40[9]}},a2_40}) <<< 3);
7'd40,7'd81:p3_40<=($signed({{4{a2_40[9]}},a2_40}) <<< 1);
7'd41,7'd65:p3_40<=($signed({{4{a2_40[9]}},a2_40}) <<< 3);
7'd64:p3_40<=-($signed({{4{a2_40[9]}},a2_40}) <<< 2);
7'd83:p3_40<=($signed({{4{a2_40[9]}},a2_40}) <<< 0);
default:p3_40<=14'sd0;endcase end end end
logic signed [8:0] b1_41,a2_41;logic signed [13:0] p3_41;
always @(posedge clk)begin if(!rst_n)begin b1_41<=0;a2_41<=0;p3_41<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_41<=($signed({1'd0,x0[22]}) + -$signed({1'd0,x0[28]}));
if(valid_pipe[1])a2_41<=mode_pipe[1]?$signed({1'd0,f1[41]}):b1_41;
if(valid_pipe[2])begin case(key2)
7'd0,7'd64,7'd65,7'd66,7'd67:p3_41<=($signed({{5{a2_41[8]}},a2_41}) <<< 3);
7'd4,7'd36,7'd37:p3_41<=-($signed({{5{a2_41[8]}},a2_41}) <<< 3);
7'd32,7'd40,7'd41:p3_41<=($signed({{5{a2_41[8]}},a2_41}) <<< 4);
7'd33:p3_41<=-($signed({{5{a2_41[8]}},a2_41}) <<< 5);
7'd81,7'd82:p3_41<=($signed({{5{a2_41[8]}},a2_41}) <<< 1);
7'd83:p3_41<=($signed({{5{a2_41[8]}},a2_41}) <<< 0);
default:p3_41<=14'sd0;endcase end end end
logic signed [9:0] b1_42,a2_42;logic signed [13:0] p3_42;
always @(posedge clk)begin if(!rst_n)begin b1_42<=0;a2_42<=0;p3_42<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_42<=((-$signed({2'd0,x0[22]}) + $signed({2'd0,x0[23]})) + ($signed({2'd0,x0[28]}) + -$signed({2'd0,x0[29]})));
if(valid_pipe[1])a2_42<=mode_pipe[1]?$signed({2'd0,f1[42]}):b1_42;
if(valid_pipe[2])begin case(key2)
7'd0,7'd40,7'd41:p3_42<=($signed({{4{a2_42[9]}},a2_42}) <<< 3);
7'd4,7'd36:p3_42<=-($signed({{4{a2_42[9]}},a2_42}) <<< 2);
7'd33:p3_42<=-($signed({{4{a2_42[9]}},a2_42}) <<< 4);
7'd37,7'd67:p3_42<=-($signed({{4{a2_42[9]}},a2_42}) <<< 3);
7'd64,7'd65:p3_42<=($signed({{4{a2_42[9]}},a2_42}) <<< 4);
7'd80:p3_42<=($signed({{4{a2_42[9]}},a2_42}) <<< 1);
7'd81:p3_42<=-($signed({{4{a2_42[9]}},a2_42}) <<< 0);
7'd83:p3_42<=($signed({{4{a2_42[9]}},a2_42}) <<< 0);
default:p3_42<=14'sd0;endcase end end end
logic signed [8:0] b1_43,a2_43;logic signed [12:0] p3_43;
always @(posedge clk)begin if(!rst_n)begin b1_43<=0;a2_43<=0;p3_43<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_43<=($signed({1'd0,x0[27]}) + -$signed({1'd0,x0[28]}));
if(valid_pipe[1])a2_43<=mode_pipe[1]?$signed({1'd0,f1[43]}):b1_43;
if(valid_pipe[2])begin case(key2)
7'd4,7'd33:p3_43<=-($signed({{4{a2_43[8]}},a2_43}) <<< 2);
7'd32,7'd41,7'd65:p3_43<=($signed({{4{a2_43[8]}},a2_43}) <<< 4);
7'd36,7'd83:p3_43<=($signed({{4{a2_43[8]}},a2_43}) <<< 1);
7'd40:p3_43<=($signed({{4{a2_43[8]}},a2_43}) <<< 2);
7'd64:p3_43<=-($signed({{4{a2_43[8]}},a2_43}) <<< 4);
7'd80,7'd82:p3_43<=-($signed({{4{a2_43[8]}},a2_43}) <<< 1);
7'd66:p3_43<=-($signed({{4{a2_43[8]}},a2_43}) <<< 3);
7'd67:p3_43<=($signed({{4{a2_43[8]}},a2_43}) <<< 3);
default:p3_43<=13'sd0;endcase end end end
logic signed [8:0] b1_44,a2_44;logic signed [13:0] p3_44;
always @(posedge clk)begin if(!rst_n)begin b1_44<=0;a2_44<=0;p3_44<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_44<=$signed({1'd0,x0[28]});
if(valid_pipe[1])a2_44<=mode_pipe[1]?$signed({1'd0,f1[44]}):b1_44;
if(valid_pipe[2])begin case(key2)
7'd0,7'd32,7'd41:p3_44<=($signed({{5{a2_44[8]}},a2_44}) <<< 4);
7'd4:p3_44<=-($signed({{5{a2_44[8]}},a2_44}) <<< 1);
7'd33:p3_44<=-($signed({{5{a2_44[8]}},a2_44}) <<< 5);
7'd36:p3_44<=-($signed({{5{a2_44[8]}},a2_44}) <<< 2);
7'd37,7'd64:p3_44<=($signed({{5{a2_44[8]}},a2_44}) <<< 2);
7'd40,7'd66:p3_44<=($signed({{5{a2_44[8]}},a2_44}) <<< 3);
7'd80,7'd82:p3_44<=($signed({{5{a2_44[8]}},a2_44}) <<< 0);
default:p3_44<=14'sd0;endcase end end end
logic signed [8:0] b1_45,a2_45;logic signed [13:0] p3_45;
always @(posedge clk)begin if(!rst_n)begin b1_45<=0;a2_45<=0;p3_45<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_45<=(-$signed({1'd0,x0[28]}) + $signed({1'd0,x0[29]}));
if(valid_pipe[1])a2_45<=mode_pipe[1]?$signed({1'd0,f1[45]}):b1_45;
if(valid_pipe[2])begin case(key2)
7'd0:p3_45<=($signed({{5{a2_45[8]}},a2_45}) <<< 4);
7'd4:p3_45<=($signed({{5{a2_45[8]}},a2_45}) <<< 1);
7'd33:p3_45<=-($signed({{5{a2_45[8]}},a2_45}) <<< 5);
7'd36,7'd67:p3_45<=-($signed({{5{a2_45[8]}},a2_45}) <<< 3);
7'd37,7'd40,7'd64:p3_45<=($signed({{5{a2_45[8]}},a2_45}) <<< 2);
7'd41,7'd80:p3_45<=($signed({{5{a2_45[8]}},a2_45}) <<< 0);
7'd83:p3_45<=-($signed({{5{a2_45[8]}},a2_45}) <<< 2);
default:p3_45<=14'sd0;endcase end end end
logic signed [9:0] b1_46,a2_46;logic signed [13:0] p3_46;
always @(posedge clk)begin if(!rst_n)begin b1_46<=0;a2_46<=0;p3_46<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_46<=((-$signed({2'd0,x0[27]}) + $signed({2'd0,x0[28]})) + ($signed({2'd0,x0[33]}) + -$signed({2'd0,x0[34]})));
if(valid_pipe[1])a2_46<=mode_pipe[1]?$signed({2'd0,f1[46]}):b1_46;
if(valid_pipe[2])begin case(key2)
7'd4:p3_46<=-($signed({{4{a2_46[9]}},a2_46}) <<< 1);
7'd33,7'd40,7'd83:p3_46<=($signed({{4{a2_46[9]}},a2_46}) <<< 1);
7'd36,7'd67:p3_46<=($signed({{4{a2_46[9]}},a2_46}) <<< 2);
7'd41:p3_46<=($signed({{4{a2_46[9]}},a2_46}) <<< 4);
7'd64,7'd66:p3_46<=-($signed({{4{a2_46[9]}},a2_46}) <<< 2);
7'd80,7'd81,7'd82:p3_46<=-($signed({{4{a2_46[9]}},a2_46}) <<< 0);
7'd65:p3_46<=($signed({{4{a2_46[9]}},a2_46}) <<< 3);
default:p3_46<=14'sd0;endcase end end end
logic signed [8:0] b1_47,a2_47;logic signed [12:0] p3_47;
always @(posedge clk)begin if(!rst_n)begin b1_47<=0;a2_47<=0;p3_47<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_47<=(-$signed({1'd0,x0[28]}) + $signed({1'd0,x0[34]}));
if(valid_pipe[1])a2_47<=mode_pipe[1]?$signed({1'd0,f1[47]}):b1_47;
if(valid_pipe[2])begin case(key2)
7'd0,7'd4,7'd65,7'd82:p3_47<=($signed({{4{a2_47[8]}},a2_47}) <<< 2);
7'd33,7'd64:p3_47<=-($signed({{4{a2_47[8]}},a2_47}) <<< 4);
7'd36,7'd41,7'd80:p3_47<=($signed({{4{a2_47[8]}},a2_47}) <<< 1);
7'd37,7'd67:p3_47<=($signed({{4{a2_47[8]}},a2_47}) <<< 4);
7'd40:p3_47<=-($signed({{4{a2_47[8]}},a2_47}) <<< 2);
7'd66:p3_47<=($signed({{4{a2_47[8]}},a2_47}) <<< 3);
7'd83:p3_47<=($signed({{4{a2_47[8]}},a2_47}) <<< 0);
default:p3_47<=13'sd0;endcase end end end
logic signed [9:0] b1_48,a2_48;logic signed [13:0] p3_48;
always @(posedge clk)begin if(!rst_n)begin b1_48<=0;a2_48<=0;p3_48<=0;end else begin
if(valid_pipe[0]&&!mode_pipe[0])b1_48<=(($signed({2'd0,x0[28]}) + -$signed({2'd0,x0[29]})) + (-$signed({2'd0,x0[34]}) + $signed({2'd0,x0[35]})));
if(valid_pipe[1])a2_48<=mode_pipe[1]?0:b1_48;
if(valid_pipe[2])begin case(key2)
7'd0:p3_48<=($signed({{4{a2_48[9]}},a2_48}) <<< 2);
7'd4:p3_48<=($signed({{4{a2_48[9]}},a2_48}) <<< 3);
7'd33:p3_48<=-($signed({{4{a2_48[9]}},a2_48}) <<< 4);
7'd36:p3_48<=-($signed({{4{a2_48[9]}},a2_48}) <<< 2);
7'd37:p3_48<=($signed({{4{a2_48[9]}},a2_48}) <<< 4);
7'd40,7'd41:p3_48<=-($signed({{4{a2_48[9]}},a2_48}) <<< 3);
default:p3_48<=14'sd0;endcase end end end
logic signed [17:0] h_0_0_0;
logic signed [17:0] h_0_0_1;
logic signed [17:0] h_0_1_0;
logic signed [17:0] h_0_1_1;
logic signed [17:0] h_0_2_0;
logic signed [17:0] h_0_2_1;
logic signed [17:0] h_0_3_0;
logic signed [17:0] h_0_3_1;
logic signed [15:0] h_1_0_0;
logic signed [15:0] h_1_0_1;
logic signed [15:0] h_1_1_0;
logic signed [15:0] h_1_1_1;
logic signed [15:0] h_1_2_0;
logic signed [15:0] h_1_2_1;
logic signed [15:0] h_1_3_0;
logic signed [15:0] h_1_3_1;
logic signed [16:0] h_2_0_0;
logic signed [16:0] h_2_0_1;
logic signed [16:0] h_2_1_0;
logic signed [16:0] h_2_1_1;
logic signed [16:0] h_2_2_0;
logic signed [16:0] h_2_2_1;
logic signed [14:0] h_3_0_0;
logic signed [14:0] h_3_0_1;
logic signed [14:0] h_3_1_0;
logic signed [14:0] h_3_1_1;
logic signed [14:0] h_3_2_0;
logic signed [14:0] h_3_2_1;
logic signed [19:0] z_0_0;
logic signed [18:0] z_0_1;
logic signed [18:0] z_0_2;
logic signed [18:0] z_0_3;
logic signed [17:0] z_1_0;
logic signed [17:0] z_1_1;
logic signed [17:0] z_1_2;
logic signed [17:0] z_1_3;
logic signed [17:0] z_2_0;
logic signed [17:0] z_2_1;
logic signed [17:0] z_2_2;
logic signed [17:0] z_2_3;
logic signed [15:0] z_3_0;
logic signed [15:0] z_3_1;
logic signed [15:0] z_3_2;
logic signed [15:0] z_3_3;
logic signed [13:0] fg4_0;
logic signed [14:0] fg4_1;
logic signed [14:0] fg4_2;
logic signed [14:0] fg4_3;
logic signed [14:0] fg4_4;
logic signed [13:0] fg4_5;
logic signed [14:0] fg4_6;
logic signed [14:0] fg4_7;
logic signed [13:0] fg4_8;
logic signed [14:0] fg4_9;
logic signed [14:0] fg4_10;
logic signed [14:0] fg4_11;
logic signed [13:0] fg4_12;
logic signed [13:0] fg4_13;
logic signed [14:0] fg4_14;
logic signed [13:0] fg4_15;
logic signed [16:0] fg5_0;
logic signed [15:0] fg5_1;
logic signed [16:0] fg5_2;
logic signed [15:0] fg5_3;
always @(posedge clk)begin if(!rst_n)begin
h_0_0_0<=0;
h_0_0_1<=0;
h_0_1_0<=0;
h_0_1_1<=0;
h_0_2_0<=0;
h_0_2_1<=0;
h_0_3_0<=0;
h_0_3_1<=0;
h_1_0_0<=0;
h_1_0_1<=0;
h_1_1_0<=0;
h_1_1_1<=0;
h_1_2_0<=0;
h_1_2_1<=0;
h_1_3_0<=0;
h_1_3_1<=0;
h_2_0_0<=0;
h_2_0_1<=0;
h_2_1_0<=0;
h_2_1_1<=0;
h_2_2_0<=0;
h_2_2_1<=0;
h_3_0_0<=0;
h_3_0_1<=0;
h_3_1_0<=0;
h_3_1_1<=0;
h_3_2_0<=0;
h_3_2_1<=0;
fg4_0<=0;
fg4_1<=0;
fg4_2<=0;
fg4_3<=0;
fg4_4<=0;
fg4_5<=0;
fg4_6<=0;
fg4_7<=0;
fg4_8<=0;
fg4_9<=0;
fg4_10<=0;
fg4_11<=0;
fg4_12<=0;
fg4_13<=0;
fg4_14<=0;
fg4_15<=0;
end else if(valid_pipe[3])begin if(!mode_pipe[3])begin
h_0_0_0<=($signed({{2{p3_0[15]}},p3_0}) + ($signed({{2{p3_1[15]}},p3_1}) + $signed({{2{p3_2[15]}},p3_2})));
h_0_0_1<=($signed({{2{p3_1[15]}},p3_1}) + (-$signed({{2{p3_2[15]}},p3_2}) + -$signed({{3{p3_3[14]}},p3_3})));
h_0_1_0<=($signed({{2{p3_4[15]}},p3_4}) + ($signed({{2{p3_5[15]}},p3_5}) + $signed({{3{p3_6[14]}},p3_6})));
h_0_1_1<=($signed({{2{p3_5[15]}},p3_5}) + (-$signed({{3{p3_6[14]}},p3_6}) + -$signed({{2{p3_7[15]}},p3_7})));
h_0_2_0<=($signed({{2{p3_8[15]}},p3_8}) + ($signed({{2{p3_9[15]}},p3_9}) + $signed({{2{p3_10[15]}},p3_10})));
h_0_2_1<=($signed({{2{p3_9[15]}},p3_9}) + (-$signed({{2{p3_10[15]}},p3_10}) + -$signed({{3{p3_11[14]}},p3_11})));
h_0_3_0<=($signed({{2{p3_12[15]}},p3_12}) + ($signed({{3{p3_13[14]}},p3_13}) + $signed({{2{p3_14[15]}},p3_14})));
h_0_3_1<=($signed({{3{p3_13[14]}},p3_13}) + (-$signed({{2{p3_14[15]}},p3_14}) + -$signed({{2{p3_15[15]}},p3_15})));
h_1_0_0<=($signed({{1{p3_16[14]}},p3_16}) + $signed({{1{p3_17[14]}},p3_17}));
h_1_0_1<=($signed({{1{p3_17[14]}},p3_17}) + $signed({{1{p3_18[14]}},p3_18}));
h_1_1_0<=($signed({{1{p3_19[14]}},p3_19}) + $signed({{1{p3_20[14]}},p3_20}));
h_1_1_1<=($signed({{1{p3_20[14]}},p3_20}) + $signed({{1{p3_21[14]}},p3_21}));
h_1_2_0<=($signed({{1{p3_22[14]}},p3_22}) + $signed({{1{p3_23[14]}},p3_23}));
h_1_2_1<=($signed({{1{p3_23[14]}},p3_23}) + $signed({{1{p3_24[14]}},p3_24}));
h_1_3_0<=($signed({{1{p3_25[14]}},p3_25}) + $signed({{1{p3_26[14]}},p3_26}));
h_1_3_1<=($signed({{1{p3_26[14]}},p3_26}) + $signed({{2{p3_27[13]}},p3_27}));
h_2_0_0<=($signed({{2{p3_28[14]}},p3_28}) + ($signed({{3{p3_29[13]}},p3_29}) + $signed({{2{p3_30[14]}},p3_30})));
h_2_0_1<=($signed({{3{p3_29[13]}},p3_29}) + (-$signed({{2{p3_30[14]}},p3_30}) + -$signed({{2{p3_31[14]}},p3_31})));
h_2_1_0<=($signed({{3{p3_32[13]}},p3_32}) + ($signed({{1{p3_33[15]}},p3_33}) + $signed({{3{p3_34[13]}},p3_34})));
h_2_1_1<=($signed({{1{p3_33[15]}},p3_33}) + (-$signed({{3{p3_34[13]}},p3_34}) + -$signed({{2{p3_35[14]}},p3_35})));
h_2_2_0<=($signed({{2{p3_36[14]}},p3_36}) + ($signed({{2{p3_37[14]}},p3_37}) + $signed({{2{p3_38[14]}},p3_38})));
h_2_2_1<=($signed({{2{p3_37[14]}},p3_37}) + (-$signed({{2{p3_38[14]}},p3_38}) + -$signed({{2{p3_39[14]}},p3_39})));
h_3_0_0<=($signed({{1{p3_40[13]}},p3_40}) + $signed({{1{p3_41[13]}},p3_41}));
h_3_0_1<=($signed({{1{p3_41[13]}},p3_41}) + $signed({{1{p3_42[13]}},p3_42}));
h_3_1_0<=($signed({{2{p3_43[12]}},p3_43}) + $signed({{1{p3_44[13]}},p3_44}));
h_3_1_1<=($signed({{1{p3_44[13]}},p3_44}) + $signed({{1{p3_45[13]}},p3_45}));
h_3_2_0<=($signed({{1{p3_46[13]}},p3_46}) + $signed({{2{p3_47[12]}},p3_47}));
h_3_2_1<=($signed({{2{p3_47[12]}},p3_47}) + $signed({{1{p3_48[13]}},p3_48}));
end else begin
fg4_0<=($signed(p3_0[13:0]) + ($signed(p3_1[13:0]) + $signed(p3_2[13:0])));
fg4_1<=($signed(p3_3) + ($signed(p3_4[14:0]) + $signed(p3_5[14:0])));
fg4_2<=($signed(p3_6) + ($signed(p3_7[14:0]) + $signed(p3_8[14:0])));
fg4_3<=($signed(p3_9[14:0]) + ($signed(p3_10[14:0]) + $signed(p3_11)));
fg4_4<=($signed(p3_12[14:0]) + ($signed(p3_13) + $signed(p3_14[14:0])));
fg4_5<=($signed(p3_15[13:0]) + ($signed(p3_16[13:0]) + $signed(p3_17[13:0])));
fg4_6<=($signed(p3_18) + ($signed(p3_19) + $signed(p3_20)));
fg4_7<=($signed(p3_21) + ($signed(p3_22) + $signed(p3_23)));
fg4_8<=($signed(p3_24[13:0]) + ($signed(p3_25[13:0]) + $signed(p3_26[13:0])));
fg4_9<=($signed({{1{p3_27[13]}},p3_27}) + ($signed(p3_28) + $signed({{1{p3_29[13]}},p3_29})));
fg4_10<=($signed(p3_30) + ($signed(p3_31) + $signed({{1{p3_32[13]}},p3_32})));
fg4_11<=($signed(p3_33[14:0]) + ($signed({{1{p3_34[13]}},p3_34}) + $signed(p3_35)));
fg4_12<=($signed(p3_36[13:0]) + ($signed(p3_37[13:0]) + $signed(p3_38[13:0])));
fg4_13<=($signed(p3_39[13:0]) + ($signed(p3_40) + $signed(p3_41)));
fg4_14<=($signed({{1{p3_42[13]}},p3_42}) + ($signed({{2{p3_43[12]}},p3_43}) + $signed({{1{p3_44[13]}},p3_44})));
fg4_15<=($signed(p3_45) + ($signed(p3_46) + $signed({{1{p3_47[12]}},p3_47})));
end end end
always @(posedge clk)begin if(!rst_n)begin
z_0_0<=0;
z_0_1<=0;
z_0_2<=0;
z_0_3<=0;
z_1_0<=0;
z_1_1<=0;
z_1_2<=0;
z_1_3<=0;
z_2_0<=0;
z_2_1<=0;
z_2_2<=0;
z_2_3<=0;
z_3_0<=0;
z_3_1<=0;
z_3_2<=0;
z_3_3<=0;
fg5_0<=0;
fg5_1<=0;
fg5_2<=0;
fg5_3<=0;
end else if(valid_pipe[4])begin if(!mode_pipe[4])begin
z_0_0<=($signed({{2{h_0_0_0[17]}},h_0_0_0}) + ($signed({{2{h_0_1_0[17]}},h_0_1_0}) + $signed({{2{h_0_2_0[17]}},h_0_2_0})));
z_0_1<=($signed({{1{h_0_0_1[17]}},h_0_0_1}) + ($signed({{1{h_0_1_1[17]}},h_0_1_1}) + $signed({{1{h_0_2_1[17]}},h_0_2_1})));
z_0_2<=($signed({{1{h_0_1_0[17]}},h_0_1_0}) + (-$signed({{1{h_0_2_0[17]}},h_0_2_0}) + -$signed({{1{h_0_3_0[17]}},h_0_3_0})));
z_0_3<=($signed({{1{h_0_1_1[17]}},h_0_1_1}) + (-$signed({{1{h_0_2_1[17]}},h_0_2_1}) + -$signed({{1{h_0_3_1[17]}},h_0_3_1})));
z_1_0<=($signed({{2{h_1_0_0[15]}},h_1_0_0}) + ($signed({{2{h_1_1_0[15]}},h_1_1_0}) + $signed({{2{h_1_2_0[15]}},h_1_2_0})));
z_1_1<=($signed({{2{h_1_0_1[15]}},h_1_0_1}) + ($signed({{2{h_1_1_1[15]}},h_1_1_1}) + $signed({{2{h_1_2_1[15]}},h_1_2_1})));
z_1_2<=($signed({{2{h_1_1_0[15]}},h_1_1_0}) + (-$signed({{2{h_1_2_0[15]}},h_1_2_0}) + -$signed({{2{h_1_3_0[15]}},h_1_3_0})));
z_1_3<=($signed({{2{h_1_1_1[15]}},h_1_1_1}) + (-$signed({{2{h_1_2_1[15]}},h_1_2_1}) + -$signed({{2{h_1_3_1[15]}},h_1_3_1})));
z_2_0<=($signed({{1{h_2_0_0[16]}},h_2_0_0}) + $signed({{1{h_2_1_0[16]}},h_2_1_0}));
z_2_1<=($signed({{1{h_2_0_1[16]}},h_2_0_1}) + $signed({{1{h_2_1_1[16]}},h_2_1_1}));
z_2_2<=($signed({{1{h_2_1_0[16]}},h_2_1_0}) + $signed({{1{h_2_2_0[16]}},h_2_2_0}));
z_2_3<=($signed({{1{h_2_1_1[16]}},h_2_1_1}) + $signed({{1{h_2_2_1[16]}},h_2_2_1}));
z_3_0<=($signed({{1{h_3_0_0[14]}},h_3_0_0}) + $signed({{1{h_3_1_0[14]}},h_3_1_0}));
z_3_1<=($signed({{1{h_3_0_1[14]}},h_3_0_1}) + $signed({{1{h_3_1_1[14]}},h_3_1_1}));
z_3_2<=($signed({{1{h_3_1_0[14]}},h_3_1_0}) + $signed({{1{h_3_2_0[14]}},h_3_2_0}));
z_3_3<=($signed({{1{h_3_1_1[14]}},h_3_1_1}) + $signed({{1{h_3_2_1[14]}},h_3_2_1}));
end else begin
fg5_0<=(($signed({{3{fg4_0[13]}},fg4_0}) + $signed({{2{fg4_1[14]}},fg4_1})) + ($signed({{2{fg4_2[14]}},fg4_2}) + $signed({{2{fg4_3[14]}},fg4_3})));
fg5_1<=(($signed({{1{fg4_4[14]}},fg4_4}) + $signed({{2{fg4_5[13]}},fg4_5})) + ($signed({{1{fg4_6[14]}},fg4_6}) + $signed({{1{fg4_7[14]}},fg4_7})));
fg5_2<=(($signed({{3{fg4_8[13]}},fg4_8}) + $signed({{2{fg4_9[14]}},fg4_9})) + ($signed({{2{fg4_10[14]}},fg4_10}) + $signed({{2{fg4_11[14]}},fg4_11})));
fg5_3<=(($signed({{2{fg4_12[13]}},fg4_12}) + $signed({{2{fg4_13[13]}},fg4_13})) + ($signed({{1{fg4_14[14]}},fg4_14}) + $signed({{2{fg4_15[13]}},fg4_15})));
end end end
always @(posedge clk)begin if(!rst_n)begin conv_y00<=0;conv_y01<=0;conv_y10<=0;conv_y11<=0;fc_sum<=0;end
else if(valid_pipe[5])begin if(!mode_pipe[5])begin
conv_y00<=((($signed({{12{z_0_0[19]}},z_0_0}) >>> 2) + ($signed({{14{z_1_0[17]}},z_1_0}) >>> 1)) + (($signed({{14{z_2_0[17]}},z_2_0}) >>> 1) + ($signed({{16{z_3_0[15]}},z_3_0}) >>> 0)));
conv_y01<=((($signed({{13{z_0_1[18]}},z_0_1}) >>> 2) + ($signed({{14{z_1_1[17]}},z_1_1}) >>> 1)) + (($signed({{14{z_2_1[17]}},z_2_1}) >>> 1) + ($signed({{16{z_3_1[15]}},z_3_1}) >>> 0)));
conv_y10<=((($signed({{13{z_0_2[18]}},z_0_2}) >>> 2) + ($signed({{14{z_1_2[17]}},z_1_2}) >>> 1)) + (($signed({{14{z_2_2[17]}},z_2_2}) >>> 1) + ($signed({{16{z_3_2[15]}},z_3_2}) >>> 0)));
conv_y11<=((($signed({{13{z_0_3[18]}},z_0_3}) >>> 2) + ($signed({{14{z_1_3[17]}},z_1_3}) >>> 1)) + (($signed({{14{z_2_3[17]}},z_2_3}) >>> 1) + ($signed({{16{z_3_3[15]}},z_3_3}) >>> 0)));
end else begin fc_sum<=(($signed({{15{fg5_0[16]}},fg5_0}) + $signed({{16{fg5_1[15]}},fg5_1})) + ($signed({{15{fg5_2[16]}},fg5_2}) + $signed({{16{fg5_3[15]}},fg5_3})));end end end
endmodule
```

## v25_dash/examples/synthetic_only/v25h/shift/v25_dash_top.sv

```systemverilog
`timescale 1ps/1ps
// Derived from V25-H controller, commit 0d345f1. Continuous byte stream; one prime cycle after reset.
// DASH adaptation: four classes, train-derived scales, signed32 bias/score, RNE+U8 saturation.
module v25_dash_top(input logic clk,rst_n,input logic [7:0] data_in,
                   output logic [1:0] decision,output logic valid_out_6,output wire [127:0] logits);
    localparam ST_STREAM = 2'd0;
    localparam ST_FC     = 2'd1;
    localparam ST_DONE   = 2'd2;
    logic [1:0] state;

    // -------------------------------------------------------------------------
    // External input stream storage.
    // Explicit row/col/slot counters replace /28, %28 and %7 address arithmetic.
    // -------------------------------------------------------------------------
    logic [7:0] linebuf [0:6][0:27];
    logic [9:0] pixels_stored;
    logic       capture_primed;
    logic [4:0] cap_row, cap_col;
    logic [2:0] cap_slot;

    // Conv1 local 6x6 sliding window.
    // The engine sees only this register bank, not a dynamic 7x28 column mux.
    logic        [7:0]  c1_window [0:5][0:5];
    logic               c1_window_valid;
    logic [4:0]         c1_new_col;  // two entering columns for next stride-2 tile

    // Pool outputs. V6 retains only seven logical fmap1 rows at a time.
    // V25-H stores post-ReLU pooled values directly as unsigned 8-bit data.
    // Conv1 keeps two physical channels: 2 x 7 x 12 x 8 = 1344 payload bits.
    logic        [7:0] fmap1_ring [0:1][0:6][0:11];
    logic        [7:0] fmap2 [0:2][0:3][0:3];

    // -------------------------------------------------------------------------
    // Conv1 progress.
    // c1_base_slot = (2*c1_issue_pr) mod 7, maintained incrementally.
    // -------------------------------------------------------------------------
    logic [3:0] c1_issue_pr, c1_issue_pc;
    logic       c1_issue_oc;
    logic [2:0] c1_base_slot;
    logic [8:0] c1_issue_count;
    logic [8:0] c1_commit_count;

    // Conv1 writeback pipeline. WB0 registers the four quantized values; the
    // following cycle performs only 4-way max/ReLU and commits to fmap1_ring.
    logic c1_wb_valid;
    logic [2:0] c1_wb_slot;
    logic [3:0] c1_wb_pc;
    logic       c1_wb_oc;
    logic signed [11:0] c1_wb_q00, c1_wb_q01, c1_wb_q10, c1_wb_q11;

    // Conv2 progress.
    logic [1:0] c2_issue_pr, c2_issue_pc;
    logic [1:0] c2_issue_oc;
    logic       c2_issue_ic;
    // Physical ring slot corresponding to logical Conv2 window start row
    // (2*c2_issue_pr) mod 7. Updated only when Conv2 advances to next row.
    logic [2:0] c2_base_slot;
    logic [7:0] c2_issue_count;
    logic [7:0] c2_rsp_count;
    logic signed [31:0] c2_acc00, c2_acc01, c2_acc10, c2_acc11;

    // Conv2 writeback pipeline. the prior critical path ran directly from the
    // engine output register through final channel accumulation, quantization,
    // max-pool/ReLU and into fmap2. V4 cuts that cone into three short stages.
    logic c2_wb0_valid, c2_wb1_valid;
    logic [1:0] c2_wb0_pr, c2_wb0_pc, c2_wb0_oc;
    logic [1:0] c2_wb1_pr, c2_wb1_pc, c2_wb1_oc;
    logic signed [31:0] c2_wb0_sum00, c2_wb0_sum01, c2_wb0_sum10, c2_wb0_sum11;
    logic signed [11:0] c2_wb1_q00, c2_wb1_q01, c2_wb1_q10, c2_wb1_q11;
    logic [5:0] c2_commit_count;

    // FC progress: two temporal PoT1 requests per class implement SP2 exactly.
    logic [3:0] fc_issue_class;
    logic [4:0] fc_issue_count;
    logic       fc_issue_term;
    logic signed [31:0] fc_term0_sum;
    logic signed [31:0] best_score;
    logic [3:0] best_idx;

    // -------------------------------------------------------------------------
    // Helpers.
    // -------------------------------------------------------------------------
    localparam integer C1_RESTORE_SHIFT=0,C2_RESTORE_SHIFT=0;
    localparam integer FC_TWO_PASS=1;
function automatic signed [31:0] get_b1(input integer idx);begin case(idx)
0:get_b1=32'sd0;
1:get_b1=32'sd0;
default:get_b1=0;endcase end endfunction
function automatic signed [31:0] get_b2(input integer idx);begin case(idx)
0:get_b2=32'sd0;
1:get_b2=32'sd0;
2:get_b2=32'sd0;
default:get_b2=0;endcase end endfunction
function automatic signed [31:0] get_fcb(input integer idx);begin case(idx)
0:get_fcb=32'sd0;
1:get_fcb=32'sd0;
2:get_fcb=32'sd0;
3:get_fcb=32'sd0;
default:get_fcb=0;endcase end endfunction
function automatic [7:0] quant_u8(input signed [31:0] raw,input integer shift);
reg signed [63:0] base,rem,half;begin base=$signed(raw)>>>shift;
if(shift>0)begin rem=$signed(raw)-(base<<<shift);half=64'sd1<<<(shift-1);
if(rem>half||(rem==half&&base[0]))base=base+1;end
if(base<0)quant_u8=0;else if(base>255)quant_u8=255;else quant_u8=base[7:0];end endfunction
function automatic signed [11:0] conv1_q(input signed [31:0] raw,bias32);begin conv1_q={4'd0,quant_u8(raw+bias32,4)};end endfunction
function automatic signed [11:0] conv2_q(input signed [31:0] raw,bias32);begin conv2_q={4'd0,quant_u8(raw+bias32,6)};end endfunction
function automatic [7:0] max4_relu_a8(input signed [11:0] a,b,c,d);reg signed [11:0] m;begin
m=a;if(b>m)m=b;if(c>m)m=c;if(d>m)m=d;max4_relu_a8=m[7:0];end endfunction
logic signed [31:0] scores[0:3];integer score_clear;
assign logits={scores[3],scores[2],scores[1],scores[0]};
    function automatic [2:0] add_mod7(
        input logic [2:0] base,
        input integer off
    );
        integer tmp;
        begin
            tmp = base + off;
            if (tmp >= 7) tmp = tmp - 7;
            add_mod7 = tmp[2:0];
        end
    endfunction

    // -------------------------------------------------------------------------
    // Shared V6 engine.
    // -------------------------------------------------------------------------
    logic req_valid, req_is_fc;
    logic [15:0] req_tag;
    logic signed [8:0] req_tile [0:5][0:5];
    logic signed [8:0] req_fc_a [0:47];

    logic rsp_valid, rsp_is_fc;
    logic [15:0] rsp_tag;
    logic signed [31:0] rsp_y00, rsp_y01, rsp_y10, rsp_y11;
    logic signed [31:0] rsp_fc_sum;

    v25_dash_engine u_engine (
        .clk(clk), .rst_n(rst_n),
        .req_valid(req_valid), .req_is_fc(req_is_fc), .req_tag(req_tag),
        .conv_tile(req_tile), .fc_a(req_fc_a),
        .rsp_valid(rsp_valid), .rsp_is_fc(rsp_is_fc), .rsp_tag(rsp_tag),
        .conv_y00(rsp_y00), .conv_y01(rsp_y01),
        .conv_y10(rsp_y10), .conv_y11(rsp_y11),
        .fc_sum(rsp_fc_sum)
    );

    // -------------------------------------------------------------------------
    // Dependency checks.
    // -------------------------------------------------------------------------
    logic c1_tile_ready;
    integer c2_required_commit_idx;
    logic c2_data_ready;

    always_comb begin
        // V6 issues Conv1 only from the local sliding window. The row-start
        // window becomes valid on the same capture edge that makes V6's first
        // tile ready; subsequent horizontal tiles are shifted in-place.
        c1_tile_ready = (c1_issue_count < 9'd288) && c1_window_valid;

        // fmap1 is produced row-major, col-major, then two physical channels.
        // Physical ic0/ic1 map to original Conv1 channels 1/2.
        c2_required_commit_idx = (((c2_issue_pr*2 + 5) * 12
                                 + (c2_issue_pc*2 + 5)) * 2
                                 + c2_issue_ic);
        c2_data_ready = (c2_issue_count < 8'd96)
                     && (c1_commit_count > c2_required_commit_idx);
    end

    // -------------------------------------------------------------------------
    // Dependency-aware request scheduler.
    // Conv1 gets priority so the 7-line input buffer safety proof remains the
    // same as V2. Conv2 uses only otherwise-idle Conv1 cycles until C1 finishes.
    // -------------------------------------------------------------------------
    integer rr, cc, kk, lane, ch, pos;
    logic issue_c1, issue_c2;
    always_comb begin
        req_valid = 1'b0;
        req_is_fc = 1'b0;
        req_tag   = 16'd0;
        issue_c1  = 1'b0;
        issue_c2  = 1'b0;
        kk = 0;
        ch = 0;
        pos = 0;

        for (rr = 0; rr < 6; rr = rr + 1)
            for (cc = 0; cc < 6; cc = cc + 1)
                req_tile[rr][cc] = 9'sd0;

        for (lane = 0; lane < 48; lane = lane + 1) begin
            req_fc_a[lane] = 9'sd0;
        end

        if (state == ST_STREAM) begin
            if (c1_tile_ready) begin
                issue_c1 = 1'b1;
                req_valid = 1'b1;
                req_is_fc = 1'b0;
                req_tag = {1'b0, 3'b000, c1_issue_pr, c1_issue_pc, 1'b0, c1_issue_oc, 2'b00};

                // Fixed/local wiring: no c1_issue_pc-driven 28-column mux.
                for (rr = 0; rr < 6; rr = rr + 1)
                    for (cc = 0; cc < 6; cc = cc + 1)
                        req_tile[rr][cc] = {1'b0,c1_window[rr][cc]};
            end else if (c2_data_ready) begin
                issue_c2 = 1'b1;
                req_valid = 1'b1;
                req_is_fc = 1'b0;
                req_tag = {1'b1, 3'b000, {2'b00,c2_issue_pr},
                           {2'b00,c2_issue_pc}, c2_issue_oc, 1'b0, c2_issue_ic};

                for (rr = 0; rr < 6; rr = rr + 1)
                    for (cc = 0; cc < 6; cc = cc + 1)
                        req_tile[rr][cc] = {1'b0, fmap1_ring[c2_issue_ic]
                            [add_mod7(c2_base_slot,rr)][c2_issue_pc*2+cc]};
            end
        end else if (state == ST_FC && fc_issue_count < 5'd8) begin
            req_valid = 1'b1;
            req_is_fc = 1'b1;
            req_tag = {11'd0,fc_issue_term,fc_issue_class};

            for (lane = 0; lane < 48; lane = lane + 1) begin
                ch  = lane / 16;
                pos = lane % 16;
                req_fc_a[lane] = {1'b0,fmap2[ch][pos/4][pos%4]};
            end
        end
    end

    // -------------------------------------------------------------------------
    // Response decode / fixed-point behavior.
    // -------------------------------------------------------------------------
    wire rsp_layer = rsp_tag[15];
    wire [3:0] rsp_pr = rsp_tag[11:8];
    wire [3:0] rsp_pc = rsp_tag[7:4];
    wire [1:0] rsp_oc = rsp_tag[3:2];
    wire [1:0] rsp_ic = rsp_tag[1:0];
    wire [3:0] rsp_fc_class = rsp_tag[3:0];
    wire       rsp_fc_term  = rsp_tag[4];

    logic signed [11:0] rsp_c1q00, rsp_c1q01, rsp_c1q10, rsp_c1q11;
    logic signed [31:0] rsp_eng20_00, rsp_eng20_01, rsp_eng20_10, rsp_eng20_11;
    logic signed [11:0] c2_wb0_q00, c2_wb0_q01, c2_wb0_q10, c2_wb0_q11;
    logic signed [31:0] fc_score_now;
    logic signed [31:0] fc_class_sum;
    logic [13:0] fc_sum_mod14;
    logic [11:0] fc_base12;
    logic [1:0]  fc_rem2;
    logic signed [8:0] fc_low9;

    always_comb begin
        rsp_c1q00 = conv1_q($signed(rsp_y00) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q01 = conv1_q($signed(rsp_y01) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q10 = conv1_q($signed(rsp_y10) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q11 = conv1_q($signed(rsp_y11) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));

        rsp_eng20_00 = $signed(rsp_y00[31:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_01 = $signed(rsp_y01[31:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_10 = $signed(rsp_y10[31:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_11 = $signed(rsp_y11[31:0]) <<< C2_RESTORE_SHIFT;

        // WB1 quantization is now isolated from engine-output accumulation.
        c2_wb0_q00 = conv2_q(c2_wb0_sum00,get_b2(c2_wb0_oc));
        c2_wb0_q01 = conv2_q(c2_wb0_sum01,get_b2(c2_wb0_oc));
        c2_wb0_q10 = conv2_q(c2_wb0_sum10,get_b2(c2_wb0_oc));
        c2_wb0_q11 = conv2_q(c2_wb0_sum11,get_b2(c2_wb0_oc));

        fc_class_sum = (FC_TWO_PASS ? fc_term0_sum : 32'sd0) + rsp_fc_sum;
        fc_score_now = fc_class_sum + get_fcb(rsp_fc_class);
    end

    // -------------------------------------------------------------------------
    // Main controller.
    // -------------------------------------------------------------------------
    integer c1wr, c1wc;
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= ST_STREAM;
            pixels_stored <= 10'd0;
            capture_primed <= 1'b0;
            cap_row <= 0;
            cap_col <= 0;
            cap_slot <= 0;
            c1_window_valid <= 1'b0;
            c1_new_col <= 5'd6;

            c1_issue_pr <= 0; c1_issue_pc <= 0; c1_issue_oc <= 0;
            c1_base_slot <= 0;
            c1_issue_count <= 0; c1_commit_count <= 0;
            c1_wb_valid <= 1'b0;
            c1_wb_slot <= 0; c1_wb_pc <= 0; c1_wb_oc <= 0;
            c1_wb_q00 <= 0; c1_wb_q01 <= 0;
            c1_wb_q10 <= 0; c1_wb_q11 <= 0;

            c2_issue_pr <= 0; c2_issue_pc <= 0;
            c2_issue_oc <= 0; c2_issue_ic <= 0;
            c2_base_slot <= 0;
            c2_issue_count <= 0; c2_rsp_count <= 0;
            c2_acc00 <= 0; c2_acc01 <= 0; c2_acc10 <= 0; c2_acc11 <= 0;

            c2_wb0_valid <= 1'b0;
            c2_wb1_valid <= 1'b0;
            c2_wb0_pr <= 0; c2_wb0_pc <= 0; c2_wb0_oc <= 0;
            c2_wb1_pr <= 0; c2_wb1_pc <= 0; c2_wb1_oc <= 0;
            c2_wb0_sum00 <= 0; c2_wb0_sum01 <= 0;
            c2_wb0_sum10 <= 0; c2_wb0_sum11 <= 0;
            c2_wb1_q00 <= 0; c2_wb1_q01 <= 0;
            c2_wb1_q10 <= 0; c2_wb1_q11 <= 0;
            c2_commit_count <= 0;

            fc_issue_class <= 0;
            fc_issue_count <= 0;
            fc_issue_term <= 1'b0;
            fc_term0_sum <= 32'sd0;
            best_score <= 32'sh80000000;
            best_idx <= 0;

            for(score_clear=0;score_clear<4;score_clear=score_clear+1)scores[score_clear]<=0;
            decision <= 0;
            valid_out_6 <= 1'b0;
        end else begin
            valid_out_6 <= 1'b0;

            // Conv1 writeback pipeline. The response cycle performs only the
            // fixed-point quantization into WB0. The next cycle performs the
            // max/ReLU and writes one pooled value into the seven-row ring.
            c1_wb_valid <= 1'b0;
            if (c1_wb_valid) begin
                fmap1_ring[c1_wb_oc][c1_wb_slot][c1_wb_pc] <=
                    max4_relu_a8(c1_wb_q00,c1_wb_q01,c1_wb_q10,c1_wb_q11);
                c1_commit_count <= c1_commit_count + 1'b1;
            end

            // Conv2 writeback pipeline advances every cycle.
            c2_wb0_valid <= 1'b0;
            c2_wb1_valid <= c2_wb0_valid;
            if (c2_wb0_valid) begin
                c2_wb1_pr <= c2_wb0_pr;
                c2_wb1_pc <= c2_wb0_pc;
                c2_wb1_oc <= c2_wb0_oc;
                c2_wb1_q00 <= c2_wb0_q00;
                c2_wb1_q01 <= c2_wb0_q01;
                c2_wb1_q10 <= c2_wb0_q10;
                c2_wb1_q11 <= c2_wb0_q11;
            end

            // Commit pooled Conv2 output from the isolated WB1 stage.
            if (c2_wb1_valid) begin
                fmap2[c2_wb1_oc][c2_wb1_pr][c2_wb1_pc] <=
                    max4_relu_a8(c2_wb1_q00,c2_wb1_q01,c2_wb1_q10,c2_wb1_q11);
                c2_commit_count <= c2_commit_count + 1'b1;

                // Start FC only after the 48th pooled fmap2 value is committed.
                if (c2_commit_count == 6'd47) begin
                    state <= ST_FC;
                    fc_issue_class <= 0;
                    fc_issue_count <= 0;
                    fc_issue_term <= 1'b0;
                    fc_term0_sum <= 32'sd0;
                    best_score <= 32'sh80000000;
                    best_idx <= 0;
                end
            end

            // Input capture continues independently of C1/C2 scheduling.
            if (pixels_stored < 10'd784) begin
                if (!capture_primed) begin
                    capture_primed <= 1'b1;
                end else begin
                    linebuf[cap_slot][cap_col] <= data_in;
                    pixels_stored <= pixels_stored + 1'b1;

                    // Row-start preload for the current Conv1 pooled row.
                    // It fires on the exact edge that captures raw column 5 of
                    // the sixth required input row. All other 35 bytes already
                    // reside in the seven-row line buffer; the just-arriving
                    // bottom-right byte bypasses the linebuf NBA write.
                    if (!c1_window_valid &&
                        (c1_issue_pc == 4'd0) &&
                        (c1_issue_oc == 2'd0) &&
                        (cap_col == 5'd5) &&
                        (cap_row == ({c1_issue_pr,1'b0} + 5'd5))) begin
                        for (c1wr = 0; c1wr < 6; c1wr = c1wr + 1) begin
                            for (c1wc = 0; c1wc < 6; c1wc = c1wc + 1) begin
                                if ((c1wr == 5) && (c1wc == 5))
                                    c1_window[c1wr][c1wc] <= data_in;
                                else
                                    c1_window[c1wr][c1wc] <=
                                        linebuf[add_mod7(c1_base_slot,c1wr)][c1wc];
                            end
                        end
                        c1_window_valid <= 1'b1;
                        c1_new_col <= 5'd6;
                    end

                    if (cap_col == 5'd27) begin
                        cap_col <= 0;
                        if (cap_row < 5'd27)
                            cap_row <= cap_row + 1'b1;
                        cap_slot <= (cap_slot == 3'd6) ? 3'd0 : cap_slot + 1'b1;
                    end else begin
                        cap_col <= cap_col + 1'b1;
                    end
                end
            end

            // Request-side progress. Conv1 reuses the same local 6x6 window
            // for the two surviving output channels. After physical channel 1, the
            // window advances by stride 2: four columns are retained and only two entering
            // columns (12 bytes total) are fetched from linebuf.
            if (req_valid && !req_is_fc && issue_c1) begin
                c1_issue_count <= c1_issue_count + 1'b1;
                if (c1_issue_oc == 1'b0) begin
                    c1_issue_oc <= 1'b1;
                end else begin
                    c1_issue_oc <= 0;
                    if (c1_issue_pc < 11) begin
                        for (c1wr = 0; c1wr < 6; c1wr = c1wr + 1) begin
                            c1_window[c1wr][0] <= c1_window[c1wr][2];
                            c1_window[c1wr][1] <= c1_window[c1wr][3];
                            c1_window[c1wr][2] <= c1_window[c1wr][4];
                            c1_window[c1wr][3] <= c1_window[c1wr][5];
                            c1_window[c1wr][4] <=
                                linebuf[add_mod7(c1_base_slot,c1wr)][c1_new_col];
                            // With only two Conv1 channels, the horizontal
                            // window advances one cycle earlier than V24.
                            // The newest bottom-row byte is being captured on
                            // this same edge, so bypass the linebuf NBA write.
                            if ((c1wr == 5) &&
                                (cap_row == ({c1_issue_pr,1'b0} + 5'd5)) &&
                                (cap_col == (c1_new_col + 1'b1)))
                                c1_window[c1wr][5] <= data_in;
                            else
                                c1_window[c1wr][5] <=
                                    linebuf[add_mod7(c1_base_slot,c1wr)][c1_new_col + 1'b1];
                        end
                        c1_new_col <= c1_new_col + 5'd2;
                        c1_issue_pc <= c1_issue_pc + 1'b1;
                    end else begin
                        // Next pooled row starts again at raw columns 0..5.
                        // Its window is reloaded by the input-capture preload
                        // above when the new bottom row reaches column 5.
                        c1_window_valid <= 1'b0;
                        c1_new_col <= 5'd6;
                        c1_issue_pc <= 0;
                        if (c1_issue_pr < 11) begin
                            c1_issue_pr <= c1_issue_pr + 1'b1;
                            c1_base_slot <= add_mod7(c1_base_slot,2);
                        end
                    end
                end
            end

            if (req_valid && !req_is_fc && issue_c2) begin
                c2_issue_count <= c2_issue_count + 1'b1;
                if (c2_issue_ic == 1'b0) begin
                    c2_issue_ic <= 1'b1;
                end else begin
                    c2_issue_ic <= 1'b0;
                    if (c2_issue_oc < 2) begin
                        c2_issue_oc <= c2_issue_oc + 1'b1;
                    end else begin
                        c2_issue_oc <= 0;
                        if (c2_issue_pc < 3) begin
                            c2_issue_pc <= c2_issue_pc + 1'b1;
                        end else begin
                            c2_issue_pc <= 0;
                            if (c2_issue_pr < 3) begin
                                c2_issue_pr <= c2_issue_pr + 1'b1;
                                c2_base_slot <= add_mod7(c2_base_slot,2);
                            end
                        end
                    end
                end
            end

            if(req_valid && req_is_fc && state==ST_FC)begin
                fc_issue_count<=fc_issue_count+1'b1;
                if(FC_TWO_PASS && !fc_issue_term)fc_issue_term<=1'b1;
                else begin fc_issue_term<=0;if(fc_issue_class<3)fc_issue_class<=fc_issue_class+1'b1;end
            end

            // Conv1 response -> WB0 quantization register. Pool/ReLU and the
            // physical ring write occur on the following cycle above.
            if (rsp_valid && !rsp_is_fc && (rsp_layer == 1'b0)) begin
                c1_wb_valid <= 1'b1;
                c1_wb_slot <= add_mod7(3'd0,rsp_pr);
                c1_wb_pc <= rsp_pc;
                c1_wb_oc <= rsp_oc;
                c1_wb_q00 <= rsp_c1q00;
                c1_wb_q01 <= rsp_c1q01;
                c1_wb_q10 <= rsp_c1q10;
                c1_wb_q11 <= rsp_c1q11;
            end

            // Conv2 response -> two-input-channel accumulation.
            // The second input-channel result is captured into WB0 instead of running
            // accumulation + quantization + pool/ReLU in one cycle.
            if (rsp_valid && !rsp_is_fc && (rsp_layer == 1'b1)) begin
                c2_rsp_count <= c2_rsp_count + 1'b1;

                if (rsp_ic == 0) begin
                    c2_acc00 <= rsp_eng20_00;
                    c2_acc01 <= rsp_eng20_01;
                    c2_acc10 <= rsp_eng20_10;
                    c2_acc11 <= rsp_eng20_11;
                end else begin
                    c2_wb0_valid <= 1'b1;
                    c2_wb0_pr <= rsp_pr[1:0];
                    c2_wb0_pc <= rsp_pc[1:0];
                    c2_wb0_oc <= rsp_oc;
                    c2_wb0_sum00 <= c2_acc00 + rsp_eng20_00;
                    c2_wb0_sum01 <= c2_acc01 + rsp_eng20_01;
                    c2_wb0_sum10 <= c2_acc10 + rsp_eng20_10;
                    c2_wb0_sum11 <= c2_acc11 + rsp_eng20_11;

                    c2_acc00 <= 0; c2_acc01 <= 0;
                    c2_acc10 <= 0; c2_acc11 <= 0;
                end
            end

            // FC SP2 is evaluated as two temporal PoT1 passes per class.
            // term0 is buffered; term1 completes the exact SP2 dot product,
            // after which the reduced-width bias/argmax datapath runs.
            if (rsp_valid && rsp_is_fc) begin
                if (FC_TWO_PASS && rsp_fc_term == 1'b0) begin
                    fc_term0_sum <= rsp_fc_sum;
                end else begin
                    scores[rsp_fc_class] <= fc_score_now;
                    if (rsp_fc_class == 0) begin
                        best_score <= fc_score_now;
                        best_idx <= 0;
                    end else if ($signed(fc_score_now) > $signed(best_score)) begin
                        best_score <= fc_score_now;
                        best_idx <= rsp_fc_class;
                    end

                    if (rsp_fc_class == 3) begin
                        if ($signed(fc_score_now) > $signed(best_score))
                            decision <= 2'd3;
                        else
                            decision <= best_idx;
                        valid_out_6 <= 1'b1;
                        state <= ST_DONE;
                    end
                end
            end
        end
    end

endmodule
```

## v25_dash/requirements.txt

```text
# Existing lab Torch 2.4.1 is sufficient; no environment replacement is needed.
numpy>=1.24
torch>=2.4
```

## v25_dash/run.py

```python
#!/usr/bin/env python3
"""Additive CLI. Run from adv_theme; no mutation of existing runs/avc4."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
ROOT=Path(__file__).resolve().parent
ADV=ROOT.parent
sys.path.insert(0,str(ADV/'src'))
sys.path.insert(0,str(ROOT))

def shared(p):
    p.add_argument('--data-work',required=True,help='existing runs/avc4 containing data/*.npz')
    p.add_argument('--out',required=True,help='new experiment output, e.g. runs/v25_avc4')

def main():
    p=argparse.ArgumentParser(description='V25-H DASH: 1->2->3, FC48->4, TD PoT1 + FC SP2')
    sub=p.add_subparsers(dest='command',required=True)
    d=sub.add_parser('doctor')
    s=sub.add_parser('smoke');s.add_argument('--data-work',required=True)
    t=sub.add_parser('train');shared(t)
    t.add_argument('--stage',choices=('fp32','int8','v25h','all'),default='all')
    t.add_argument('--base-epochs',type=int,default=40);t.add_argument('--qat-epochs',type=int,default=15)
    t.add_argument('--coded-epochs',type=int,default=15);t.add_argument('--batch-size',type=int,default=64)
    t.add_argument('--lr',type=float,default=.001);t.add_argument('--qat-lr',type=float,default=.0002)
    t.add_argument('--calibration-samples',type=int,default=1024);t.add_argument('--seed',type=int,default=2026)
    t.add_argument('--device',default='cpu');t.add_argument('--threads',type=int,default=2)
    v=sub.add_parser('verify-export');shared(v)
    v.add_argument('--stage',choices=('int8','v25h','all'),default='all')
    v.add_argument('--iverilog',default='iverilog');v.add_argument('--vvp',default='vvp');v.add_argument('--ivl-base')
    e=sub.add_parser('evaluate');shared(e);e.add_argument('--stage',choices=('int8','v25h','all'),default='all');e.add_argument('--batch-size',type=int,default=128)
    f=sub.add_parser('flow');f.add_argument('--out',required=True);f.add_argument('--period-ns',type=float,default=10.)
    c=sub.add_parser('selftest')
    a=p.parse_args()
    if a.command=='doctor':
        import torch
        from v25.model import V25DASH
        print(json.dumps(dict(python=sys.version.split()[0],torch=torch.__version__,cuda=torch.cuda.is_available(),
              iverilog=shutil.which('iverilog'),vvp=shutil.which('vvp'),parameters=sum(x.numel() for x in V25DASH().parameters()),
              channels=[1,2,3],fc=[48,4],existing_data_reused=True),indent=2));return
    if a.command=='smoke':
        script=ADV/'tests/make_smoke_data.py'
        if not script.exists():raise FileNotFoundError('existing adv_theme/tests/make_smoke_data.py required')
        subprocess.run([sys.executable,str(script),'--out',a.data_work],check=True);return
    if a.command=='train':
        from v25.train import train
        train(a);return
    if a.command=='evaluate':
        from v25.train import evaluate
        evaluate(a);return
    if a.command=='verify-export':
        from dash_cnn.data.audit import load
        from v25.train import representatives,dataset_identity,checkpoint
        from v25.integer import load as load_integer
        from v25.verify import verify
        from v25.util import sha256
        import numpy as np
        va=load(Path(a.data_work)/'data/validation.npz');x,_=representatives(va)
        for stage in (('int8','v25h') if a.stage=='all' else (a.stage,)):
            folder=Path(a.out)/'models'/stage
            report=json.loads((folder/'training_report.json').read_text())
            if report['dataset_identity']!=dataset_identity(a.data_work) or report['checkpoint_sha256']!=sha256(folder/'weights.pt'):raise ValueError('checkpoint/data changed')
            params=load_integer(folder/'integer/weights_int.npz');m,_=checkpoint(folder/'weights.pt')
            for key,value in m.export_integer().items():
                if not np.array_equal(value,params[key]):raise ValueError('export changed: '+key)
            verify(params,x,Path(a.out)/'verification'/stage,a.iverilog,a.vvp,a.ivl_base)
        return
    if a.command=='flow':
        from v25.flow import prepare
        prepare(a);return
    if a.command=='selftest':
        import unittest
        suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_*.py')
        if not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful():raise SystemExit(1)

if __name__=='__main__':main()
```

## v25_dash/source_v25h/chip_pfdw_fc_v25h.sv

```systemverilog
// =============================================================================
// V25-H controller: multiplierless fixed-model PFDW accelerator
//
// Search point: W566 / A88 / C(pot1,pot1,sp2) / T(16,8,8) / M67.
//   * Conv1: original output channel 0 removed; original channels 1/2 kept.
//   * Conv2: all three output channels kept, but only the two surviving Conv1
//            channels are consumed.
//   * Conv1/Conv2 transformed coefficients use single signed powers of two.
//   * FC SP2 coefficients are evaluated as two temporal PoT1 passes.
//   * Post-pool feature maps are stored at 8 bits.
//   * External trained-weight ports are retained only for interface compatibility;
//     this fixed-model implementation embeds the searched coefficients. Bias ports
//     remain live inputs.
//
// The controller preserves the V24 streaming/overlap architecture where useful,
// while adapting request counts, tags and writeback to the pruned two-channel
// Conv1 representation.
// =============================================================================
`timescale 1ps/1ps

// Architecture notes:
//   - A persistent 6x6 Conv1 sliding window avoids a wide dynamic line-buffer mux.
//   - Conv1 has two physical output channels and Conv2 consumes two input channels.
//   - Conv1/Conv2 share the 49-lane fixed-coefficient shift engine.
//   - Conv1/Conv2 overlap is retained; FC begins after all 48 fmap2 values commit.
//   - FC uses two temporal passes per class to realize SP2 without per-lane adders.
//   - The FC final score uses an exact reduced-width bias/carry formulation to avoid
//     the V24 external-bias -> 20-bit-adder -> argmax critical path.
//
module chip_pfdw_fc_v25h (
    input  logic clk,
    input  logic rst_n,
    input  logic [7:0] data_in,
    output logic [3:0] decision,
    output logic valid_out_6,

    input [0:199]  w_11,
    input [0:199]  w_12,
    input [0:199]  w_13,
    input [0:23]   b_1,
    input [0:23]   b_2,
    input [0:199]  w_211,
    input [0:199]  w_212,
    input [0:199]  w_213,
    input [0:199]  w_221,
    input [0:199]  w_222,
    input [0:199]  w_223,
    input [0:199]  w_231,
    input [0:199]  w_232,
    input [0:199]  w_233,
    input [0:3839] w_fc,
    input [0:79]   b_fc
);

    localparam ST_STREAM = 2'd0;
    localparam ST_FC     = 2'd1;
    localparam ST_DONE   = 2'd2;
    logic [1:0] state;

    // -------------------------------------------------------------------------
    // External input stream storage.
    // Explicit row/col/slot counters replace /28, %28 and %7 address arithmetic.
    // -------------------------------------------------------------------------
    logic [7:0] linebuf [0:6][0:27];
    logic [9:0] pixels_stored;
    logic       capture_primed;
    logic [4:0] cap_row, cap_col;
    logic [2:0] cap_slot;

    // Conv1 local 6x6 sliding window.
    // The engine sees only this register bank, not a dynamic 7x28 column mux.
    logic        [7:0]  c1_window [0:5][0:5];
    logic               c1_window_valid;
    logic [4:0]         c1_new_col;  // two entering columns for next stride-2 tile

    // Pool outputs. V6 retains only seven logical fmap1 rows at a time.
    // V25-H stores post-ReLU pooled values directly as unsigned 8-bit data.
    // Conv1 keeps two physical channels: 2 x 7 x 12 x 8 = 1344 payload bits.
    logic        [7:0] fmap1_ring [0:1][0:6][0:11];
    logic        [7:0] fmap2 [0:2][0:3][0:3];

    // -------------------------------------------------------------------------
    // Conv1 progress.
    // c1_base_slot = (2*c1_issue_pr) mod 7, maintained incrementally.
    // -------------------------------------------------------------------------
    logic [3:0] c1_issue_pr, c1_issue_pc;
    logic       c1_issue_oc;
    logic [2:0] c1_base_slot;
    logic [8:0] c1_issue_count;
    logic [8:0] c1_commit_count;

    // Conv1 writeback pipeline. WB0 registers the four quantized values; the
    // following cycle performs only 4-way max/ReLU and commits to fmap1_ring.
    logic c1_wb_valid;
    logic [2:0] c1_wb_slot;
    logic [3:0] c1_wb_pc;
    logic       c1_wb_oc;
    logic signed [11:0] c1_wb_q00, c1_wb_q01, c1_wb_q10, c1_wb_q11;

    // Conv2 progress.
    logic [1:0] c2_issue_pr, c2_issue_pc;
    logic [1:0] c2_issue_oc;
    logic       c2_issue_ic;
    // Physical ring slot corresponding to logical Conv2 window start row
    // (2*c2_issue_pr) mod 7. Updated only when Conv2 advances to next row.
    logic [2:0] c2_base_slot;
    logic [7:0] c2_issue_count;
    logic [7:0] c2_rsp_count;
    logic signed [19:0] c2_acc00, c2_acc01, c2_acc10, c2_acc11;

    // Conv2 writeback pipeline. the prior critical path ran directly from the
    // engine output register through final channel accumulation, quantization,
    // max-pool/ReLU and into fmap2. V4 cuts that cone into three short stages.
    logic c2_wb0_valid, c2_wb1_valid;
    logic [1:0] c2_wb0_pr, c2_wb0_pc, c2_wb0_oc;
    logic [1:0] c2_wb1_pr, c2_wb1_pc, c2_wb1_oc;
    logic signed [19:0] c2_wb0_sum00, c2_wb0_sum01, c2_wb0_sum10, c2_wb0_sum11;
    logic signed [11:0] c2_wb1_q00, c2_wb1_q01, c2_wb1_q10, c2_wb1_q11;
    logic [5:0] c2_commit_count;

    // FC progress: two temporal PoT1 requests per class implement SP2 exactly.
    logic [3:0] fc_issue_class;
    logic [4:0] fc_issue_count;
    logic       fc_issue_term;
    logic signed [15:0] fc_term0_sum;
    logic signed [11:0] best_score;
    logic [3:0] best_idx;

    // -------------------------------------------------------------------------
    // Helpers.
    // -------------------------------------------------------------------------
    // Layer-specific scale restoration from the searched V25-H point.
    localparam integer C1_RESTORE_SHIFT = 3; // INT8 -> W5
    localparam integer C2_RESTORE_SHIFT = 5; // A11->A8 (3) + INT8->W6 (2)
    localparam integer FC_RESTORE_SHIFT = 5; // A11->A8 (3) + INT8->W6 (2)

    // Conv1 physical channel 0/1 corresponds to original channel 1/2.
    function automatic logic signed [7:0] get_b1(input integer phys_oc);
        begin
            case (phys_oc)
                0: get_b1 = $signed(b_1[8+:8]);
                1: get_b1 = $signed(b_1[16+:8]);
                default: get_b1 = 8'sd0;
            endcase
        end
    endfunction

    function automatic logic signed [7:0] get_b2(input integer oc);
        begin
            case (oc)
                0: get_b2 = $signed(b_2[0+:8]);
                1: get_b2 = $signed(b_2[8+:8]);
                2: get_b2 = $signed(b_2[16+:8]);
                default: get_b2 = 8'sd0;
            endcase
        end
    endfunction

    function automatic logic signed [7:0] get_fcb(input integer cls);
        get_fcb = $signed(b_fc[(8*cls)+:8]);
    endfunction

    function automatic logic signed [11:0] conv1_q(
        input logic signed [31:0] raw,
        input logic signed [7:0] bias8
    );
        logic signed [19:0] t20;
        logic signed [11:0] shr12;
        logic signed [11:0] b12;
        logic signed [12:0] add13;
        begin
            t20   = raw[19:0];
            shr12 = $signed(t20) >>> 8;
            b12   = {{4{bias8[7]}},bias8};
            add13 = $signed(shr12) + $signed(b12);
            conv1_q = add13[11:0];
        end
    endfunction

    function automatic logic signed [11:0] conv2_q(
        input logic signed [19:0] sum20,
        input logic signed [7:0] bias8
    );
        logic signed [13:0] t14;
        logic signed [12:0] pre13;
        logic signed [11:0] b12;
        logic signed [13:0] add14;
        begin
            t14   = sum20[19:6];
            pre13 = $signed(t14[13:1]);
            b12   = {{4{bias8[7]}},bias8};
            add14 = $signed(pre13) + $signed(b12);
            conv2_q = add14[11:0];
        end
    endfunction

    function automatic logic signed [11:0] max4_relu(
        input logic signed [11:0] a,
        input logic signed [11:0] b,
        input logic signed [11:0] c,
        input logic signed [11:0] d
    );
        logic signed [11:0] m0, m1, m;
        begin
            m0 = (a >= b) ? a : b;
            m1 = (c >= d) ? c : d;
            m  = (m0 >= m1) ? m0 : m1;
            max4_relu = (m > 0) ? m : 12'sd0;
        end
    endfunction

    // Exact A8 storage used by the V25 search model:
    // pool/ReLU is still performed in the 12-bit domain, then arithmetic >>3.
    function automatic logic [7:0] max4_relu_a8(
        input logic signed [11:0] a,
        input logic signed [11:0] b,
        input logic signed [11:0] c,
        input logic signed [11:0] d
    );
        logic signed [11:0] m0, m1, m;
        begin
            m0 = (a >= b) ? a : b;
            m1 = (c >= d) ? c : d;
            m  = (m0 >= m1) ? m0 : m1;
            if (m > 0)
                max4_relu_a8 = m[10:3];
            else
                max4_relu_a8 = 8'd0;
        end
    endfunction

    function automatic [2:0] add_mod7(
        input logic [2:0] base,
        input integer off
    );
        integer tmp;
        begin
            tmp = base + off;
            if (tmp >= 7) tmp = tmp - 7;
            add_mod7 = tmp[2:0];
        end
    endfunction

    // -------------------------------------------------------------------------
    // Shared V6 engine.
    // -------------------------------------------------------------------------
    logic req_valid, req_is_fc;
    logic [15:0] req_tag;
    logic signed [8:0] req_tile [0:5][0:5];
    logic signed [8:0] req_fc_a [0:47];

    logic rsp_valid, rsp_is_fc;
    logic [15:0] rsp_tag;
    logic signed [19:0] rsp_y00, rsp_y01, rsp_y10, rsp_y11;
    logic signed [15:0] rsp_fc_sum;

    pfdw_pipe49_shift_engine_v25h u_engine (
        .clk(clk), .rst_n(rst_n),
        .req_valid(req_valid), .req_is_fc(req_is_fc), .req_tag(req_tag),
        .conv_tile(req_tile), .fc_a(req_fc_a),
        .rsp_valid(rsp_valid), .rsp_is_fc(rsp_is_fc), .rsp_tag(rsp_tag),
        .conv_y00(rsp_y00), .conv_y01(rsp_y01),
        .conv_y10(rsp_y10), .conv_y11(rsp_y11),
        .fc_sum(rsp_fc_sum)
    );

    // -------------------------------------------------------------------------
    // Dependency checks.
    // -------------------------------------------------------------------------
    logic c1_tile_ready;
    integer c2_required_commit_idx;
    logic c2_data_ready;

    always_comb begin
        // V6 issues Conv1 only from the local sliding window. The row-start
        // window becomes valid on the same capture edge that makes V6's first
        // tile ready; subsequent horizontal tiles are shifted in-place.
        c1_tile_ready = (c1_issue_count < 9'd288) && c1_window_valid;

        // fmap1 is produced row-major, col-major, then two physical channels.
        // Physical ic0/ic1 map to original Conv1 channels 1/2.
        c2_required_commit_idx = (((c2_issue_pr*2 + 5) * 12
                                 + (c2_issue_pc*2 + 5)) * 2
                                 + c2_issue_ic);
        c2_data_ready = (c2_issue_count < 8'd96)
                     && (c1_commit_count > c2_required_commit_idx);
    end

    // -------------------------------------------------------------------------
    // Dependency-aware request scheduler.
    // Conv1 gets priority so the 7-line input buffer safety proof remains the
    // same as V2. Conv2 uses only otherwise-idle Conv1 cycles until C1 finishes.
    // -------------------------------------------------------------------------
    integer rr, cc, kk, lane, ch, pos;
    logic issue_c1, issue_c2;
    always_comb begin
        req_valid = 1'b0;
        req_is_fc = 1'b0;
        req_tag   = 16'd0;
        issue_c1  = 1'b0;
        issue_c2  = 1'b0;
        kk = 0;
        ch = 0;
        pos = 0;

        for (rr = 0; rr < 6; rr = rr + 1)
            for (cc = 0; cc < 6; cc = cc + 1)
                req_tile[rr][cc] = 9'sd0;

        for (lane = 0; lane < 48; lane = lane + 1) begin
            req_fc_a[lane] = 9'sd0;
        end

        if (state == ST_STREAM) begin
            if (c1_tile_ready) begin
                issue_c1 = 1'b1;
                req_valid = 1'b1;
                req_is_fc = 1'b0;
                req_tag = {1'b0, 3'b000, c1_issue_pr, c1_issue_pc, 1'b0, c1_issue_oc, 2'b00};

                // Fixed/local wiring: no c1_issue_pc-driven 28-column mux.
                for (rr = 0; rr < 6; rr = rr + 1)
                    for (cc = 0; cc < 6; cc = cc + 1)
                        req_tile[rr][cc] = {1'b0,c1_window[rr][cc]};
            end else if (c2_data_ready) begin
                issue_c2 = 1'b1;
                req_valid = 1'b1;
                req_is_fc = 1'b0;
                req_tag = {1'b1, 3'b000, {2'b00,c2_issue_pr},
                           {2'b00,c2_issue_pc}, c2_issue_oc, 1'b0, c2_issue_ic};

                for (rr = 0; rr < 6; rr = rr + 1)
                    for (cc = 0; cc < 6; cc = cc + 1)
                        req_tile[rr][cc] = {1'b0, fmap1_ring[c2_issue_ic]
                            [add_mod7(c2_base_slot,rr)][c2_issue_pc*2+cc]};
            end
        end else if (state == ST_FC && fc_issue_count < 5'd20) begin
            req_valid = 1'b1;
            req_is_fc = 1'b1;
            req_tag = {11'd0,fc_issue_term,fc_issue_class};

            for (lane = 0; lane < 48; lane = lane + 1) begin
                ch  = lane / 16;
                pos = lane % 16;
                req_fc_a[lane] = {1'b0,fmap2[ch][pos/4][pos%4]};
            end
        end
    end

    // -------------------------------------------------------------------------
    // Response decode / fixed-point behavior.
    // -------------------------------------------------------------------------
    wire rsp_layer = rsp_tag[15];
    wire [3:0] rsp_pr = rsp_tag[11:8];
    wire [3:0] rsp_pc = rsp_tag[7:4];
    wire [1:0] rsp_oc = rsp_tag[3:2];
    wire [1:0] rsp_ic = rsp_tag[1:0];
    wire [3:0] rsp_fc_class = rsp_tag[3:0];
    wire       rsp_fc_term  = rsp_tag[4];

    logic signed [11:0] rsp_c1q00, rsp_c1q01, rsp_c1q10, rsp_c1q11;
    logic signed [19:0] rsp_eng20_00, rsp_eng20_01, rsp_eng20_10, rsp_eng20_11;
    logic signed [11:0] c2_wb0_q00, c2_wb0_q01, c2_wb0_q10, c2_wb0_q11;
    logic signed [11:0] fc_score_now;
    logic signed [16:0] fc_class_sum;
    logic [13:0] fc_sum_mod14;
    logic [11:0] fc_base12;
    logic [1:0]  fc_rem2;
    logic signed [8:0] fc_low9;

    always_comb begin
        rsp_c1q00 = conv1_q($signed(rsp_y00) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q01 = conv1_q($signed(rsp_y01) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q10 = conv1_q($signed(rsp_y10) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));
        rsp_c1q11 = conv1_q($signed(rsp_y11) <<< C1_RESTORE_SHIFT,get_b1(rsp_oc));

        rsp_eng20_00 = $signed(rsp_y00[19:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_01 = $signed(rsp_y01[19:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_10 = $signed(rsp_y10[19:0]) <<< C2_RESTORE_SHIFT;
        rsp_eng20_11 = $signed(rsp_y11[19:0]) <<< C2_RESTORE_SHIFT;

        // WB1 quantization is now isolated from engine-output accumulation.
        c2_wb0_q00 = conv2_q(c2_wb0_sum00,get_b2(c2_wb0_oc));
        c2_wb0_q01 = conv2_q(c2_wb0_sum01,get_b2(c2_wb0_oc));
        c2_wb0_q10 = conv2_q(c2_wb0_sum10,get_b2(c2_wb0_oc));
        c2_wb0_q11 = conv2_q(c2_wb0_sum11,get_b2(c2_wb0_oc));

        // Exact reduced FC score datapath for restore shift=5.
        // Original semantics:
        //   score = signed_slice(wrap20((sum<<5)+bias),18,7)
        // Only sum[13:0], the two low remainder bits and a {-1,0,+1}
        // correction are required. This removes V24's 20-bit bias adder and
        // breaks the old b_fc -> best_score critical path without 80 bias FFs.
        fc_class_sum = $signed({fc_term0_sum[15],fc_term0_sum})
                     + $signed({rsp_fc_sum[15],rsp_fc_sum});
        fc_sum_mod14 = fc_class_sum[13:0];
        fc_base12 = fc_sum_mod14[13:2];
        fc_rem2 = fc_sum_mod14[1:0];
        fc_low9 = $signed({2'b00,fc_rem2,5'b00000}) + $signed(get_fcb(rsp_fc_class));
        if (fc_low9 < 0)
            fc_score_now = $signed(fc_base12) - 12'sd1;
        else if (fc_low9 >= 9'sd128)
            fc_score_now = $signed(fc_base12) + 12'sd1;
        else
            fc_score_now = $signed(fc_base12);
    end

    // -------------------------------------------------------------------------
    // Main controller.
    // -------------------------------------------------------------------------
    integer c1wr, c1wc;
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= ST_STREAM;
            pixels_stored <= 10'd0;
            capture_primed <= 1'b0;
            cap_row <= 0;
            cap_col <= 0;
            cap_slot <= 0;
            c1_window_valid <= 1'b0;
            c1_new_col <= 5'd6;

            c1_issue_pr <= 0; c1_issue_pc <= 0; c1_issue_oc <= 0;
            c1_base_slot <= 0;
            c1_issue_count <= 0; c1_commit_count <= 0;
            c1_wb_valid <= 1'b0;
            c1_wb_slot <= 0; c1_wb_pc <= 0; c1_wb_oc <= 0;
            c1_wb_q00 <= 0; c1_wb_q01 <= 0;
            c1_wb_q10 <= 0; c1_wb_q11 <= 0;

            c2_issue_pr <= 0; c2_issue_pc <= 0;
            c2_issue_oc <= 0; c2_issue_ic <= 0;
            c2_base_slot <= 0;
            c2_issue_count <= 0; c2_rsp_count <= 0;
            c2_acc00 <= 0; c2_acc01 <= 0; c2_acc10 <= 0; c2_acc11 <= 0;

            c2_wb0_valid <= 1'b0;
            c2_wb1_valid <= 1'b0;
            c2_wb0_pr <= 0; c2_wb0_pc <= 0; c2_wb0_oc <= 0;
            c2_wb1_pr <= 0; c2_wb1_pc <= 0; c2_wb1_oc <= 0;
            c2_wb0_sum00 <= 0; c2_wb0_sum01 <= 0;
            c2_wb0_sum10 <= 0; c2_wb0_sum11 <= 0;
            c2_wb1_q00 <= 0; c2_wb1_q01 <= 0;
            c2_wb1_q10 <= 0; c2_wb1_q11 <= 0;
            c2_commit_count <= 0;

            fc_issue_class <= 0;
            fc_issue_count <= 0;
            fc_issue_term <= 1'b0;
            fc_term0_sum <= 16'sd0;
            best_score <= -12'sd2048;
            best_idx <= 0;

            decision <= 0;
            valid_out_6 <= 1'b0;
        end else begin
            valid_out_6 <= 1'b0;

            // Conv1 writeback pipeline. The response cycle performs only the
            // fixed-point quantization into WB0. The next cycle performs the
            // max/ReLU and writes one pooled value into the seven-row ring.
            c1_wb_valid <= 1'b0;
            if (c1_wb_valid) begin
                fmap1_ring[c1_wb_oc][c1_wb_slot][c1_wb_pc] <=
                    max4_relu_a8(c1_wb_q00,c1_wb_q01,c1_wb_q10,c1_wb_q11);
                c1_commit_count <= c1_commit_count + 1'b1;
            end

            // Conv2 writeback pipeline advances every cycle.
            c2_wb0_valid <= 1'b0;
            c2_wb1_valid <= c2_wb0_valid;
            if (c2_wb0_valid) begin
                c2_wb1_pr <= c2_wb0_pr;
                c2_wb1_pc <= c2_wb0_pc;
                c2_wb1_oc <= c2_wb0_oc;
                c2_wb1_q00 <= c2_wb0_q00;
                c2_wb1_q01 <= c2_wb0_q01;
                c2_wb1_q10 <= c2_wb0_q10;
                c2_wb1_q11 <= c2_wb0_q11;
            end

            // Commit pooled Conv2 output from the isolated WB1 stage.
            if (c2_wb1_valid) begin
                fmap2[c2_wb1_oc][c2_wb1_pr][c2_wb1_pc] <=
                    max4_relu_a8(c2_wb1_q00,c2_wb1_q01,c2_wb1_q10,c2_wb1_q11);
                c2_commit_count <= c2_commit_count + 1'b1;

                // Start FC only after the 48th pooled fmap2 value is committed.
                if (c2_commit_count == 6'd47) begin
                    state <= ST_FC;
                    fc_issue_class <= 0;
                    fc_issue_count <= 0;
                    fc_issue_term <= 1'b0;
                    fc_term0_sum <= 16'sd0;
                    best_score <= -12'sd2048;
                    best_idx <= 0;
                end
            end

            // Input capture continues independently of C1/C2 scheduling.
            if (pixels_stored < 10'd784) begin
                if (!capture_primed) begin
                    capture_primed <= 1'b1;
                end else begin
                    linebuf[cap_slot][cap_col] <= data_in;
                    pixels_stored <= pixels_stored + 1'b1;

                    // Row-start preload for the current Conv1 pooled row.
                    // It fires on the exact edge that captures raw column 5 of
                    // the sixth required input row. All other 35 bytes already
                    // reside in the seven-row line buffer; the just-arriving
                    // bottom-right byte bypasses the linebuf NBA write.
                    if (!c1_window_valid &&
                        (c1_issue_pc == 4'd0) &&
                        (c1_issue_oc == 2'd0) &&
                        (cap_col == 5'd5) &&
                        (cap_row == ({c1_issue_pr,1'b0} + 5'd5))) begin
                        for (c1wr = 0; c1wr < 6; c1wr = c1wr + 1) begin
                            for (c1wc = 0; c1wc < 6; c1wc = c1wc + 1) begin
                                if ((c1wr == 5) && (c1wc == 5))
                                    c1_window[c1wr][c1wc] <= data_in;
                                else
                                    c1_window[c1wr][c1wc] <=
                                        linebuf[add_mod7(c1_base_slot,c1wr)][c1wc];
                            end
                        end
                        c1_window_valid <= 1'b1;
                        c1_new_col <= 5'd6;
                    end

                    if (cap_col == 5'd27) begin
                        cap_col <= 0;
                        if (cap_row < 5'd27)
                            cap_row <= cap_row + 1'b1;
                        cap_slot <= (cap_slot == 3'd6) ? 3'd0 : cap_slot + 1'b1;
                    end else begin
                        cap_col <= cap_col + 1'b1;
                    end
                end
            end

            // Request-side progress. Conv1 reuses the same local 6x6 window
            // for the two surviving output channels. After physical channel 1, the
            // window advances by stride 2: four columns are retained and only two entering
            // columns (12 bytes total) are fetched from linebuf.
            if (req_valid && !req_is_fc && issue_c1) begin
                c1_issue_count <= c1_issue_count + 1'b1;
                if (c1_issue_oc == 1'b0) begin
                    c1_issue_oc <= 1'b1;
                end else begin
                    c1_issue_oc <= 0;
                    if (c1_issue_pc < 11) begin
                        for (c1wr = 0; c1wr < 6; c1wr = c1wr + 1) begin
                            c1_window[c1wr][0] <= c1_window[c1wr][2];
                            c1_window[c1wr][1] <= c1_window[c1wr][3];
                            c1_window[c1wr][2] <= c1_window[c1wr][4];
                            c1_window[c1wr][3] <= c1_window[c1wr][5];
                            c1_window[c1wr][4] <=
                                linebuf[add_mod7(c1_base_slot,c1wr)][c1_new_col];
                            // With only two Conv1 channels, the horizontal
                            // window advances one cycle earlier than V24.
                            // The newest bottom-row byte is being captured on
                            // this same edge, so bypass the linebuf NBA write.
                            if ((c1wr == 5) &&
                                (cap_row == ({c1_issue_pr,1'b0} + 5'd5)) &&
                                (cap_col == (c1_new_col + 1'b1)))
                                c1_window[c1wr][5] <= data_in;
                            else
                                c1_window[c1wr][5] <=
                                    linebuf[add_mod7(c1_base_slot,c1wr)][c1_new_col + 1'b1];
                        end
                        c1_new_col <= c1_new_col + 5'd2;
                        c1_issue_pc <= c1_issue_pc + 1'b1;
                    end else begin
                        // Next pooled row starts again at raw columns 0..5.
                        // Its window is reloaded by the input-capture preload
                        // above when the new bottom row reaches column 5.
                        c1_window_valid <= 1'b0;
                        c1_new_col <= 5'd6;
                        c1_issue_pc <= 0;
                        if (c1_issue_pr < 11) begin
                            c1_issue_pr <= c1_issue_pr + 1'b1;
                            c1_base_slot <= add_mod7(c1_base_slot,2);
                        end
                    end
                end
            end

            if (req_valid && !req_is_fc && issue_c2) begin
                c2_issue_count <= c2_issue_count + 1'b1;
                if (c2_issue_ic == 1'b0) begin
                    c2_issue_ic <= 1'b1;
                end else begin
                    c2_issue_ic <= 1'b0;
                    if (c2_issue_oc < 2) begin
                        c2_issue_oc <= c2_issue_oc + 1'b1;
                    end else begin
                        c2_issue_oc <= 0;
                        if (c2_issue_pc < 3) begin
                            c2_issue_pc <= c2_issue_pc + 1'b1;
                        end else begin
                            c2_issue_pc <= 0;
                            if (c2_issue_pr < 3) begin
                                c2_issue_pr <= c2_issue_pr + 1'b1;
                                c2_base_slot <= add_mod7(c2_base_slot,2);
                            end
                        end
                    end
                end
            end

            if (req_valid && req_is_fc && state == ST_FC) begin
                fc_issue_count <= fc_issue_count + 1'b1;
                if (fc_issue_term == 1'b0) begin
                    fc_issue_term <= 1'b1;
                end else begin
                    fc_issue_term <= 1'b0;
                    if (fc_issue_class < 9)
                        fc_issue_class <= fc_issue_class + 1'b1;
                end
            end

            // Conv1 response -> WB0 quantization register. Pool/ReLU and the
            // physical ring write occur on the following cycle above.
            if (rsp_valid && !rsp_is_fc && (rsp_layer == 1'b0)) begin
                c1_wb_valid <= 1'b1;
                c1_wb_slot <= add_mod7(3'd0,rsp_pr);
                c1_wb_pc <= rsp_pc;
                c1_wb_oc <= rsp_oc;
                c1_wb_q00 <= rsp_c1q00;
                c1_wb_q01 <= rsp_c1q01;
                c1_wb_q10 <= rsp_c1q10;
                c1_wb_q11 <= rsp_c1q11;
            end

            // Conv2 response -> two-input-channel accumulation.
            // The second input-channel result is captured into WB0 instead of running
            // accumulation + quantization + pool/ReLU in one cycle.
            if (rsp_valid && !rsp_is_fc && (rsp_layer == 1'b1)) begin
                c2_rsp_count <= c2_rsp_count + 1'b1;

                if (rsp_ic == 0) begin
                    c2_acc00 <= rsp_eng20_00;
                    c2_acc01 <= rsp_eng20_01;
                    c2_acc10 <= rsp_eng20_10;
                    c2_acc11 <= rsp_eng20_11;
                end else begin
                    c2_wb0_valid <= 1'b1;
                    c2_wb0_pr <= rsp_pr[1:0];
                    c2_wb0_pc <= rsp_pc[1:0];
                    c2_wb0_oc <= rsp_oc;
                    c2_wb0_sum00 <= c2_acc00 + rsp_eng20_00;
                    c2_wb0_sum01 <= c2_acc01 + rsp_eng20_01;
                    c2_wb0_sum10 <= c2_acc10 + rsp_eng20_10;
                    c2_wb0_sum11 <= c2_acc11 + rsp_eng20_11;

                    c2_acc00 <= 0; c2_acc01 <= 0;
                    c2_acc10 <= 0; c2_acc11 <= 0;
                end
            end

            // FC SP2 is evaluated as two temporal PoT1 passes per class.
            // term0 is buffered; term1 completes the exact SP2 dot product,
            // after which the reduced-width bias/argmax datapath runs.
            if (rsp_valid && rsp_is_fc) begin
                if (rsp_fc_term == 1'b0) begin
                    fc_term0_sum <= rsp_fc_sum;
                end else begin
                    if (rsp_fc_class == 0) begin
                        best_score <= fc_score_now;
                        best_idx <= 0;
                    end else if ($signed(fc_score_now) > $signed(best_score)) begin
                        best_score <= fc_score_now;
                        best_idx <= rsp_fc_class;
                    end

                    if (rsp_fc_class == 9) begin
                        if ($signed(fc_score_now) > $signed(best_score))
                            decision <= 4'd9;
                        else
                            decision <= best_idx;
                        valid_out_6 <= 1'b1;
                        state <= ST_DONE;
                    end
                end
            end
        end
    end

endmodule
```

## v25_dash/source_v25h/explore_v25.py

```python
#!/usr/bin/env python3
"""
V25 PPA Searcher for the KNU/IDEC CNN accelerator project.

Purpose
-------
Search numerical/hardware candidates BEFORE writing another RTL version.
The model follows the V24 PFDW datapath at inference level:
  * 6x6 tile + 5x5 kernel -> four outputs through the same decomposed Winograd
    transforms used by pfdw_pipe49_booth_engine_v24.sv.
  * V24-style layer-wise weight LSB dropping with scale restoration.
  * Conv1/Conv2 fixed-point quantization, ReLU/max-pool, and FC score slicing.

It additionally explores V25 candidates:
  * layer-wise weight precision (W4..W8)
  * layer-wise activation precision for fmap1/fmap2 (8..11 bits)
  * unstructured pruning thresholds
  * structured Conv1/Conv2 channel pruning
  * transformed-domain signed-power coefficient coding for convolution
    (pot1 / csd2 / sp2) and signed-power coding for FC weights

IMPORTANT
---------
The reported PPA score is a ranking proxy, NOT an OpenROAD prediction.
Always synthesize the best few candidates. The accuracy/inference path is the
part intended to be bit-faithful to the V24 arithmetic conventions.

Typical usage (Windows PowerShell):
  python explore_v25.py --data-dir C:/cnn_verilog/test24 --num-images 200 --search
  python explore_v25.py --data-dir C:/cnn_verilog/test24 --num-images 1000 --validate

Typical usage (Linux):
  python3 explore_v25.py --data-dir ~/cnn_data --num-images 200 --search

Outputs are written under --out-dir (default: v25_search_out).
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict, dataclass, replace
from functools import lru_cache
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view


# -----------------------------------------------------------------------------
# Two's-complement helpers
# -----------------------------------------------------------------------------

def wrap_signed(x, bits: int):
    """Wrap scalar/ndarray to a signed two's-complement integer of width bits."""
    mod = 1 << bits
    half = 1 << (bits - 1)
    a = np.asarray(x, dtype=np.int64)
    u = np.bitwise_and(a, mod - 1)
    y = np.where(u >= half, u - mod, u).astype(np.int64)
    if np.ndim(x) == 0:
        return int(y)
    return y


def signed_slice(x, hi: int, lo: int):
    """Verilog-style signed slice x[hi:lo], interpreted as signed."""
    width = hi - lo + 1
    a = np.asarray(x, dtype=np.int64)
    u = np.bitwise_and(a, (1 << (hi + 1)) - 1)
    s = np.right_shift(u, lo)
    y = wrap_signed(s, width)
    if np.ndim(x) == 0:
        return int(y)
    return y


def popcount3(mask: int) -> int:
    return ((mask >> 0) & 1) + ((mask >> 1) & 1) + ((mask >> 2) & 1)


# -----------------------------------------------------------------------------
# Exact V24 PFDW transforms (integer form)
# -----------------------------------------------------------------------------

def _b3(x0, x1, x2, x3, o):
    return (x0 - x2, x1 + x2, -x1 + x2, x1 - x3)[o]


def _b2(x0, x1, x2, o):
    return (x0 - x1, x1, -x1 + x2)[o]


def _g3(x0, x1, x2, o):
    return (x0 << 1, x0 + x1 + x2, x0 - x1 + x2, x2 << 1)[o]


def _g2(x0, x1, o):
    return (x0, x0 + x1, x1)[o]


def _a3(x0, x1, x2, x3, o):
    return x0 + x1 + x2 if o == 0 else x1 - x2 - x3


def _a2(x0, x1, x2, o):
    return x0 + x1 if o == 0 else x1 + x2


def transform_tile_scalar(tile: Sequence[Sequence[int]]) -> List[int]:
    """V24 B transform: 6x6 activation tile -> 49 lanes."""
    p1 = [0] * 49
    # 3x3 block
    for r in range(4):
        for o in range(4):
            p1[r * 4 + o] = _b3(*tile[r][0:4], o)
    # 3x2 block
    for r in range(4):
        for o in range(3):
            p1[16 + r * 3 + o] = _b2(*tile[r][3:6], o)
    # 2x3 block
    for r in range(3):
        for o in range(4):
            p1[28 + r * 4 + o] = _b3(*tile[r + 3][0:4], o)
    # 2x2 block
    for r in range(3):
        for o in range(3):
            p1[40 + r * 3 + o] = _b2(*tile[r + 3][3:6], o)

    p2 = [0] * 49
    # block 0 4x4
    for j in range(4):
        for i in range(4):
            p2[i * 4 + j] = _b3(p1[0 * 4 + j], p1[1 * 4 + j],
                                 p1[2 * 4 + j], p1[3 * 4 + j], i)
    # block 1 4x3
    for j in range(3):
        for i in range(4):
            p2[16 + i * 3 + j] = _b3(p1[16 + 0 * 3 + j], p1[16 + 1 * 3 + j],
                                      p1[16 + 2 * 3 + j], p1[16 + 3 * 3 + j], i)
    # block 2 3x4
    for j in range(4):
        for i in range(3):
            p2[28 + i * 4 + j] = _b2(p1[28 + 0 * 4 + j], p1[28 + 1 * 4 + j],
                                      p1[28 + 2 * 4 + j], i)
    # block 3 3x3
    for j in range(3):
        for i in range(3):
            p2[40 + i * 3 + j] = _b2(p1[40 + 0 * 3 + j], p1[40 + 1 * 3 + j],
                                      p1[40 + 2 * 3 + j], i)
    return p2


def transform_kernel_scalar(k: Sequence[Sequence[int]]) -> List[int]:
    """V24 G transform: 5x5 spatial kernel -> 49 transformed coefficients."""
    p1 = [0] * 35
    for r in range(3):
        for o in range(4):
            p1[r * 4 + o] = _g3(*k[r][0:3], o)
    for r in range(3):
        for o in range(3):
            p1[12 + r * 3 + o] = _g2(*k[r][3:5], o)
    for r in range(2):
        for o in range(4):
            p1[21 + r * 4 + o] = _g3(*k[r + 3][0:3], o)
    for r in range(2):
        for o in range(3):
            p1[29 + r * 3 + o] = _g2(*k[r + 3][3:5], o)

    p2 = [0] * 49
    for j in range(4):
        for i in range(4):
            p2[i * 4 + j] = _g3(p1[0 * 4 + j], p1[1 * 4 + j], p1[2 * 4 + j], i)
    for j in range(3):
        for i in range(4):
            p2[16 + i * 3 + j] = _g3(p1[12 + 0 * 3 + j], p1[12 + 1 * 3 + j],
                                      p1[12 + 2 * 3 + j], i)
    for j in range(4):
        for i in range(3):
            p2[28 + i * 4 + j] = _g2(p1[21 + 0 * 4 + j], p1[21 + 1 * 4 + j], i)
    for j in range(3):
        for i in range(3):
            p2[40 + i * 3 + j] = _g2(p1[29 + 0 * 3 + j], p1[29 + 1 * 3 + j], i)
    return p2


def _build_linear_matrix(kind: str) -> np.ndarray:
    if kind == "B":
        mat = np.zeros((49, 36), dtype=np.int64)
        for n in range(36):
            x = [[0] * 6 for _ in range(6)]
            x[n // 6][n % 6] = 1
            mat[:, n] = np.asarray(transform_tile_scalar(x), dtype=np.int64)
        return mat
    if kind == "G":
        mat = np.zeros((49, 25), dtype=np.int64)
        for n in range(25):
            x = [[0] * 5 for _ in range(5)]
            x[n // 5][n % 5] = 1
            mat[:, n] = np.asarray(transform_kernel_scalar(x), dtype=np.int64)
        return mat
    raise ValueError(kind)


B_MAT = _build_linear_matrix("B")
G_MAT = _build_linear_matrix("G")

LANE_AW = np.array([
    14 if i == 5 else 12 if i in {17,23,26,32,34,35,41,43,44,45,47} else 13
    for i in range(49)
], dtype=np.int64)

_LANE_BW_BASE = []
for i in range(49):
    if i in {5,6,9,10}:
        v = 12
    elif i in {1,2,4,7,8,11,13,14,20,23,33,34}:
        v = 11
    elif i in {0,3,12,15,17,19,21,22,24,26,29,30,32,35,37,38,44}:
        v = 10
    elif i in {16,18,25,27,28,31,36,39,41,43,45,47}:
        v = 9
    else:
        v = 8
    _LANE_BW_BASE.append(v)
LANE_BW_BASE = np.asarray(_LANE_BW_BASE, dtype=np.int64)

LANE_PW_BASE = np.asarray([
    22,23,23,22, 23,25,24,23, 23,24,24,23, 22,23,23,22,
    21,21,21,22, 23,22,22,22, 22,21,21,21,
    21,22,22,21, 21,23,22,21, 21,22,22,21,
    20,20,20,20, 21,20,20,20, 20
], dtype=np.int64)


def inverse_pfdw(p3: np.ndarray) -> np.ndarray:
    """V24 P4/P5/P6 inverse transform, vectorized over leading dimensions."""
    p = np.asarray(p3, dtype=np.int64)
    lead = p.shape[:-1]
    h33 = np.zeros(lead + (4, 2), dtype=np.int64)
    h32 = np.zeros(lead + (4, 2), dtype=np.int64)
    h23 = np.zeros(lead + (3, 2), dtype=np.int64)
    h22 = np.zeros(lead + (3, 2), dtype=np.int64)

    for r in range(4):
        x = p[..., r * 4:r * 4 + 4]
        h33[..., r, 0] = x[..., 0] + x[..., 1] + x[..., 2]
        h33[..., r, 1] = x[..., 1] - x[..., 2] - x[..., 3]
        x = p[..., 16 + r * 3:16 + r * 3 + 3]
        h32[..., r, 0] = x[..., 0] + x[..., 1]
        h32[..., r, 1] = x[..., 1] + x[..., 2]

    for r in range(3):
        x = p[..., 28 + r * 4:28 + r * 4 + 4]
        h23[..., r, 0] = x[..., 0] + x[..., 1] + x[..., 2]
        h23[..., r, 1] = x[..., 1] - x[..., 2] - x[..., 3]
        x = p[..., 40 + r * 3:40 + r * 3 + 3]
        h22[..., r, 0] = x[..., 0] + x[..., 1]
        h22[..., r, 1] = x[..., 1] + x[..., 2]

    # Physical register widths in V24 P4.
    h33 = wrap_signed(h33, 26)
    h32 = wrap_signed(h32, 24)
    h23 = wrap_signed(h23, 24)
    h22 = wrap_signed(h22, 22)

    b0 = np.zeros(lead + (4,), dtype=np.int64)
    b1 = np.zeros(lead + (4,), dtype=np.int64)
    b2 = np.zeros(lead + (4,), dtype=np.int64)
    b3 = np.zeros(lead + (4,), dtype=np.int64)

    for col in range(2):
        # index order 00,01,10,11
        b0[..., col] = h33[..., 0, col] + h33[..., 1, col] + h33[..., 2, col]
        b0[..., 2 + col] = h33[..., 1, col] - h33[..., 2, col] - h33[..., 3, col]
        b1[..., col] = h32[..., 0, col] + h32[..., 1, col] + h32[..., 2, col]
        b1[..., 2 + col] = h32[..., 1, col] - h32[..., 2, col] - h32[..., 3, col]
        b2[..., col] = h23[..., 0, col] + h23[..., 1, col]
        b2[..., 2 + col] = h23[..., 1, col] + h23[..., 2, col]
        b3[..., col] = h22[..., 0, col] + h22[..., 1, col]
        b3[..., 2 + col] = h22[..., 1, col] + h22[..., 2, col]

    b0 = wrap_signed(b0, 27)
    b1 = wrap_signed(b1, 25)
    b2 = wrap_signed(b2, 25)
    b3 = wrap_signed(b3, 23)

    y = (b0 >> 2) + (b1 >> 1) + (b2 >> 1) + b3
    return wrap_signed(y, 29)


def transform_tiles_np(tiles: np.ndarray) -> np.ndarray:
    t = np.asarray(tiles, dtype=np.int64)
    flat = t.reshape(t.shape[:-2] + (36,))
    out = np.matmul(flat, B_MAT.T)
    # Apply exact lane activation register widths.
    for lane, aw in enumerate(LANE_AW.tolist()):
        out[..., lane] = wrap_signed(out[..., lane], int(aw))
    return out


def transform_kernels_np(kernels: np.ndarray) -> np.ndarray:
    k = np.asarray(kernels, dtype=np.int64)
    flat = k.reshape(k.shape[:-2] + (25,))
    return np.matmul(flat, G_MAT.T)


# -----------------------------------------------------------------------------
# Signed-power coefficient coding
# -----------------------------------------------------------------------------

def _candidate_terms(max_exp: int, scheme: str):
    # value -> (term_count, tuple(signed powers)) ; ties prefer fewer terms.
    best: Dict[int, Tuple[int, Tuple[int, ...]]] = {0: (0, tuple())}
    powers = [1 << e for e in range(max_exp + 1)]
    for p in powers:
        for s in (-1, 1):
            v = s * p
            best[v] = min(best.get(v, (99, tuple())), (1, (v,)), key=lambda z: z[0])
    if scheme in {"sp2", "csd2"}:
        for e1 in range(max_exp + 1):
            for e2 in range(e1):
                if scheme == "csd2" and abs(e1 - e2) == 1:
                    continue  # canonical signed-digit: no adjacent non-zero digits
                p1, p2 = 1 << e1, 1 << e2
                for s1 in (-1, 1):
                    for s2 in (-1, 1):
                        terms = (s1 * p1, s2 * p2)
                        v = sum(terms)
                        old = best.get(v)
                        if old is None or old[0] > 2:
                            best[v] = (2, terms)
    vals = sorted(best)
    return np.asarray(vals, dtype=np.int64), best


@lru_cache(maxsize=None)
def candidate_table(bits: int, scheme: str):
    if scheme == "exact":
        return None
    if scheme not in {"pot1", "sp2", "csd2"}:
        raise ValueError(f"unknown coefficient scheme {scheme}")
    max_abs = (1 << (bits - 1))
    max_exp = max(0, int(math.ceil(math.log2(max_abs))))
    vals, meta = _candidate_terms(max_exp, scheme)
    lo, hi = -(1 << (bits - 1)), (1 << (bits - 1)) - 1
    vals = vals[(vals >= lo) & (vals <= hi)]
    return vals, meta


def quantize_signed_power(values: np.ndarray, bits_per_lane: np.ndarray | int, scheme: str):
    a = np.asarray(values, dtype=np.int64)
    if scheme == "exact":
        if np.ndim(bits_per_lane) == 0:
            return wrap_signed(a, int(bits_per_lane)), np.full_like(a, -1)
        out = np.empty_like(a)
        for lane, bits in enumerate(np.asarray(bits_per_lane).tolist()):
            out[..., lane] = wrap_signed(a[..., lane], int(bits))
        return out, np.full_like(a, -1)

    out = np.zeros_like(a)
    terms = np.zeros_like(a)
    if np.ndim(bits_per_lane) == 0:
        bits_arr = np.full(a.shape[-1] if a.ndim else 1, int(bits_per_lane), dtype=np.int64)
    else:
        bits_arr = np.asarray(bits_per_lane, dtype=np.int64)

    # Last dimension is treated as lanes if bits_per_lane is an array.
    if np.ndim(bits_per_lane) == 0:
        unique_vals = np.unique(a)
        vals, meta = candidate_table(int(bits_per_lane), scheme)
        lut = {}
        for x in unique_vals.tolist():
            idx = int(np.argmin(np.abs(vals - int(x))))
            q = int(vals[idx])
            lut[int(x)] = (q, meta[q][0])
        for x, (q, tc) in lut.items():
            m = (a == x)
            out[m] = q
            terms[m] = tc
        return out, terms

    for lane, bits in enumerate(bits_arr.tolist()):
        vals, meta = candidate_table(int(bits), scheme)
        src = a[..., lane]
        for x in np.unique(src).tolist():
            # Primary criterion: absolute numerical error. Secondary: fewer terms.
            errs = np.abs(vals - int(x))
            minerr = errs.min()
            idxs = np.flatnonzero(errs == minerr)
            if len(idxs) > 1:
                idx = min(idxs.tolist(), key=lambda ii: (meta[int(vals[ii])][0], abs(int(vals[ii]))))
            else:
                idx = int(idxs[0])
            q = int(vals[idx])
            tc = meta[q][0]
            m = (src == x)
            out[..., lane][m] = q
            terms[..., lane][m] = tc
    return out, terms


# -----------------------------------------------------------------------------
# Dataset / parameter loading
# -----------------------------------------------------------------------------

def _read_memh(path: Path, count: int, bits: int, signed: bool) -> np.ndarray:
    if not path.exists():
        raise FileNotFoundError(path)
    toks: List[str] = []
    for line in path.read_text().splitlines():
        line = line.split("//", 1)[0].strip()
        if not line:
            continue
        toks.extend(line.split())
    if len(toks) < count:
        raise ValueError(f"{path}: expected at least {count} values, got {len(toks)}")
    vals = []
    mask = (1 << bits) - 1
    for tok in toks[:count]:
        tok = tok.replace("_", "")
        # readmemh files are hexadecimal; tolerate 0x prefix.
        v = int(tok, 16) & mask
        if signed and (v & (1 << (bits - 1))):
            v -= 1 << bits
        vals.append(v)
    return np.asarray(vals, dtype=np.int64)


@dataclass
class ModelData:
    images: np.ndarray          # [N,28,28] uint-ish int64
    labels: np.ndarray          # [N]
    c1_w: np.ndarray            # [3,5,5]
    c1_b: np.ndarray            # [3]
    c2_w: np.ndarray            # [3,3,5,5] [out,in]
    c2_b: np.ndarray            # [3]
    fc_w: np.ndarray            # [10,48]
    fc_b: np.ndarray            # [10]


def load_model_data(data_dir: Path, num_images: int, label_file: str | None = None) -> ModelData:
    pixels = _read_memh(data_dir / "input_1000.txt", num_images * 784, 8, False)
    images = pixels.reshape(num_images, 28, 28)
    if label_file:
        labels = _read_memh(Path(label_file), num_images, 8, False)
    else:
        labels = np.arange(num_images, dtype=np.int64) % 10

    c1_w = np.stack([
        _read_memh(data_dir / f"conv1_weight_{i}.txt", 25, 8, True).reshape(5, 5)
        for i in (1, 2, 3)
    ])
    c1_b = _read_memh(data_dir / "conv1_bias.txt", 3, 8, True)

    c2 = np.zeros((3, 3, 5, 5), dtype=np.int64)
    for oc in range(3):
        for ic in range(3):
            c2[oc, ic] = _read_memh(
                data_dir / f"conv2_weight_{oc+1}{ic+1}.txt", 25, 8, True
            ).reshape(5, 5)
    c2_b = _read_memh(data_dir / "conv2_bias.txt", 3, 8, True)
    fc_w = _read_memh(data_dir / "fc_weight.txt", 480, 8, True).reshape(10, 48)
    fc_b = _read_memh(data_dir / "fc_bias.txt", 10, 8, True)
    return ModelData(images, labels, c1_w, c1_b, c2, c2_b, fc_w, fc_b)


# -----------------------------------------------------------------------------
# Search configuration
# -----------------------------------------------------------------------------
@dataclass(frozen=True)
class Config:
    wbits_c1: int = 7
    wbits_c2: int = 7
    wbits_fc: int = 7
    abits_f1: int = 11
    abits_f2: int = 11
    code_c1: str = "exact"
    code_c2: str = "exact"
    code_fc: str = "exact"
    prune_thr_c1: int = 0
    prune_thr_c2: int = 0
    prune_thr_fc: int = 0
    c1_mask: int = 0b111
    c2_mask: int = 0b111

    def tag(self) -> str:
        return (
            f"W{self.wbits_c1}{self.wbits_c2}{self.wbits_fc}_"
            f"A{self.abits_f1}{self.abits_f2}_"
            f"C{self.code_c1}-{self.code_c2}-{self.code_fc}_"
            f"T{self.prune_thr_c1}-{self.prune_thr_c2}-{self.prune_thr_fc}_"
            f"M{self.c1_mask:x}{self.c2_mask:x}"
        )


@dataclass
class EvalResult:
    config: Config
    correct: int
    total: int
    accuracy: float
    elapsed_s: float
    proxy_area: float
    proxy_dynamic: float
    proxy_ppa: float
    c1_zero_frac: float
    c2_zero_frac: float
    fc_zero_frac: float
    c1_avg_terms: float
    c2_avg_terms: float
    fc_avg_terms: float


# -----------------------------------------------------------------------------
# V24/V25 inference model
# -----------------------------------------------------------------------------
class Explorer:
    def __init__(self, data: ModelData):
        self.d = data
        # Conv1 raw-image transformed tiles do not depend on the candidate.
        sw = sliding_window_view(data.images, (6, 6), axis=(1, 2))
        c1_tiles = sw[:, ::2, ::2, :, :]  # [N,12,12,6,6]
        self.c1_bt = transform_tiles_np(c1_tiles)  # [N,12,12,49]
        self.cache: Dict[Config, EvalResult] = {}

    @staticmethod
    def _spatial_q(w: np.ndarray, bits: int, threshold: int) -> np.ndarray:
        x = np.asarray(w, dtype=np.int64).copy()
        if threshold > 0:
            x[np.abs(x) < threshold] = 0
        shift = 8 - bits
        return np.right_shift(x, shift)

    @staticmethod
    def _conv_td(kq: np.ndarray, bits: int, scheme: str):
        td = transform_kernels_np(kq)
        bw = LANE_BW_BASE - (8 - bits)
        q, terms = quantize_signed_power(td, bw, scheme)
        # Exact V24 physical P2 lane register widths.
        for lane, b in enumerate(bw.tolist()):
            q[..., lane] = wrap_signed(q[..., lane], int(b))
        return q, terms

    @staticmethod
    def _mul_inverse(bt: np.ndarray, coeff49: np.ndarray, wbits: int) -> np.ndarray:
        # bt [...,49], coeff49 [49]
        bw_shift = 8 - wbits
        pw = LANE_PW_BASE - bw_shift
        p = bt * coeff49
        for lane, bits in enumerate(pw.tolist()):
            p[..., lane] = wrap_signed(p[..., lane], int(bits))
        return inverse_pfdw(p)

    @staticmethod
    def _conv1_quant(raw: np.ndarray, bias: int, restore_shift: int) -> np.ndarray:
        t20 = wrap_signed(np.left_shift(raw, restore_shift), 20)
        shr = np.right_shift(t20, 8)
        return wrap_signed(shr + int(bias), 12)

    @staticmethod
    def _conv2_quant(sum20: np.ndarray, bias: int) -> np.ndarray:
        # RTL: sum20[19:6] then [13:1] == arithmetic >>7, then bias, low 12 bits.
        return wrap_signed(np.right_shift(wrap_signed(sum20, 20), 7) + int(bias), 12)

    @staticmethod
    def _pool_relu4(q4: np.ndarray) -> np.ndarray:
        m = np.max(q4, axis=-1)
        return np.where(m > 0, m, 0).astype(np.int64)

    @staticmethod
    def _fc_score(sum_prod: np.ndarray, bias: int, restore_shift: int) -> np.ndarray:
        t = wrap_signed(sum_prod, 20)
        t = wrap_signed(np.left_shift(t, restore_shift), 20)
        t = wrap_signed(t + int(bias), 20)
        return signed_slice(t, 18, 7)

    def _proxy(self, cfg: Config, td_stats: Dict[str, Tuple[np.ndarray, np.ndarray]], fq_terms: np.ndarray):
        # Transparent ranking proxy. It intentionally does NOT pretend to be OpenROAD.
        c1n, c2n = popcount3(cfg.c1_mask), popcount3(cfg.c2_mask)
        req_c1 = 144 * c1n
        req_c2 = 16 * c2n * c1n
        fc_lanes = 16 * c2n

        # Register/storage payload proxy.
        storage = 3 * 7 * 12 * cfg.abits_f1 + 3 * 4 * 4 * cfg.abits_f2
        storage += 36 * 8  # C1 window, common to all candidates

        def code_cost(scheme: str, terms: np.ndarray, abit: int, wbit: int):
            if scheme == "exact":
                # multiplier complexity proxy
                return float(abit * (wbit + 2))
            avg_terms = float(np.mean(terms)) if terms.size else 0.0
            # wiring/shift-select + optional add; much cheaper than a multiplier.
            return float(abit * (0.22 + 0.18 * avg_terms) + max(0.0, avg_terms - 1.0) * abit * 0.35)

        c1_terms = td_stats["c1"][1]
        c2_terms = td_stats["c2"][1]
        c1_pe = code_cost(cfg.code_c1, c1_terms, 14, cfg.wbits_c1)
        c2_pe = code_cost(cfg.code_c2, c2_terms, cfg.abits_f1 + 3, cfg.wbits_c2)
        fc_pe = code_cost(cfg.code_fc, fq_terms, cfg.abits_f2, cfg.wbits_fc)

        # Shared-PE area is dominated by the largest mode cost.
        pe_area = 49.0 * max(c1_pe, c2_pe, fc_pe)
        area = pe_area + 0.018 * storage + 110.0

        # Dynamic proxy weights how often each mode is exercised.
        dynamic = 49.0 * (req_c1 * c1_pe + req_c2 * c2_pe + 10 * (fc_lanes / 48.0) * fc_pe)
        dynamic /= 1e5
        # Channel pruning additionally reduces scheduler/accumulator activity.
        dynamic += 0.08 * (req_c1 + req_c2 + 10)
        ppa = area * dynamic
        return area, dynamic, ppa

    def evaluate(self, cfg: Config) -> EvalResult:
        if cfg in self.cache:
            return self.cache[cfg]
        t0 = time.time()
        d = self.d
        nimg = d.images.shape[0]

        # ---- weights: prune -> V24-style bit reduction ----
        c1q = self._spatial_q(d.c1_w, cfg.wbits_c1, cfg.prune_thr_c1)
        c2q = self._spatial_q(d.c2_w, cfg.wbits_c2, cfg.prune_thr_c2)
        fcq = self._spatial_q(d.fc_w, cfg.wbits_fc, cfg.prune_thr_fc)

        c1td, c1terms = self._conv_td(c1q, cfg.wbits_c1, cfg.code_c1)
        c2td, c2terms = self._conv_td(c2q, cfg.wbits_c2, cfg.code_c2)
        # FC does not use G transform.
        fcq_code, fcterms = quantize_signed_power(fcq, cfg.wbits_fc, cfg.code_fc)

        # ---- Conv1 + pool ----
        f1 = np.zeros((nimg, 3, 12, 12), dtype=np.int64)
        wshift1 = 8 - cfg.wbits_c1
        for oc in range(3):
            if not (cfg.c1_mask & (1 << oc)):
                continue
            y = self._mul_inverse(self.c1_bt, c1td[oc], cfg.wbits_c1)  # [N,12,12,4]
            q = self._conv1_quant(y, int(d.c1_b[oc]), wshift1)
            f1[:, oc] = self._pool_relu4(q)

        ashift1 = 11 - cfg.abits_f1
        if ashift1:
            f1 = np.right_shift(f1, ashift1)

        # ---- Conv2 + pool ----
        f2 = np.zeros((nimg, 3, 4, 4), dtype=np.int64)
        sw2 = sliding_window_view(f1, (6, 6), axis=(2, 3))
        tiles2 = sw2[:, :, ::2, ::2, :, :]  # [N,3,4,4,6,6]
        bt2 = transform_tiles_np(tiles2)     # [N,3,4,4,49]
        wshift2 = 8 - cfg.wbits_c2
        restore2 = ashift1 + wshift2

        for oc in range(3):
            if not (cfg.c2_mask & (1 << oc)):
                continue
            acc = np.zeros((nimg, 4, 4, 4), dtype=np.int64)
            for ic in range(3):
                if not (cfg.c1_mask & (1 << ic)):
                    continue
                y = self._mul_inverse(bt2[:, ic], c2td[oc, ic], cfg.wbits_c2)
                contrib = wrap_signed(np.left_shift(signed_slice(y, 19, 0), restore2), 20)
                acc = wrap_signed(acc + contrib, 20)
            q = self._conv2_quant(acc, int(d.c2_b[oc]))
            f2[:, oc] = self._pool_relu4(q)

        ashift2 = 11 - cfg.abits_f2
        if ashift2:
            f2 = np.right_shift(f2, ashift2)

        # ---- FC + online argmax equivalent ----
        flat = f2.reshape(nimg, 48)  # channel-major, row-major = V24 lane order
        scores = np.zeros((nimg, 10), dtype=np.int64)
        wshiftf = 8 - cfg.wbits_fc
        restoref = ashift2 + wshiftf
        # Inputs belonging to a pruned Conv2 output channel are already zero.
        for cls in range(10):
            prod_sum = np.sum(flat * fcq_code[cls][None, :], axis=1, dtype=np.int64)
            scores[:, cls] = self._fc_score(prod_sum, int(d.fc_b[cls]), restoref)
        pred = np.argmax(scores, axis=1)
        correct = int(np.sum(pred == d.labels))
        acc = correct / nimg

        td_stats = {"c1": (c1td, c1terms), "c2": (c2td, c2terms)}
        area, dyn, ppa = self._proxy(cfg, td_stats, fcterms)

        def zfrac(x):
            return float(np.mean(np.asarray(x) == 0))
        def avgterms(scheme, terms):
            if scheme == "exact":
                return float("nan")
            return float(np.mean(terms))

        res = EvalResult(
            config=cfg, correct=correct, total=nimg, accuracy=acc,
            elapsed_s=time.time() - t0,
            proxy_area=area, proxy_dynamic=dyn, proxy_ppa=ppa,
            c1_zero_frac=zfrac(c1td), c2_zero_frac=zfrac(c2td), fc_zero_frac=zfrac(fcq_code),
            c1_avg_terms=avgterms(cfg.code_c1, c1terms),
            c2_avg_terms=avgterms(cfg.code_c2, c2terms),
            fc_avg_terms=avgterms(cfg.code_fc, fcterms),
        )
        self.cache[cfg] = res
        return res

    def export_candidate(self, cfg: Config, out_dir: Path):
        out_dir.mkdir(parents=True, exist_ok=True)
        d = self.d
        c1q = self._spatial_q(d.c1_w, cfg.wbits_c1, cfg.prune_thr_c1)
        c2q = self._spatial_q(d.c2_w, cfg.wbits_c2, cfg.prune_thr_c2)
        fcq = self._spatial_q(d.fc_w, cfg.wbits_fc, cfg.prune_thr_fc)
        c1td, c1terms = self._conv_td(c1q, cfg.wbits_c1, cfg.code_c1)
        c2td, c2terms = self._conv_td(c2q, cfg.wbits_c2, cfg.code_c2)
        fcqc, fcterms = quantize_signed_power(fcq, cfg.wbits_fc, cfg.code_fc)

        (out_dir / "config.json").write_text(json.dumps(asdict(cfg), indent=2))
        np.savetxt(out_dir / "conv1_td_coeffs.csv", c1td.reshape(3, 49), fmt="%d", delimiter=",")
        np.savetxt(out_dir / "conv2_td_coeffs.csv", c2td.reshape(9, 49), fmt="%d", delimiter=",")
        np.savetxt(out_dir / "fc_coeffs.csv", fcqc.reshape(10, 48), fmt="%d", delimiter=",")
        np.savetxt(out_dir / "conv1_term_count.csv", c1terms.reshape(3, 49), fmt="%d", delimiter=",")
        np.savetxt(out_dir / "conv2_term_count.csv", c2terms.reshape(9, 49), fmt="%d", delimiter=",")
        np.savetxt(out_dir / "fc_term_count.csv", fcterms.reshape(10, 48), fmt="%d", delimiter=",")

    def validate_known(self):
        print("[validate] checking V21/W8 and V24/W7 software-model points...")
        r8 = self.evaluate(Config(wbits_c1=8, wbits_c2=8, wbits_fc=8))
        r7 = self.evaluate(Config())
        print(f"  W8 exact: {r8.correct}/{r8.total} = {100*r8.accuracy:.2f}%")
        print(f"  W7 exact: {r7.correct}/{r7.total} = {100*r7.accuracy:.2f}%")
        if r8.total == 1000:
            if r8.correct != 970 or r7.correct != 980:
                print("  WARNING: expected project checkpoints are W8=970/1000 and W7=980/1000.")
                print("           Do NOT trust a broad search until file ordering/data format is checked.")
                return False
            print("  PASS: matches the known V21/V24 1000-image checkpoints.")
        else:
            print("  NOTE: exact 97/98% checkpoint only applies to the full 1000-image run.")
        return True


# -----------------------------------------------------------------------------
# Search routines
# -----------------------------------------------------------------------------
def result_row(r: EvalResult):
    d = asdict(r.config)
    d.update({
        "correct": r.correct,
        "total": r.total,
        "accuracy": r.accuracy,
        "accuracy_pct": 100 * r.accuracy,
        "elapsed_s": r.elapsed_s,
        "proxy_area": r.proxy_area,
        "proxy_dynamic": r.proxy_dynamic,
        "proxy_ppa": r.proxy_ppa,
        "c1_zero_frac": r.c1_zero_frac,
        "c2_zero_frac": r.c2_zero_frac,
        "fc_zero_frac": r.fc_zero_frac,
        "c1_avg_terms": r.c1_avg_terms,
        "c2_avg_terms": r.c2_avg_terms,
        "fc_avg_terms": r.fc_avg_terms,
        "tag": r.config.tag(),
    })
    return d


def save_results(results: Sequence[EvalResult], out_csv: Path):
    rows = [result_row(r) for r in results]
    if not rows:
        return
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with out_csv.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def print_result(r: EvalResult, prefix=""):
    print(
        f"{prefix}{r.config.tag():58s} "
        f"acc={100*r.accuracy:6.2f}% ({r.correct}/{r.total}) "
        f"Aproxy={r.proxy_area:8.1f} Dproxy={r.proxy_dynamic:9.1f} "
        f"PPA={r.proxy_ppa:11.1f} t={r.elapsed_s:5.2f}s"
    )


def coordinate_search(ex: Explorer, min_acc: float, out_dir: Path, passes: int = 2):
    # Start from the measured V24 W7 design point.
    current = Config()
    all_results: List[EvalResult] = []
    rcur = ex.evaluate(current)
    all_results.append(rcur)
    print_result(rcur, "START ")

    fields = [
        ("wbits_c1", [4, 5, 6, 7, 8]),
        ("wbits_c2", [4, 5, 6, 7, 8]),
        ("wbits_fc", [4, 5, 6, 7, 8]),
        ("abits_f1", [8, 9, 10, 11]),
        ("abits_f2", [8, 9, 10, 11]),
        # sp2 is intentionally included separately from strict CSD2.
        ("code_c1", ["exact", "sp2", "csd2", "pot1"]),
        ("code_c2", ["exact", "sp2", "csd2", "pot1"]),
        ("code_fc", ["exact", "sp2", "csd2", "pot1"]),
        ("prune_thr_c1", [0, 2, 4, 8, 16, 32]),
        ("prune_thr_c2", [0, 2, 4, 8, 16, 32]),
        ("prune_thr_fc", [0, 2, 4, 8, 16, 32]),
        # Keep all channels or remove one. Multiple-channel removal can be tried
        # manually after the first robust candidate is found.
        ("c1_mask", [0b111, 0b110, 0b101, 0b011]),
        ("c2_mask", [0b111, 0b110, 0b101, 0b011]),
    ]

    for pidx in range(passes):
        print(f"\n=== coordinate pass {pidx+1}/{passes} ===")
        changed = False
        for field, values in fields:
            candidates = []
            seen = set()
            for v in values:
                c = replace(current, **{field: v})
                if c in seen:
                    continue
                seen.add(c)
                r = ex.evaluate(c)
                all_results.append(r)
                candidates.append(r)
                print_result(r, f"  {field:13s} ")
            feasible = [r for r in candidates if r.accuracy >= min_acc]
            if feasible:
                best = min(feasible, key=lambda r: (r.proxy_ppa, r.proxy_area, -r.accuracy))
                if best.config != current:
                    print(f"  -> accept {field}={getattr(best.config, field)}")
                    current = best.config
                    rcur = best
                    changed = True
            else:
                print(f"  -> no {field} candidate meets min accuracy {100*min_acc:.2f}%")
        if not changed:
            break

    # De-duplicate and rank feasible results.
    uniq = {r.config: r for r in all_results}
    all_results = list(uniq.values())
    feasible = sorted(
        [r for r in all_results if r.accuracy >= min_acc],
        key=lambda r: (r.proxy_ppa, r.proxy_area, -r.accuracy)
    )
    save_results(sorted(all_results, key=lambda r: (-r.accuracy, r.proxy_ppa)), out_dir / "v25_search_results.csv")

    print("\n=== TOP FEASIBLE CANDIDATES ===")
    for r in feasible[:12]:
        print_result(r, "TOP   ")
    if feasible:
        best = feasible[0]
        (out_dir / "v25_best_config.json").write_text(json.dumps(result_row(best), indent=2))
        ex.export_candidate(best.config, out_dir / "best_candidate_export")
        print(f"\nBest config exported to: {out_dir / 'best_candidate_export'}")
        return best
    print("No candidate met the minimum accuracy target.")
    return None


# -----------------------------------------------------------------------------
# Self-test
# -----------------------------------------------------------------------------
def selftest():
    rng = np.random.default_rng(7)
    for _ in range(30):
        tile = rng.integers(-20, 21, size=(6, 6), dtype=np.int64)
        ker = rng.integers(-8, 9, size=(5, 5), dtype=np.int64)
        bt = transform_tiles_np(tile[None, ...])[0]
        gt = transform_kernels_np(ker[None, ...])[0]
        p = bt * gt
        # W8 exact physical lane widths.
        for lane, pw in enumerate(LANE_PW_BASE.tolist()):
            p[lane] = wrap_signed(p[lane], int(pw))
        y = inverse_pfdw(p[None, ...])[0]
        direct = []
        for ro, co in ((0, 0), (0, 1), (1, 0), (1, 1)):
            direct.append(int(np.sum(tile[ro:ro+5, co:co+5] * ker)))
        if list(map(int, y)) != direct:
            raise AssertionError((y.tolist(), direct))
    print("SELFTEST PASS: PFDW integer transform reproduces direct 5x5 convolution.")


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--data-dir", type=Path, help="directory containing input_1000.txt and weight/bias txt files")
    ap.add_argument("--num-images", type=int, default=200, help="number of images to evaluate (1..1000)")
    ap.add_argument("--label-file", type=str, default=None, help="optional readmemh label file; otherwise label=index%%10")
    ap.add_argument("--out-dir", type=Path, default=Path("v25_search_out"))
    ap.add_argument("--min-acc", type=float, default=0.97, help="minimum acceptable accuracy, fraction")
    ap.add_argument("--passes", type=int, default=2, help="coordinate-search passes")
    ap.add_argument("--validate", action="store_true", help="evaluate W8 and W7 project checkpoints")
    ap.add_argument("--search", action="store_true", help="run coordinate search")
    ap.add_argument("--selftest", action="store_true", help="run arithmetic self-test and exit if no data-dir")
    args = ap.parse_args()

    selftest()
    if args.selftest and args.data_dir is None:
        return
    if args.data_dir is None:
        ap.error("--data-dir is required unless only --selftest is requested")
    if not (1 <= args.num_images <= 1000):
        ap.error("--num-images must be 1..1000")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Loading {args.num_images} images from {args.data_dir} ...")
    data = load_model_data(args.data_dir, args.num_images, args.label_file)
    ex = Explorer(data)

    if args.validate or not args.search:
        ex.validate_known()
    if args.search:
        best = coordinate_search(ex, args.min_acc, args.out_dir, args.passes)
        if best is not None:
            print("\nIMPORTANT: proxy ranking is not an OpenROAD PPA result.")
            print("Synthesize at least the top 3 feasible candidates before selecting V25 RTL.")


if __name__ == "__main__":
    main()
```

## v25_dash/source_v25h/pfdw_pipe49_shift_engine_v25h.sv

```systemverilog
// =============================================================================
// V25-H fixed-model PFDW multiplierless shared engine
//
// Generated from V25_H_export.zip:
//   Conv1 transformed coefficients : PoT1, W5 search point
//   Conv2 transformed coefficients : PoT1, W6 search point
//   FC coefficients                : SP2, W6 search point
//   Activations                    : unsigned 8-bit after pooling/quantization
//
// Key hardware changes from V24:
//   * removes all 49 Booth multipliers;
//   * removes the kernel G-transform datapath and all kernel pipeline registers;
//   * hard-wires the searched transformed coefficients;
//   * implements Conv products as zero/sign/constant-shift only;
//   * implements FC SP2 exactly as two temporal PoT1 passes (no lane adder);
//   * narrows activation-transform registers using exact 0..255 input bounds;
//   * narrows physical product registers lane-by-lane.
//
// External trained-weight ports remain on the chip wrapper for pin compatibility,
// but this fixed-model engine intentionally does not consume them.
// =============================================================================
`timescale 1ps/1ps

module pfdw_pipe49_shift_engine_v25h (
    input  logic clk,
    input  logic rst_n,

    input  logic req_valid,
    input  logic req_is_fc,
    input  logic [15:0] req_tag,

    input  logic signed [8:0] conv_tile [0:5][0:5],
    input  logic signed [8:0] fc_a [0:47],

    output logic rsp_valid,
    output logic rsp_is_fc,
    output logic [15:0] rsp_tag,
    output logic signed [19:0] conv_y00,
    output logic signed [19:0] conv_y01,
    output logic signed [19:0] conv_y10,
    output logic signed [19:0] conv_y11,
    output logic signed [15:0] fc_sum
);

    function automatic logic signed [9:0] b3_h9(
        input logic signed [8:0] x0,
        input logic signed [8:0] x1,
        input logic signed [8:0] x2,
        input logic signed [8:0] x3,
        input integer o
    );
        logic signed [9:0] a0,a1,a2,a3;
        begin
            a0={x0[8],x0}; a1={x1[8],x1};
            a2={x2[8],x2}; a3={x3[8],x3};
            case(o)
                0: b3_h9 = a0-a2;
                1: b3_h9 = a1+a2;
                2: b3_h9 = -a1+a2;
                default: b3_h9 = a1-a3;
            endcase
        end
    endfunction

    function automatic logic signed [9:0] b2_h9(
        input logic signed [8:0] x0,
        input logic signed [8:0] x1,
        input logic signed [8:0] x2,
        input integer o
    );
        logic signed [9:0] a0,a1,a2;
        begin
            a0={x0[8],x0}; a1={x1[8],x1}; a2={x2[8],x2};
            case(o)
                0: b2_h9 = a0-a1;
                1: b2_h9 = a1;
                default: b2_h9 = -a1+a2;
            endcase
        end
    endfunction

    function automatic logic signed [10:0] b3_v10(
        input logic signed [9:0] x0,
        input logic signed [9:0] x1,
        input logic signed [9:0] x2,
        input logic signed [9:0] x3,
        input integer o
    );
        logic signed [10:0] a0,a1,a2,a3;
        begin
            a0={x0[9],x0}; a1={x1[9],x1};
            a2={x2[9],x2}; a3={x3[9],x3};
            case(o)
                0: b3_v10 = a0-a2;
                1: b3_v10 = a1+a2;
                2: b3_v10 = -a1+a2;
                default: b3_v10 = a1-a3;
            endcase
        end
    endfunction

    function automatic logic signed [10:0] b2_v10(
        input logic signed [9:0] x0,
        input logic signed [9:0] x1,
        input logic signed [9:0] x2,
        input integer o
    );
        logic signed [10:0] a0,a1,a2;
        begin
            a0={x0[9],x0}; a1={x1[9],x1}; a2={x2[9],x2};
            case(o)
                0: b2_v10 = a0-a1;
                1: b2_v10 = a1;
                default: b2_v10 = -a1+a2;
            endcase
        end
    endfunction

    function automatic integer lane_aw(input integer idx);
        begin
            case (idx)
                17, 23, 26, 32, 34, 35, 41, 43, 44, 45, 47: lane_aw = 9;
                0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 24, 25, 27, 28, 29, 30, 31, 33, 36, 37, 38, 39, 40, 42, 46, 48: lane_aw = 10;
                5: lane_aw = 11;
                default: lane_aw = 10;
            endcase
        end
    endfunction

    function automatic integer lane_pw(input integer idx);
        begin
            case (idx)
                24, 34, 38, 40, 41, 42, 43, 45, 47, 48: lane_pw = 13;
                6, 9, 10, 14, 18, 22, 23, 29, 30, 32, 36, 44, 46: lane_pw = 14;
                1, 2, 8, 11, 13, 16, 17, 19, 21, 25, 26, 27, 28, 31, 33, 35, 37, 39: lane_pw = 15;
                0, 3, 4, 7, 12, 15, 20: lane_pw = 16;
                5: lane_pw = 17;
                default: lane_pw = 13;
            endcase
        end
    endfunction

    logic p0_valid, p0_is_fc;
    logic [15:0] p0_tag;
    logic signed [8:0] p0_a [0:47];
    integer r0,c0,f0;
    always_ff @(posedge clk) begin
        if(!rst_n) begin
            p0_valid<=1'b0; p0_is_fc<=1'b0; p0_tag<=16'd0;
        end else begin
            p0_valid<=req_valid;
            if(req_valid) begin
                p0_is_fc<=req_is_fc; p0_tag<=req_tag;
                if(req_is_fc) begin
                    for(f0=0;f0<48;f0=f0+1) p0_a[f0] <= fc_a[f0];
                end else begin
                    for(r0=0;r0<6;r0=r0+1)
                        for(c0=0;c0<6;c0=c0+1)
                            p0_a[r0*6+c0] <= conv_tile[r0][c0];
                end
            end
        end
    end

    logic p1_valid,p1_is_fc;
    logic [15:0] p1_tag;
    logic signed [9:0] p1_a [0:48];
    integer pr,po,pf;
    always_ff @(posedge clk) begin
        if(!rst_n) begin
            p1_valid<=1'b0; p1_is_fc<=1'b0; p1_tag<=16'd0;
        end else begin
            p1_valid<=p0_valid;
            if(p0_valid) begin
                p1_is_fc<=p0_is_fc; p1_tag<=p0_tag;
                if(p0_is_fc) begin
                    for(pf=0;pf<48;pf=pf+1)
                        p1_a[pf] <= {p0_a[pf][8],p0_a[pf]};
                    p1_a[48] <= 10'sd0;
                end else begin
                    for(pr=0;pr<4;pr=pr+1)
                        for(po=0;po<4;po=po+1)
                            p1_a[pr*4+po] <= b3_h9(p0_a[pr*6+0],p0_a[pr*6+1],p0_a[pr*6+2],p0_a[pr*6+3],po);
                    for(pr=0;pr<4;pr=pr+1)
                        for(po=0;po<3;po=po+1)
                            p1_a[16+pr*3+po] <= b2_h9(p0_a[pr*6+3],p0_a[pr*6+4],p0_a[pr*6+5],po);
                    for(pr=0;pr<3;pr=pr+1)
                        for(po=0;po<4;po=po+1)
                            p1_a[28+pr*4+po] <= b3_h9(p0_a[(pr+3)*6+0],p0_a[(pr+3)*6+1],p0_a[(pr+3)*6+2],p0_a[(pr+3)*6+3],po);
                    for(pr=0;pr<3;pr=pr+1)
                        for(po=0;po<3;po=po+1)
                            p1_a[40+pr*3+po] <= b2_h9(p0_a[(pr+3)*6+3],p0_a[(pr+3)*6+4],p0_a[(pr+3)*6+5],po);
                end
            end
        end
    end

    logic signed [10:0] p2_a_comb [0:48];
    integer pj,pi;
    always_comb begin
        for(pi=0;pi<49;pi=pi+1) p2_a_comb[pi]=11'sd0;
        if(p1_is_fc) begin
            for(pi=0;pi<48;pi=pi+1)
                p2_a_comb[pi] = {{1{p1_a[pi][9]}},p1_a[pi]};
        end else begin
            for(pj=0;pj<4;pj=pj+1)
                for(pi=0;pi<4;pi=pi+1)
                    p2_a_comb[pi*4+pj]=b3_v10(p1_a[0*4+pj],p1_a[1*4+pj],p1_a[2*4+pj],p1_a[3*4+pj],pi);
            for(pj=0;pj<3;pj=pj+1)
                for(pi=0;pi<4;pi=pi+1)
                    p2_a_comb[16+pi*3+pj]=b3_v10(p1_a[16+0*3+pj],p1_a[16+1*3+pj],p1_a[16+2*3+pj],p1_a[16+3*3+pj],pi);
            for(pj=0;pj<4;pj=pj+1)
                for(pi=0;pi<3;pi=pi+1)
                    p2_a_comb[28+pi*4+pj]=b2_v10(p1_a[28+0*4+pj],p1_a[28+1*4+pj],p1_a[28+2*4+pj],pi);
            for(pj=0;pj<3;pj=pj+1)
                for(pi=0;pi<3;pi=pi+1)
                    p2_a_comb[40+pi*3+pj]=b2_v10(p1_a[40+0*3+pj],p1_a[40+1*3+pj],p1_a[40+2*3+pj],pi);
        end
    end

    logic p2_valid,p2_is_fc,p3_valid,p3_is_fc;
    logic [15:0] p2_tag,p3_tag;
    wire signed [17:0] p3_p [0:48];

    always_ff @(posedge clk) begin
        if(!rst_n) begin
            p2_valid<=1'b0; p2_is_fc<=1'b0; p2_tag<=16'd0;
            p3_valid<=1'b0; p3_is_fc<=1'b0; p3_tag<=16'd0;
        end else begin
            p2_valid<=p1_valid;
            if(p1_valid) begin p2_is_fc<=p1_is_fc; p2_tag<=p1_tag; end
            p3_valid<=p2_valid;
            if(p2_valid) begin p3_is_fc<=p2_is_fc; p3_tag<=p2_tag; end
        end
    end

    generate

        if (1) begin : G_LANE_0
            localparam integer AW = 10;
            localparam integer PW = 16;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd4; // term=0 class=1
                        5'd2: coeff_term = -8'sd4; // term=0 class=2
                        5'd3: coeff_term = -8'sd16; // term=0 class=3
                        5'd4: coeff_term = 8'sd8; // term=0 class=4
                        5'd5: coeff_term = 8'sd4; // term=0 class=5
                        5'd6: coeff_term = 8'sd4; // term=0 class=6
                        5'd7: coeff_term = -8'sd8; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = -8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = -8'sd2; // term=1 class=2
                        5'd19: coeff_term = 8'sd2; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd2; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = -8'sd2; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd0;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd64;
                        4'b0001: coeff_term = 8'sd0;
                        4'b0100: coeff_term = -8'sd32;
                        4'b0101: coeff_term = -8'sd16;
                        4'b1000: coeff_term = -8'sd16;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[0] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[0][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (0 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_1
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd4; // term=0 class=1
                        5'd2: coeff_term = -8'sd4; // term=0 class=2
                        5'd3: coeff_term = -8'sd16; // term=0 class=3
                        5'd4: coeff_term = 8'sd8; // term=0 class=4
                        5'd5: coeff_term = 8'sd4; // term=0 class=5
                        5'd6: coeff_term = 8'sd8; // term=0 class=6
                        5'd7: coeff_term = -8'sd8; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = -8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd2; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd4; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd4; // term=1 class=6
                        5'd23: coeff_term = -8'sd4; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = -8'sd4; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd32;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd32;
                        4'b0101: coeff_term = -8'sd32;
                        4'b1000: coeff_term = -8'sd8;
                        4'b1001: coeff_term = -8'sd32;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[1] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[1][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (1 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_2
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd16; // term=0 class=1
                        5'd2: coeff_term = -8'sd2; // term=0 class=2
                        5'd3: coeff_term = 8'sd2; // term=0 class=3
                        5'd4: coeff_term = 8'sd8; // term=0 class=4
                        5'd5: coeff_term = -8'sd8; // term=0 class=5
                        5'd6: coeff_term = 8'sd4; // term=0 class=6
                        5'd7: coeff_term = -8'sd4; // term=0 class=7
                        5'd8: coeff_term = -8'sd2; // term=0 class=8
                        5'd9: coeff_term = -8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = -8'sd1; // term=1 class=1
                        5'd18: coeff_term = -8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd2; // term=1 class=4
                        5'd21: coeff_term = -8'sd2; // term=1 class=5
                        5'd22: coeff_term = 8'sd1; // term=1 class=6
                        5'd23: coeff_term = -8'sd2; // term=1 class=7
                        5'd24: coeff_term = -8'sd1; // term=1 class=8
                        5'd25: coeff_term = -8'sd2; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd16;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd4;
                        4'b0101: coeff_term = -8'sd16;
                        4'b1000: coeff_term = -8'sd8;
                        4'b1001: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[2] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[2][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (2 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_3
            localparam integer AW = 10;
            localparam integer PW = 16;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd8; // term=0 class=0
                        5'd1: coeff_term = 8'sd4; // term=0 class=1
                        5'd2: coeff_term = -8'sd4; // term=0 class=2
                        5'd3: coeff_term = 8'sd2; // term=0 class=3
                        5'd4: coeff_term = 8'sd8; // term=0 class=4
                        5'd5: coeff_term = -8'sd4; // term=0 class=5
                        5'd6: coeff_term = 8'sd2; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = -8'sd2; // term=0 class=8
                        5'd9: coeff_term = -8'sd2; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd4; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = -8'sd1; // term=1 class=8
                        5'd25: coeff_term = -8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd0;
                        4'b0001: coeff_term = -8'sd64;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = -8'sd16;
                        4'b1000: coeff_term = 8'sd0;
                        4'b1001: coeff_term = -8'sd32;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[3] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[3][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (3 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_4
            localparam integer AW = 10;
            localparam integer PW = 16;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = -8'sd2; // term=0 class=1
                        5'd2: coeff_term = -8'sd8; // term=0 class=2
                        5'd3: coeff_term = -8'sd8; // term=0 class=3
                        5'd4: coeff_term = 8'sd8; // term=0 class=4
                        5'd5: coeff_term = 8'sd4; // term=0 class=5
                        5'd6: coeff_term = 8'sd4; // term=0 class=6
                        5'd7: coeff_term = -8'sd16; // term=0 class=7
                        5'd8: coeff_term = 8'sd2; // term=0 class=8
                        5'd9: coeff_term = 8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd1; // term=1 class=3
                        5'd20: coeff_term = -8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd2; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = -8'sd16;
                        2'd1: coeff_term = 8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd64;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd4;
                        4'b0101: coeff_term = 8'sd0;
                        4'b1000: coeff_term = -8'sd32;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[4] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[4][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (4 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_5
            localparam integer AW = 11;
            localparam integer PW = 17;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd0; // term=0 class=1
                        5'd2: coeff_term = -8'sd2; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd2; // term=0 class=4
                        5'd5: coeff_term = 8'sd4; // term=0 class=5
                        5'd6: coeff_term = 8'sd4; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd2; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = -8'sd2; // term=1 class=3
                        5'd20: coeff_term = 8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd2; // term=1 class=5
                        5'd22: coeff_term = 8'sd2; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd0;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd32;
                        4'b0001: coeff_term = -8'sd64;
                        4'b0100: coeff_term = -8'sd32;
                        4'b0101: coeff_term = 8'sd4;
                        4'b1000: coeff_term = -8'sd32;
                        4'b1001: coeff_term = -8'sd32;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[5] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[5][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (5 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_6
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd2; // term=0 class=1
                        5'd2: coeff_term = 8'sd2; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = -8'sd8; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = 8'sd2; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd0; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd4;
                        4'b0001: coeff_term = -8'sd16;
                        4'b0100: coeff_term = 8'sd4;
                        4'b0101: coeff_term = -8'sd8;
                        4'b1000: coeff_term = -8'sd4;
                        4'b1001: coeff_term = 8'sd2;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[6] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[6][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (6 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_7
            localparam integer AW = 10;
            localparam integer PW = 16;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd2; // term=0 class=0
                        5'd1: coeff_term = 8'sd2; // term=0 class=1
                        5'd2: coeff_term = 8'sd4; // term=0 class=2
                        5'd3: coeff_term = 8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd2; // term=0 class=4
                        5'd5: coeff_term = -8'sd16; // term=0 class=5
                        5'd6: coeff_term = -8'sd16; // term=0 class=6
                        5'd7: coeff_term = 8'sd8; // term=0 class=7
                        5'd8: coeff_term = -8'sd2; // term=0 class=8
                        5'd9: coeff_term = 8'sd2; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd2; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = -8'sd2; // term=1 class=5
                        5'd22: coeff_term = -8'sd4; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = -8'sd1; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd32;
                        4'b0001: coeff_term = -8'sd64;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = -8'sd2;
                        4'b1000: coeff_term = -8'sd16;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[7] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[7][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (7 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_8
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd0; // term=0 class=1
                        5'd2: coeff_term = -8'sd4; // term=0 class=2
                        5'd3: coeff_term = 8'sd2; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd4; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = -8'sd8; // term=0 class=8
                        5'd9: coeff_term = 8'sd0; // term=0 class=9
                        5'd16: coeff_term = 8'sd2; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = -8'sd2; // term=1 class=2
                        5'd19: coeff_term = 8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = -8'sd4; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd0;
                        2'd1: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd32;
                        4'b0001: coeff_term = -8'sd2;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = -8'sd16;
                        4'b1000: coeff_term = -8'sd8;
                        4'b1001: coeff_term = -8'sd2;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[8] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[8][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (8 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_9
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd8; // term=0 class=0
                        5'd1: coeff_term = 8'sd0; // term=0 class=1
                        5'd2: coeff_term = -8'sd8; // term=0 class=2
                        5'd3: coeff_term = -8'sd8; // term=0 class=3
                        5'd4: coeff_term = 8'sd2; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd8; // term=0 class=6
                        5'd7: coeff_term = 8'sd8; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = -8'sd2; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = -8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = -8'sd1;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd16;
                        4'b0001: coeff_term = -8'sd2;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = -8'sd8;
                        4'b1000: coeff_term = 8'sd16;
                        4'b1001: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[9] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[9][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (9 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_10
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd2; // term=0 class=2
                        5'd3: coeff_term = -8'sd2; // term=0 class=3
                        5'd4: coeff_term = -8'sd4; // term=0 class=4
                        5'd5: coeff_term = 8'sd2; // term=0 class=5
                        5'd6: coeff_term = -8'sd8; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = -8'sd2; // term=0 class=8
                        5'd9: coeff_term = 8'sd2; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd1; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = -8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = -8'sd2; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd2;
                        2'd1: coeff_term = 8'sd2;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd16;
                        4'b0001: coeff_term = 8'sd2;
                        4'b0100: coeff_term = -8'sd2;
                        4'b0101: coeff_term = -8'sd8;
                        4'b1000: coeff_term = 8'sd16;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[10] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[10][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (10 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_11
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd8; // term=0 class=1
                        5'd2: coeff_term = 8'sd8; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd2; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = -8'sd8; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd2; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd2;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd8;
                        4'b0001: coeff_term = 8'sd2;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = 8'sd4;
                        4'b1000: coeff_term = 8'sd32;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[11] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[11][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (11 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_12
            localparam integer AW = 10;
            localparam integer PW = 16;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd2; // term=0 class=1
                        5'd2: coeff_term = 8'sd8; // term=0 class=2
                        5'd3: coeff_term = -8'sd8; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = -8'sd8; // term=0 class=5
                        5'd6: coeff_term = 8'sd2; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = 8'sd8; // term=0 class=8
                        5'd9: coeff_term = -8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd1; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = -8'sd4; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = -8'sd4; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd1; // term=1 class=8
                        5'd25: coeff_term = 8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = -8'sd16;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd64;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = 8'sd16;
                        4'b0101: coeff_term = 8'sd0;
                        4'b1000: coeff_term = -8'sd16;
                        4'b1001: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[12] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[12][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (12 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_13
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd8; // term=0 class=1
                        5'd2: coeff_term = 8'sd4; // term=0 class=2
                        5'd3: coeff_term = -8'sd16; // term=0 class=3
                        5'd4: coeff_term = 8'sd2; // term=0 class=4
                        5'd5: coeff_term = -8'sd2; // term=0 class=5
                        5'd6: coeff_term = 8'sd2; // term=0 class=6
                        5'd7: coeff_term = 8'sd4; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = -8'sd2; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd2; // term=1 class=3
                        5'd20: coeff_term = 8'sd1; // term=1 class=4
                        5'd21: coeff_term = -8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = -8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd0;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd32;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd4;
                        4'b0101: coeff_term = 8'sd16;
                        4'b1000: coeff_term = -8'sd8;
                        4'b1001: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[13] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[13][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (13 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_14
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd2; // term=0 class=1
                        5'd2: coeff_term = -8'sd4; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = 8'sd4; // term=0 class=4
                        5'd5: coeff_term = 8'sd4; // term=0 class=5
                        5'd6: coeff_term = -8'sd2; // term=0 class=6
                        5'd7: coeff_term = 8'sd8; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd8; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd1; // term=1 class=1
                        5'd18: coeff_term = -8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd2; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = -8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = -8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd0;
                        2'd1: coeff_term = -8'sd2;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd4;
                        4'b0001: coeff_term = 8'sd4;
                        4'b0100: coeff_term = 8'sd8;
                        4'b0101: coeff_term = 8'sd0;
                        4'b1000: coeff_term = 8'sd16;
                        4'b1001: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[14] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[14][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (14 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_15
            localparam integer AW = 10;
            localparam integer PW = 16;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd2; // term=0 class=0
                        5'd1: coeff_term = -8'sd4; // term=0 class=1
                        5'd2: coeff_term = -8'sd16; // term=0 class=2
                        5'd3: coeff_term = 8'sd2; // term=0 class=3
                        5'd4: coeff_term = 8'sd2; // term=0 class=4
                        5'd5: coeff_term = 8'sd2; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = 8'sd2; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = -8'sd1; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = -8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd64;
                        4'b0001: coeff_term = 8'sd0;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = 8'sd16;
                        4'b1000: coeff_term = 8'sd16;
                        4'b1001: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[15] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[15][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (15 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_16
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd2; // term=0 class=0
                        5'd1: coeff_term = -8'sd2; // term=0 class=1
                        5'd2: coeff_term = 8'sd8; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = -8'sd2; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = -8'sd2; // term=0 class=6
                        5'd7: coeff_term = 8'sd2; // term=0 class=7
                        5'd8: coeff_term = 8'sd4; // term=0 class=8
                        5'd9: coeff_term = -8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = -8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = -8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = -8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd32;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = 8'sd0;
                        4'b1000: coeff_term = -8'sd8;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[16] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[16][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (16 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_17
            localparam integer AW = 9;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd8; // term=0 class=0
                        5'd1: coeff_term = -8'sd8; // term=0 class=1
                        5'd2: coeff_term = -8'sd8; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = 8'sd2; // term=0 class=4
                        5'd5: coeff_term = 8'sd8; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = -8'sd8; // term=0 class=7
                        5'd8: coeff_term = 8'sd8; // term=0 class=8
                        5'd9: coeff_term = 8'sd8; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = -8'sd2; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = -8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd2; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd32;
                        2'd1: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd64;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd4;
                        4'b0101: coeff_term = 8'sd8;
                        4'b1000: coeff_term = -8'sd2;
                        4'b1001: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[17] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[17][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (17 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_18
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd2; // term=0 class=1
                        5'd2: coeff_term = -8'sd2; // term=0 class=2
                        5'd3: coeff_term = 8'sd4; // term=0 class=3
                        5'd4: coeff_term = -8'sd4; // term=0 class=4
                        5'd5: coeff_term = -8'sd2; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = 8'sd2; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd4; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd1; // term=1 class=3
                        5'd20: coeff_term = -8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd8;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = 8'sd4;
                        4'b0101: coeff_term = 8'sd8;
                        4'b1000: coeff_term = 8'sd4;
                        4'b1001: coeff_term = 8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[18] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[18][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (18 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_19
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd8; // term=0 class=0
                        5'd1: coeff_term = -8'sd8; // term=0 class=1
                        5'd2: coeff_term = 8'sd2; // term=0 class=2
                        5'd3: coeff_term = 8'sd2; // term=0 class=3
                        5'd4: coeff_term = -8'sd4; // term=0 class=4
                        5'd5: coeff_term = -8'sd8; // term=0 class=5
                        5'd6: coeff_term = -8'sd16; // term=0 class=6
                        5'd7: coeff_term = 8'sd8; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd4; // term=0 class=9
                        5'd16: coeff_term = 8'sd2; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = -8'sd2; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd4; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd32;
                        2'd1: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd32;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = 8'sd8;
                        4'b1000: coeff_term = 8'sd8;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[19] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[19][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (19 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_20
            localparam integer AW = 10;
            localparam integer PW = 16;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = -8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd2; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = 8'sd4; // term=0 class=4
                        5'd5: coeff_term = 8'sd2; // term=0 class=5
                        5'd6: coeff_term = -8'sd4; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd8; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = -8'sd2; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = -8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd64;
                        2'd1: coeff_term = -8'sd32;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd16;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = 8'sd32;
                        4'b1000: coeff_term = 8'sd32;
                        4'b1001: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[20] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[20][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (20 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_21
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = -8'sd16; // term=0 class=1
                        5'd2: coeff_term = -8'sd4; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd8; // term=0 class=4
                        5'd5: coeff_term = 8'sd2; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = -8'sd8; // term=0 class=7
                        5'd8: coeff_term = -8'sd2; // term=0 class=8
                        5'd9: coeff_term = 8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd2; // term=1 class=1
                        5'd18: coeff_term = -8'sd2; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd2; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = -8'sd1; // term=1 class=7
                        5'd24: coeff_term = -8'sd1; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd16;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = 8'sd16;
                        4'b1000: coeff_term = 8'sd32;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[21] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[21][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (21 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_22
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = -8'sd2; // term=0 class=1
                        5'd2: coeff_term = -8'sd2; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = 8'sd2; // term=0 class=8
                        5'd9: coeff_term = -8'sd4; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd1; // term=1 class=8
                        5'd25: coeff_term = -8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd4;
                        4'b0001: coeff_term = -8'sd16;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = -8'sd4;
                        4'b1000: coeff_term = 8'sd8;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[22] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[22][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (22 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_23
            localparam integer AW = 9;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd2; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd8; // term=0 class=4
                        5'd5: coeff_term = 8'sd4; // term=0 class=5
                        5'd6: coeff_term = 8'sd4; // term=0 class=6
                        5'd7: coeff_term = 8'sd8; // term=0 class=7
                        5'd8: coeff_term = -8'sd8; // term=0 class=8
                        5'd9: coeff_term = -8'sd4; // term=0 class=9
                        5'd16: coeff_term = -8'sd2; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = -8'sd2; // term=1 class=3
                        5'd20: coeff_term = -8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd1; // term=1 class=6
                        5'd23: coeff_term = -8'sd1; // term=1 class=7
                        5'd24: coeff_term = -8'sd2; // term=1 class=8
                        5'd25: coeff_term = -8'sd2; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = 8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd8;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = -8'sd4;
                        4'b1000: coeff_term = 8'sd8;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[23] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[23][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (23 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_24
            localparam integer AW = 10;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd2; // term=0 class=1
                        5'd2: coeff_term = 8'sd8; // term=0 class=2
                        5'd3: coeff_term = 8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = 8'sd8; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = -8'sd8; // term=0 class=7
                        5'd8: coeff_term = -8'sd4; // term=0 class=8
                        5'd9: coeff_term = 8'sd0; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = -8'sd4; // term=1 class=7
                        5'd24: coeff_term = -8'sd2; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd4;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd4;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = -8'sd1;
                        4'b1000: coeff_term = 8'sd1;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[24] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[24][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (24 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_25
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd16; // term=0 class=0
                        5'd1: coeff_term = -8'sd16; // term=0 class=1
                        5'd2: coeff_term = 8'sd0; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = -8'sd16; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd16; // term=0 class=6
                        5'd7: coeff_term = -8'sd16; // term=0 class=7
                        5'd8: coeff_term = 8'sd8; // term=0 class=8
                        5'd9: coeff_term = -8'sd4; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd2; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd8;
                        4'b0001: coeff_term = -8'sd16;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = 8'sd4;
                        4'b1000: coeff_term = 8'sd32;
                        4'b1001: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[25] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[25][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (25 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_26
            localparam integer AW = 9;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd2; // term=0 class=0
                        5'd1: coeff_term = 8'sd16; // term=0 class=1
                        5'd2: coeff_term = 8'sd8; // term=0 class=2
                        5'd3: coeff_term = 8'sd2; // term=0 class=3
                        5'd4: coeff_term = -8'sd2; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd8; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = -8'sd2; // term=0 class=8
                        5'd9: coeff_term = -8'sd16; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = -8'sd2; // term=1 class=1
                        5'd18: coeff_term = 8'sd2; // term=1 class=2
                        5'd19: coeff_term = 8'sd1; // term=1 class=3
                        5'd20: coeff_term = -8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = -8'sd4; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd32;
                        2'd1: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd16;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = -8'sd32;
                        4'b0101: coeff_term = 8'sd8;
                        4'b1000: coeff_term = 8'sd64;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[26] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[26][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (26 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_27
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd0; // term=0 class=1
                        5'd2: coeff_term = 8'sd2; // term=0 class=2
                        5'd3: coeff_term = 8'sd8; // term=0 class=3
                        5'd4: coeff_term = -8'sd4; // term=0 class=4
                        5'd5: coeff_term = 8'sd2; // term=0 class=5
                        5'd6: coeff_term = -8'sd4; // term=0 class=6
                        5'd7: coeff_term = -8'sd4; // term=0 class=7
                        5'd8: coeff_term = 8'sd4; // term=0 class=8
                        5'd9: coeff_term = 8'sd0; // term=0 class=9
                        5'd16: coeff_term = -8'sd2; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = -8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = -8'sd2; // term=1 class=6
                        5'd23: coeff_term = -8'sd2; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd32;
                        4'b0001: coeff_term = -8'sd16;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = 8'sd4;
                        4'b1000: coeff_term = 8'sd16;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[27] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[27][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (27 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_28
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = -8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd0; // term=0 class=2
                        5'd3: coeff_term = 8'sd8; // term=0 class=3
                        5'd4: coeff_term = -8'sd4; // term=0 class=4
                        5'd5: coeff_term = 8'sd2; // term=0 class=5
                        5'd6: coeff_term = -8'sd16; // term=0 class=6
                        5'd7: coeff_term = 8'sd4; // term=0 class=7
                        5'd8: coeff_term = 8'sd2; // term=0 class=8
                        5'd9: coeff_term = 8'sd2; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = -8'sd1; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd2; // term=1 class=3
                        5'd20: coeff_term = -8'sd1; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = -8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd0;
                        2'd1: coeff_term = 8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd32;
                        4'b0001: coeff_term = -8'sd16;
                        4'b0100: coeff_term = 8'sd4;
                        4'b0101: coeff_term = 8'sd0;
                        4'b1000: coeff_term = 8'sd8;
                        4'b1001: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[28] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[28][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (28 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_29
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd4; // term=0 class=0
                        5'd1: coeff_term = -8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd2; // term=0 class=2
                        5'd3: coeff_term = 8'sd2; // term=0 class=3
                        5'd4: coeff_term = -8'sd8; // term=0 class=4
                        5'd5: coeff_term = 8'sd4; // term=0 class=5
                        5'd6: coeff_term = -8'sd2; // term=0 class=6
                        5'd7: coeff_term = -8'sd8; // term=0 class=7
                        5'd8: coeff_term = 8'sd8; // term=0 class=8
                        5'd9: coeff_term = 8'sd0; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = -8'sd1; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd1; // term=1 class=3
                        5'd20: coeff_term = -8'sd4; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = -8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd2; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd8;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = -8'sd2;
                        4'b0101: coeff_term = 8'sd16;
                        4'b1000: coeff_term = 8'sd16;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[29] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[29][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (29 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_30
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = -8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd2; // term=0 class=2
                        5'd3: coeff_term = 8'sd2; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = 8'sd4; // term=0 class=5
                        5'd6: coeff_term = -8'sd8; // term=0 class=6
                        5'd7: coeff_term = 8'sd4; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd0; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd2;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd8;
                        4'b0001: coeff_term = -8'sd4;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = 8'sd2;
                        4'b1000: coeff_term = 8'sd16;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[30] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[30][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (30 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_31
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd8; // term=0 class=0
                        5'd1: coeff_term = 8'sd8; // term=0 class=1
                        5'd2: coeff_term = 8'sd8; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = 8'sd2; // term=0 class=5
                        5'd6: coeff_term = -8'sd8; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = 8'sd2; // term=0 class=8
                        5'd9: coeff_term = 8'sd2; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd1; // term=1 class=1
                        5'd18: coeff_term = -8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd8;
                        4'b0001: coeff_term = 8'sd0;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = 8'sd16;
                        4'b1000: coeff_term = 8'sd32;
                        4'b1001: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[31] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[31][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (31 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_32
            localparam integer AW = 9;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd4; // term=0 class=0
                        5'd1: coeff_term = -8'sd8; // term=0 class=1
                        5'd2: coeff_term = -8'sd4; // term=0 class=2
                        5'd3: coeff_term = -8'sd8; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd4; // term=0 class=6
                        5'd7: coeff_term = -8'sd4; // term=0 class=7
                        5'd8: coeff_term = 8'sd4; // term=0 class=8
                        5'd9: coeff_term = 8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = -8'sd1; // term=1 class=1
                        5'd18: coeff_term = -8'sd2; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd2; // term=1 class=8
                        5'd25: coeff_term = 8'sd4; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd4;
                        2'd1: coeff_term = 8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd32;
                        4'b0001: coeff_term = -8'sd32;
                        4'b0100: coeff_term = 8'sd4;
                        4'b0101: coeff_term = -8'sd8;
                        4'b1000: coeff_term = 8'sd8;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[32] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[32][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (32 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_33
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd2; // term=0 class=1
                        5'd2: coeff_term = -8'sd8; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd4; // term=0 class=6
                        5'd7: coeff_term = -8'sd8; // term=0 class=7
                        5'd8: coeff_term = -8'sd2; // term=0 class=8
                        5'd9: coeff_term = -8'sd4; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd1; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = -8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = -8'sd1; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = 8'sd32;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd16;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = 8'sd8;
                        4'b0101: coeff_term = 8'sd32;
                        4'b1000: coeff_term = 8'sd32;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[33] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[33][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (33 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_34
            localparam integer AW = 9;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd4; // term=0 class=1
                        5'd2: coeff_term = -8'sd8; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd4; // term=0 class=4
                        5'd5: coeff_term = -8'sd4; // term=0 class=5
                        5'd6: coeff_term = 8'sd4; // term=0 class=6
                        5'd7: coeff_term = 8'sd4; // term=0 class=7
                        5'd8: coeff_term = -8'sd8; // term=0 class=8
                        5'd9: coeff_term = -8'sd4; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd2; // term=1 class=1
                        5'd18: coeff_term = -8'sd4; // term=1 class=2
                        5'd19: coeff_term = -8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd2; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd1; // term=1 class=8
                        5'd25: coeff_term = -8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd16;
                        4'b0001: coeff_term = -8'sd16;
                        4'b0100: coeff_term = -8'sd16;
                        4'b0101: coeff_term = 8'sd2;
                        4'b1000: coeff_term = 8'sd8;
                        4'b1001: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[34] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[34][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (34 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_35
            localparam integer AW = 9;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd4; // term=0 class=1
                        5'd2: coeff_term = -8'sd8; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = 8'sd8; // term=0 class=4
                        5'd5: coeff_term = 8'sd8; // term=0 class=5
                        5'd6: coeff_term = -8'sd4; // term=0 class=6
                        5'd7: coeff_term = 8'sd8; // term=0 class=7
                        5'd8: coeff_term = -8'sd4; // term=0 class=8
                        5'd9: coeff_term = -8'sd8; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd1; // term=1 class=1
                        5'd18: coeff_term = -8'sd4; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd2; // term=1 class=4
                        5'd21: coeff_term = 8'sd2; // term=1 class=5
                        5'd22: coeff_term = -8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd4; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = -8'sd2; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = 8'sd32;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd0;
                        4'b0001: coeff_term = 8'sd4;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = 8'sd64;
                        4'b1000: coeff_term = 8'sd32;
                        4'b1001: coeff_term = -8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[35] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[35][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (35 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_36
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd4; // term=0 class=0
                        5'd1: coeff_term = 8'sd0; // term=0 class=1
                        5'd2: coeff_term = 8'sd0; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd2; // term=0 class=6
                        5'd7: coeff_term = -8'sd8; // term=0 class=7
                        5'd8: coeff_term = -8'sd4; // term=0 class=8
                        5'd9: coeff_term = -8'sd4; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = -8'sd2; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd4;
                        2'd1: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd4;
                        4'b0001: coeff_term = -8'sd16;
                        4'b0100: coeff_term = 8'sd0;
                        4'b0101: coeff_term = -8'sd8;
                        4'b1000: coeff_term = 8'sd0;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[36] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[36][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (36 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_37
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd2; // term=0 class=0
                        5'd1: coeff_term = 8'sd0; // term=0 class=1
                        5'd2: coeff_term = 8'sd0; // term=0 class=2
                        5'd3: coeff_term = 8'sd8; // term=0 class=3
                        5'd4: coeff_term = -8'sd8; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd2; // term=0 class=6
                        5'd7: coeff_term = -8'sd2; // term=0 class=7
                        5'd8: coeff_term = -8'sd2; // term=0 class=8
                        5'd9: coeff_term = 8'sd2; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd4; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = -8'sd1; // term=1 class=7
                        5'd24: coeff_term = -8'sd1; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd8;
                        4'b0001: coeff_term = 8'sd2;
                        4'b0100: coeff_term = 8'sd16;
                        4'b0101: coeff_term = 8'sd32;
                        4'b1000: coeff_term = 8'sd16;
                        4'b1001: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[37] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[37][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (37 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_38
            localparam integer AW = 10;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd8; // term=0 class=0
                        5'd1: coeff_term = 8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd4; // term=0 class=2
                        5'd3: coeff_term = 8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = -8'sd16; // term=0 class=5
                        5'd6: coeff_term = -8'sd4; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = 8'sd8; // term=0 class=8
                        5'd9: coeff_term = 8'sd4; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd2; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd2; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = -8'sd2; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = -8'sd1; // term=1 class=8
                        5'd25: coeff_term = 8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd4;
                        2'd1: coeff_term = 8'sd1;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd8;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = -8'sd1;
                        4'b0101: coeff_term = 8'sd0;
                        4'b1000: coeff_term = -8'sd1;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[38] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[38][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (38 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_39
            localparam integer AW = 10;
            localparam integer PW = 15;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = -8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd2; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = -8'sd8; // term=0 class=5
                        5'd6: coeff_term = -8'sd2; // term=0 class=6
                        5'd7: coeff_term = 8'sd2; // term=0 class=7
                        5'd8: coeff_term = 8'sd2; // term=0 class=8
                        5'd9: coeff_term = 8'sd0; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = -8'sd2; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = -8'sd1; // term=1 class=5
                        5'd22: coeff_term = -8'sd1; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd1; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd8;
                        4'b0001: coeff_term = 8'sd4;
                        4'b0100: coeff_term = 8'sd8;
                        4'b0101: coeff_term = 8'sd32;
                        4'b1000: coeff_term = 8'sd16;
                        4'b1001: coeff_term = -8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[39] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[39][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (39 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_40
            localparam integer AW = 10;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd2; // term=0 class=0
                        5'd1: coeff_term = 8'sd2; // term=0 class=1
                        5'd2: coeff_term = 8'sd16; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = -8'sd4; // term=0 class=4
                        5'd5: coeff_term = -8'sd4; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = 8'sd8; // term=0 class=7
                        5'd8: coeff_term = 8'sd8; // term=0 class=8
                        5'd9: coeff_term = -8'sd16; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd1; // term=1 class=1
                        5'd18: coeff_term = -8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = -8'sd2; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = -8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd1; // term=1 class=8
                        5'd25: coeff_term = 8'sd2; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd4;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = 8'sd4;
                        4'b1000: coeff_term = 8'sd8;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[40] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[40][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (40 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_41
            localparam integer AW = 9;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd8; // term=0 class=0
                        5'd1: coeff_term = 8'sd2; // term=0 class=1
                        5'd2: coeff_term = 8'sd4; // term=0 class=2
                        5'd3: coeff_term = -8'sd2; // term=0 class=3
                        5'd4: coeff_term = -8'sd8; // term=0 class=4
                        5'd5: coeff_term = -8'sd8; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = 8'sd8; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = -8'sd8; // term=0 class=9
                        5'd16: coeff_term = -8'sd2; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = -8'sd4; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd2; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = -8'sd2; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd0;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = -8'sd8;
                        4'b0101: coeff_term = 8'sd8;
                        4'b1000: coeff_term = 8'sd4;
                        4'b1001: coeff_term = -8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[41] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[41][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (41 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_42
            localparam integer AW = 10;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd2; // term=0 class=0
                        5'd1: coeff_term = -8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd4; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = -8'sd8; // term=0 class=5
                        5'd6: coeff_term = -8'sd4; // term=0 class=6
                        5'd7: coeff_term = 8'sd4; // term=0 class=7
                        5'd8: coeff_term = -8'sd8; // term=0 class=8
                        5'd9: coeff_term = 8'sd2; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = -8'sd1; // term=1 class=1
                        5'd18: coeff_term = 8'sd2; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = -8'sd1; // term=1 class=5
                        5'd22: coeff_term = -8'sd2; // term=1 class=6
                        5'd23: coeff_term = 8'sd2; // term=1 class=7
                        5'd24: coeff_term = -8'sd1; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd0;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd4;
                        4'b0001: coeff_term = 8'sd0;
                        4'b0100: coeff_term = 8'sd0;
                        4'b0101: coeff_term = 8'sd4;
                        4'b1000: coeff_term = -8'sd4;
                        4'b1001: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[42] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[42][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (42 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_43
            localparam integer AW = 9;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd8; // term=0 class=0
                        5'd1: coeff_term = -8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd4; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = -8'sd4; // term=0 class=4
                        5'd5: coeff_term = -8'sd8; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = 8'sd8; // term=0 class=7
                        5'd8: coeff_term = -8'sd8; // term=0 class=8
                        5'd9: coeff_term = 8'sd2; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = -8'sd2; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = -8'sd1; // term=1 class=4
                        5'd21: coeff_term = -8'sd2; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = -8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd1; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = 8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = -8'sd4;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = 8'sd4;
                        4'b0101: coeff_term = 8'sd16;
                        4'b1000: coeff_term = 8'sd8;
                        4'b1001: coeff_term = -8'sd2;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[43] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[43][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (43 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_44
            localparam integer AW = 9;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd0; // term=0 class=0
                        5'd1: coeff_term = 8'sd4; // term=0 class=1
                        5'd2: coeff_term = 8'sd0; // term=0 class=2
                        5'd3: coeff_term = -8'sd4; // term=0 class=3
                        5'd4: coeff_term = 8'sd2; // term=0 class=4
                        5'd5: coeff_term = 8'sd0; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = 8'sd2; // term=0 class=7
                        5'd8: coeff_term = 8'sd2; // term=0 class=8
                        5'd9: coeff_term = -8'sd2; // term=0 class=9
                        5'd16: coeff_term = 8'sd0; // term=1 class=0
                        5'd17: coeff_term = 8'sd1; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = -8'sd1; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd16;
                        2'd1: coeff_term = 8'sd32;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd8;
                        4'b0001: coeff_term = -8'sd8;
                        4'b0100: coeff_term = 8'sd8;
                        4'b0101: coeff_term = 8'sd32;
                        4'b1000: coeff_term = 8'sd4;
                        4'b1001: coeff_term = -8'sd2;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[44] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[44][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (44 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_45
            localparam integer AW = 9;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd4; // term=0 class=0
                        5'd1: coeff_term = -8'sd2; // term=0 class=1
                        5'd2: coeff_term = -8'sd4; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = 8'sd0; // term=0 class=4
                        5'd5: coeff_term = 8'sd8; // term=0 class=5
                        5'd6: coeff_term = -8'sd8; // term=0 class=6
                        5'd7: coeff_term = 8'sd0; // term=0 class=7
                        5'd8: coeff_term = -8'sd8; // term=0 class=8
                        5'd9: coeff_term = 8'sd0; // term=0 class=9
                        5'd16: coeff_term = -8'sd2; // term=1 class=0
                        5'd17: coeff_term = -8'sd1; // term=1 class=1
                        5'd18: coeff_term = 8'sd0; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = -8'sd1; // term=1 class=5
                        5'd22: coeff_term = -8'sd2; // term=1 class=6
                        5'd23: coeff_term = 8'sd0; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd4;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd16;
                        4'b0001: coeff_term = 8'sd0;
                        4'b0100: coeff_term = 8'sd4;
                        4'b0101: coeff_term = 8'sd8;
                        4'b1000: coeff_term = -8'sd4;
                        4'b1001: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[45] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[45][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (45 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_46
            localparam integer AW = 10;
            localparam integer PW = 14;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = -8'sd2; // term=0 class=0
                        5'd1: coeff_term = 8'sd0; // term=0 class=1
                        5'd2: coeff_term = -8'sd8; // term=0 class=2
                        5'd3: coeff_term = 8'sd8; // term=0 class=3
                        5'd4: coeff_term = -8'sd4; // term=0 class=4
                        5'd5: coeff_term = 8'sd8; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = 8'sd4; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = 8'sd2; // term=0 class=9
                        5'd16: coeff_term = -8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = 8'sd1; // term=1 class=2
                        5'd19: coeff_term = 8'sd4; // term=1 class=3
                        5'd20: coeff_term = -8'sd2; // term=1 class=4
                        5'd21: coeff_term = 8'sd0; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = 8'sd1; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd4;
                        2'd1: coeff_term = 8'sd8;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd0;
                        4'b0001: coeff_term = 8'sd0;
                        4'b0100: coeff_term = 8'sd8;
                        4'b0101: coeff_term = 8'sd16;
                        4'b1000: coeff_term = 8'sd2;
                        4'b1001: coeff_term = 8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[46] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[46][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (46 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_47
            localparam integer AW = 9;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        5'd0: coeff_term = 8'sd2; // term=0 class=0
                        5'd1: coeff_term = 8'sd0; // term=0 class=1
                        5'd2: coeff_term = -8'sd4; // term=0 class=2
                        5'd3: coeff_term = 8'sd0; // term=0 class=3
                        5'd4: coeff_term = -8'sd4; // term=0 class=4
                        5'd5: coeff_term = 8'sd2; // term=0 class=5
                        5'd6: coeff_term = 8'sd0; // term=0 class=6
                        5'd7: coeff_term = -8'sd4; // term=0 class=7
                        5'd8: coeff_term = 8'sd0; // term=0 class=8
                        5'd9: coeff_term = -8'sd2; // term=0 class=9
                        5'd16: coeff_term = 8'sd1; // term=1 class=0
                        5'd17: coeff_term = 8'sd0; // term=1 class=1
                        5'd18: coeff_term = -8'sd2; // term=1 class=2
                        5'd19: coeff_term = 8'sd0; // term=1 class=3
                        5'd20: coeff_term = 8'sd0; // term=1 class=4
                        5'd21: coeff_term = 8'sd1; // term=1 class=5
                        5'd22: coeff_term = 8'sd0; // term=1 class=6
                        5'd23: coeff_term = -8'sd2; // term=1 class=7
                        5'd24: coeff_term = 8'sd0; // term=1 class=8
                        5'd25: coeff_term = 8'sd0; // term=1 class=9
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd8;
                        2'd1: coeff_term = 8'sd16;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd8;
                        4'b0001: coeff_term = 8'sd0;
                        4'b0100: coeff_term = 8'sd16;
                        4'b0101: coeff_term = 8'sd16;
                        4'b1000: coeff_term = 8'sd2;
                        4'b1001: coeff_term = 8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[47] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[47][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (47 < 48)))
                    p3_p_q <= prod_comb;
            end
        end

        if (1) begin : G_LANE_48
            localparam integer AW = 10;
            localparam integer PW = 13;
            logic signed [AW-1:0] p2_a_q;
            logic signed [PW-1:0] p3_p_q;
            logic signed [PW-1:0] prod_comb;
            logic signed [7:0] coeff_term;
            wire signed [PW-1:0] a_ext =
                {{(PW-AW){p2_a_q[AW-1]}}, p2_a_q};

            always_comb begin
                coeff_term = 8'sd0;
                if (p2_is_fc) begin
                    case ({p2_tag[4],p2_tag[3:0]})
                        default: coeff_term = 8'sd0;
                    endcase
                end else if (!p2_tag[15]) begin
                    case (p2_tag[3:2])
                        2'd0: coeff_term = 8'sd4;
                        2'd1: coeff_term = 8'sd4;
                        default: coeff_term = 8'sd0;
                    endcase
                end else begin
                    case ({p2_tag[3:2],p2_tag[1:0]})
                        4'b0000: coeff_term = 8'sd8;
                        4'b0001: coeff_term = 8'sd0;
                        4'b0100: coeff_term = 8'sd4;
                        4'b0101: coeff_term = 8'sd2;
                        4'b1000: coeff_term = 8'sd0;
                        4'b1001: coeff_term = 8'sd0;
                        default: coeff_term = 8'sd0;
                    endcase
                end

                case (coeff_term)
                    -8'sd64: prod_comb = -($signed(a_ext) <<< 6);
                    -8'sd32: prod_comb = -($signed(a_ext) <<< 5);
                    -8'sd16: prod_comb = -($signed(a_ext) <<< 4);
                    -8'sd8: prod_comb = -($signed(a_ext) <<< 3);
                    -8'sd4: prod_comb = -($signed(a_ext) <<< 2);
                    -8'sd2: prod_comb = -($signed(a_ext) <<< 1);
                    -8'sd1: prod_comb = -$signed(a_ext);
                    8'sd0: prod_comb = '0;
                    8'sd1: prod_comb = $signed(a_ext);
                    8'sd2: prod_comb = ($signed(a_ext) <<< 1);
                    8'sd4: prod_comb = ($signed(a_ext) <<< 2);
                    8'sd8: prod_comb = ($signed(a_ext) <<< 3);
                    8'sd16: prod_comb = ($signed(a_ext) <<< 4);
                    8'sd32: prod_comb = ($signed(a_ext) <<< 5);
                    8'sd64: prod_comb = ($signed(a_ext) <<< 6);
                    default: prod_comb = '0;
                endcase
            end

            assign p3_p[48] = {{(18-PW){p3_p_q[PW-1]}}, p3_p_q};

            always_ff @(posedge clk) begin
                if (p1_valid)
                    p2_a_q <= p2_a_comb[48][AW-1:0];
                if (p2_valid && ((!p2_is_fc) || (48 < 48)))
                    p3_p_q <= prod_comb;
            end
        end
    endgenerate

    logic p4_valid,p4_is_fc;
    logic [15:0] p4_tag;
    logic signed [17:0] p4_h33 [0:3][0:1];
    logic signed [16:0] p4_h32 [0:3][0:1];
    logic signed [16:0] p4_h23 [0:2][0:1];
    logic signed [14:0] p4_h22 [0:2][0:1];
    logic signed [14:0] p4_fc_grp [0:15];

    function automatic logic signed [17:0] a3_h18(
        input logic signed [17:0] x0,x1,x2,x3,input integer o);
        logic signed [19:0] t;
        begin
            if(o==0) t=$signed(x0)+$signed(x1)+$signed(x2);
            else     t=$signed(x1)-$signed(x2)-$signed(x3);
            a3_h18=t[17:0];
        end
    endfunction
    function automatic logic signed [16:0] a2_h17(
        input logic signed [17:0] x0,x1,x2,input integer o);
        logic signed [19:0] t;
        begin
            if(o==0) t=$signed(x0)+$signed(x1);
            else     t=$signed(x1)+$signed(x2);
            a2_h17=t[16:0];
        end
    endfunction
    function automatic logic signed [16:0] a3_h17(
        input logic signed [17:0] x0,x1,x2,x3,input integer o);
        logic signed [19:0] t;
        begin
            if(o==0) t=$signed(x0)+$signed(x1)+$signed(x2);
            else     t=$signed(x1)-$signed(x2)-$signed(x3);
            a3_h17=t[16:0];
        end
    endfunction
    function automatic logic signed [14:0] a2_h15(
        input logic signed [17:0] x0,x1,x2,input integer o);
        logic signed [19:0] t;
        begin
            if(o==0) t=$signed(x0)+$signed(x1);
            else     t=$signed(x1)+$signed(x2);
            a2_h15=t[14:0];
        end
    endfunction

    integer p4r,p4g;
    always_ff @(posedge clk) begin
        if(!rst_n) begin
            p4_valid<=1'b0; p4_is_fc<=1'b0; p4_tag<=16'd0;
        end else begin
            p4_valid<=p3_valid;
            if(p3_valid) begin
                p4_is_fc<=p3_is_fc; p4_tag<=p3_tag;
                if(p3_is_fc) begin
                    for(p4g=0;p4g<16;p4g=p4g+1)
                        p4_fc_grp[p4g] <=
                            $signed(p3_p[p4g*3]) +
                            $signed(p3_p[p4g*3+1]) +
                            $signed(p3_p[p4g*3+2]);
                end else begin
                    for(p4r=0;p4r<4;p4r=p4r+1) begin
                        p4_h33[p4r][0] <= a3_h18(p3_p[p4r*4+0],p3_p[p4r*4+1],p3_p[p4r*4+2],p3_p[p4r*4+3],0);
                        p4_h33[p4r][1] <= a3_h18(p3_p[p4r*4+0],p3_p[p4r*4+1],p3_p[p4r*4+2],p3_p[p4r*4+3],1);
                        p4_h32[p4r][0] <= a2_h17(p3_p[16+p4r*3+0],p3_p[16+p4r*3+1],p3_p[16+p4r*3+2],0);
                        p4_h32[p4r][1] <= a2_h17(p3_p[16+p4r*3+0],p3_p[16+p4r*3+1],p3_p[16+p4r*3+2],1);
                    end
                    for(p4r=0;p4r<3;p4r=p4r+1) begin
                        p4_h23[p4r][0] <= a3_h17(p3_p[28+p4r*4+0],p3_p[28+p4r*4+1],p3_p[28+p4r*4+2],p3_p[28+p4r*4+3],0);
                        p4_h23[p4r][1] <= a3_h17(p3_p[28+p4r*4+0],p3_p[28+p4r*4+1],p3_p[28+p4r*4+2],p3_p[28+p4r*4+3],1);
                        p4_h22[p4r][0] <= a2_h15(p3_p[40+p4r*3+0],p3_p[40+p4r*3+1],p3_p[40+p4r*3+2],0);
                        p4_h22[p4r][1] <= a2_h15(p3_p[40+p4r*3+0],p3_p[40+p4r*3+1],p3_p[40+p4r*3+2],1);
                    end
                end
            end
        end
    end

    logic p5_valid,p5_is_fc;
    logic [15:0] p5_tag;
    logic signed [18:0] p5_b0 [0:3];
    logic signed [17:0] p5_b1 [0:3];
    logic signed [17:0] p5_b2 [0:3];
    logic signed [15:0] p5_b3 [0:3];
    logic signed [15:0] p5_fc_grp4 [0:3];

    function automatic logic signed [18:0] a3_v19(
        input logic signed [17:0] x0,x1,x2,x3,input integer o);
        logic signed [20:0] t;
        begin
            if(o==0) t=$signed(x0)+$signed(x1)+$signed(x2);
            else     t=$signed(x1)-$signed(x2)-$signed(x3);
            a3_v19=t[18:0];
        end
    endfunction
    function automatic logic signed [17:0] a3_v18_from17(
        input logic signed [16:0] x0,x1,x2,x3,input integer o);
        logic signed [20:0] t;
        begin
            if(o==0) t=$signed(x0)+$signed(x1)+$signed(x2);
            else     t=$signed(x1)-$signed(x2)-$signed(x3);
            a3_v18_from17=t[17:0];
        end
    endfunction
    function automatic logic signed [17:0] a2_v18_from17(
        input logic signed [16:0] x0,x1,x2,input integer o);
        logic signed [19:0] t;
        begin
            if(o==0) t=$signed(x0)+$signed(x1);
            else     t=$signed(x1)+$signed(x2);
            a2_v18_from17=t[17:0];
        end
    endfunction
    function automatic logic signed [15:0] a2_v16_from15(
        input logic signed [14:0] x0,x1,x2,input integer o);
        logic signed [18:0] t;
        begin
            if(o==0) t=$signed(x0)+$signed(x1);
            else     t=$signed(x1)+$signed(x2);
            a2_v16_from15=t[15:0];
        end
    endfunction

    integer p5g;
    always_ff @(posedge clk) begin
        if(!rst_n) begin
            p5_valid<=1'b0; p5_is_fc<=1'b0; p5_tag<=16'd0;
        end else begin
            p5_valid<=p4_valid;
            if(p4_valid) begin
                p5_is_fc<=p4_is_fc; p5_tag<=p4_tag;
                if(p4_is_fc) begin
                    for(p5g=0;p5g<4;p5g=p5g+1)
                        p5_fc_grp4[p5g] <=
                            $signed({p4_fc_grp[p5g*4][14],p4_fc_grp[p5g*4]}) +
                            $signed({p4_fc_grp[p5g*4+1][14],p4_fc_grp[p5g*4+1]}) +
                            $signed({p4_fc_grp[p5g*4+2][14],p4_fc_grp[p5g*4+2]}) +
                            $signed({p4_fc_grp[p5g*4+3][14],p4_fc_grp[p5g*4+3]});
                end else begin
                    p5_b0[0] <= a3_v19(p4_h33[0][0],p4_h33[1][0],p4_h33[2][0],p4_h33[3][0],0);
                    p5_b0[1] <= a3_v19(p4_h33[0][1],p4_h33[1][1],p4_h33[2][1],p4_h33[3][1],0);
                    p5_b0[2] <= a3_v19(p4_h33[0][0],p4_h33[1][0],p4_h33[2][0],p4_h33[3][0],1);
                    p5_b0[3] <= a3_v19(p4_h33[0][1],p4_h33[1][1],p4_h33[2][1],p4_h33[3][1],1);

                    p5_b1[0] <= a3_v18_from17(p4_h32[0][0],p4_h32[1][0],p4_h32[2][0],p4_h32[3][0],0);
                    p5_b1[1] <= a3_v18_from17(p4_h32[0][1],p4_h32[1][1],p4_h32[2][1],p4_h32[3][1],0);
                    p5_b1[2] <= a3_v18_from17(p4_h32[0][0],p4_h32[1][0],p4_h32[2][0],p4_h32[3][0],1);
                    p5_b1[3] <= a3_v18_from17(p4_h32[0][1],p4_h32[1][1],p4_h32[2][1],p4_h32[3][1],1);

                    p5_b2[0] <= a2_v18_from17(p4_h23[0][0],p4_h23[1][0],p4_h23[2][0],0);
                    p5_b2[1] <= a2_v18_from17(p4_h23[0][1],p4_h23[1][1],p4_h23[2][1],0);
                    p5_b2[2] <= a2_v18_from17(p4_h23[0][0],p4_h23[1][0],p4_h23[2][0],1);
                    p5_b2[3] <= a2_v18_from17(p4_h23[0][1],p4_h23[1][1],p4_h23[2][1],1);

                    p5_b3[0] <= a2_v16_from15(p4_h22[0][0],p4_h22[1][0],p4_h22[2][0],0);
                    p5_b3[1] <= a2_v16_from15(p4_h22[0][1],p4_h22[1][1],p4_h22[2][1],0);
                    p5_b3[2] <= a2_v16_from15(p4_h22[0][0],p4_h22[1][0],p4_h22[2][0],1);
                    p5_b3[3] <= a2_v16_from15(p4_h22[0][1],p4_h22[1][1],p4_h22[2][1],1);
                end
            end
        end
    end

    logic signed [21:0] y0_comb,y1_comb,y2_comb,y3_comb;
    logic signed [16:0] fc48_wide;
    logic signed [15:0] fc48_comb;
    always_comb begin
        y0_comb = ($signed({{3{p5_b0[0][18]}},p5_b0[0]}) >>> 2)
                + ($signed({{4{p5_b1[0][17]}},p5_b1[0]}) >>> 1)
                + ($signed({{4{p5_b2[0][17]}},p5_b2[0]}) >>> 1)
                +  $signed({{6{p5_b3[0][15]}},p5_b3[0]});
        y1_comb = ($signed({{3{p5_b0[1][18]}},p5_b0[1]}) >>> 2)
                + ($signed({{4{p5_b1[1][17]}},p5_b1[1]}) >>> 1)
                + ($signed({{4{p5_b2[1][17]}},p5_b2[1]}) >>> 1)
                +  $signed({{6{p5_b3[1][15]}},p5_b3[1]});
        y2_comb = ($signed({{3{p5_b0[2][18]}},p5_b0[2]}) >>> 2)
                + ($signed({{4{p5_b1[2][17]}},p5_b1[2]}) >>> 1)
                + ($signed({{4{p5_b2[2][17]}},p5_b2[2]}) >>> 1)
                +  $signed({{6{p5_b3[2][15]}},p5_b3[2]});
        y3_comb = ($signed({{3{p5_b0[3][18]}},p5_b0[3]}) >>> 2)
                + ($signed({{4{p5_b1[3][17]}},p5_b1[3]}) >>> 1)
                + ($signed({{4{p5_b2[3][17]}},p5_b2[3]}) >>> 1)
                +  $signed({{6{p5_b3[3][15]}},p5_b3[3]});

        fc48_wide = $signed({p5_fc_grp4[0][15],p5_fc_grp4[0]})
                    + $signed({p5_fc_grp4[1][15],p5_fc_grp4[1]})
                    + $signed({p5_fc_grp4[2][15],p5_fc_grp4[2]})
                    + $signed({p5_fc_grp4[3][15],p5_fc_grp4[3]});
        fc48_comb = fc48_wide[15:0];
    end

    always_ff @(posedge clk) begin
        if(!rst_n) begin
            rsp_valid<=1'b0; rsp_is_fc<=1'b0; rsp_tag<=16'd0;
            conv_y00<=20'sd0; conv_y01<=20'sd0;
            conv_y10<=20'sd0; conv_y11<=20'sd0;
            fc_sum<=16'sd0;
        end else begin
            rsp_valid<=p5_valid;
            if(p5_valid) begin
                rsp_is_fc<=p5_is_fc; rsp_tag<=p5_tag;
                if(p5_is_fc)
                    fc_sum <= fc48_comb;
                else begin
                    conv_y00 <= y0_comb[19:0];
                    conv_y01 <= y1_comb[19:0];
                    conv_y10 <= y2_comb[19:0];
                    conv_y11 <= y3_comb[19:0];
                end
            end
        end
    end
endmodule
```

## v25_dash/tests/test_integer.py

```python
"""Meaningful numerical-contract checks, including independent dense-vs-transform arithmetic."""
import copy
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np
import torch
from v25.model import V25DASH
from v25.coding import quantize,single_terms,shift_products
from v25.transforms import BM,GM,inverse
from v25.integer import rne,infer,infer_spatial,export,load,validate,range_report
from v25.hardware import generate_engine
from v25.train import crosscheck
from v25.spec import LANE_BW8

class IntegerContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2);torch.manual_seed(2026)
        cls.x=np.random.default_rng(91).integers(0,256,(16,28,28),dtype=np.uint8)
        cls.x[0]=0;cls.x[1]=255;cls.models={}
        for mode in ('int8','v25h'):
            m=V25DASH(mode);m.calibrate(torch.from_numpy(cls.x.copy()).float()[:,None]/256)
            cls.models[mode]=m

    def test_49_transform_matches_independent_spatial_5x5(self):
        rng=np.random.default_rng(2026)
        for _ in range(128):
            x=rng.integers(0,256,(6,6),dtype=np.int64);w=rng.integers(-128,128,(5,5),dtype=np.int64)
            actual=inverse((BM@x.ravel())*(GM@w.ravel()))
            expected=[np.sum(x[r:r+5,c:c+5]*w) for r in range(2) for c in range(2)]
            np.testing.assert_array_equal(actual,expected)

    def test_frozen_v25_source_transform_parity(self):
        path=Path(__file__).resolve().parents[1]/'source_v25h/explore_v25.py'
        spec=importlib.util.spec_from_file_location('frozen_v25',path)
        source=importlib.util.module_from_spec(spec);sys.modules[spec.name]=source;spec.loader.exec_module(source)
        np.testing.assert_array_equal(BM,source.B_MAT)
        np.testing.assert_array_equal(GM,source.G_MAT)
        np.testing.assert_array_equal(LANE_BW8,source.LANE_BW_BASE)
        # Compare arbitrary coded products, including negative non-divisible inverse sums.
        p=np.random.default_rng(71).integers(-100000,100000,(128,49),dtype=np.int64)
        np.testing.assert_array_equal(inverse(p),source.inverse_pfdw(p))

    def test_rne_negative_and_positive_ties(self):
        x=np.arange(-255,256,dtype=np.int64)
        for s in range(9):np.testing.assert_array_equal(rne(x,s),np.rint(x/2**s))

    def test_full_network_qat_integer_backend_equivalence(self):
        for m in self.models.values():crosscheck(m,self.x,'cpu')

    def test_coded_coefficients_and_shift_terms(self):
        for bits in (5,6,9):
            x=np.arange(-(1<<(bits-1)),1<<(bits-1))
            for scheme in ('pot1','sp2'):
                q,t=quantize(x,bits,scheme);single_terms(t)
                np.testing.assert_array_equal(t.sum(-1),q)
                if scheme=='pot1':single_terms(q)
                np.testing.assert_array_equal(shift_products(np.full_like(t,255),t).sum(-1),255*q)
        # A direct spatial convolution ceases to be the correct golden once G coefficients are coded.
        with self.assertRaises(ValueError):infer_spatial(self.x,self.models['v25h'].export_integer())

    def test_export_roundtrip_and_contract_rejections(self):
        for mode,m in self.models.items():
            p=m.export_integer();self.assertEqual(range_report(p)['status'],'PASS_FULL_U8_INTERVAL_BOUNDS')
            with tempfile.TemporaryDirectory() as td:
                export(p,td);q=load(Path(td)/'weights_int.npz')
                for key in p:np.testing.assert_array_equal(p[key],q[key])
            bad=copy.deepcopy(p)
            if mode=='v25h':bad['q1_td'][0,0,0]=3
            else:bad['q1_td'][0,0,0]+=3
            with self.assertRaises(ValueError):validate(bad)
            bad=copy.deepcopy(p);bad['bfc'][0]=(1<<31)-1
            with self.assertRaises(OverflowError):range_report(bad)
            if mode=='v25h':
                rtl,_=generate_engine(p,'shift')
                # The generated coefficient datapath contains no generic multiply.
                self.assertNotRegex(rtl,r'p3_\d+\s*<=.*\*')

    def test_training_gradients_through_transformed_coding(self):
        m=self.models['v25h'];m.zero_grad(set_to_none=True)
        y=torch.tensor(np.arange(len(self.x))%4,dtype=torch.long)
        loss=torch.nn.functional.cross_entropy(m(torch.from_numpy(self.x.copy()).float()[:,None]/256),y)
        loss.backward()
        for p in m.parameters():self.assertIsNotNone(p.grad);self.assertTrue(torch.isfinite(p.grad).all())

if __name__=='__main__':unittest.main()
```

## v25_dash/v25/__init__.py

```python
"""V25-H structure and coefficient coding adapted to four-grade DASH patches."""
```

## v25_dash/v25/coding.py

```python
"""Deterministic zero/signed-PoT and two-term SP2 codebooks."""
from functools import lru_cache
import numpy as np

@lru_cache(maxsize=32)
def table(bits, scheme):
    if not 2 <= int(bits) <= 16 or scheme not in ('pot1','sp2'):
        raise ValueError('supported signed coefficient codebook required')
    powers = [1 << e for e in range(bits)]
    entries = {0: ()}
    for p in powers:
        entries[p]=(p,); entries[-p]=(-p,)
    if scheme == 'sp2':
        for i,p in enumerate(powers):
            for q in powers[:i]:
                for a in (-p,p):
                    for b in (-q,q):
                        v=a+b
                        if v not in entries or len(entries[v])>2: entries[v]=(a,b)
    lo,hi=-(1<<(bits-1)),(1<<(bits-1))-1
    # First minimum implements the V25 per-lane tie rule: fewer terms, smaller magnitude.
    keys=sorted((v for v in entries if lo<=v<=hi),key=lambda v:(len(entries[v]),abs(v),v))
    terms=np.zeros((len(keys),2),np.int64)
    for i,v in enumerate(keys):terms[i,:len(entries[v])]=entries[v]
    return np.array(keys,np.int64),terms

def quantize(values,bits,scheme):
    x=np.asarray(values,np.int64); out=np.empty_like(x); terms=np.zeros(x.shape+(2,),np.int64)
    if np.ndim(bits)==0:
        vs,ts=table(int(bits),scheme); ix=np.abs(x[...,None]-vs).argmin(-1)
        return vs[ix],ts[ix]
    bs=np.asarray(bits,np.int64)
    if bs.shape!=(x.shape[-1],):raise ValueError('one bit width per lane')
    for lane,b in enumerate(bs):
        vs,ts=table(int(b),scheme); ix=np.abs(x[...,lane,None]-vs).argmin(-1)
        out[...,lane]=vs[ix];terms[...,lane,:]=ts[ix]
    return out,terms

def single_terms(coefficients):
    x=np.asarray(coefficients,np.int64)
    a=np.abs(x)
    if np.any((a!=0)&((a&(a-1))!=0)):raise ValueError('non-PoT coefficient')
    return x

def shift_products(x, coefficient):
    c=single_terms(coefficient);a=np.abs(c)
    exps=np.zeros_like(c)
    for v in np.unique(a):
        if v:exps[a==v]=int(v).bit_length()-1
    shifted=np.left_shift(np.asarray(x,np.int64),exps)
    return np.where(c>0,shifted,np.where(c<0,-shifted,0))
```

## v25_dash/v25/flow.py

```python
"""Prepare comparable ORFS/ASAP7 and Vivado inputs, without inventing PPA measurements."""
import json
from pathlib import Path
from .integer import load
from .hardware import generate
from .util import sha256,write_json

def prepare(args):
    out=Path(args.out).resolve();period=float(args.period_ns)
    if period<=0 or period!=period or period==float('inf'):raise ValueError('positive finite period required')
    if any(c.isspace() for c in str(out)):raise ValueError('flow path must not contain whitespace')
    for stage,backend,label in (('int8','mul','before_int8_mul'),('v25h','shift','after_v25h_shift'),('v25h','mul','ablation_v25h_mul')):
        folder=out/'models'/stage;meta=json.loads((folder/'training_report.json').read_text())
        proof=json.loads((out/'verification'/stage/'verification.json').read_text())
        params=load(folder/'integer/weights_int.npz')
        if meta['checkpoint_sha256']!=sha256(folder/'weights.pt'):raise ValueError('checkpoint changed')
        dst=generate(params,out/'flow'/label,backend)
        # Independent coefficient-export integrity is checked in verify-export before PPA preparation.
        actual={f.name:sha256(f) for f in dst.glob('v25_*.sv')}
        if actual!=proof['logs'][backend]['rtl_sha256']:raise ValueError('RTL changed since verified export; rerun verify-export')
        period_ps=period*1000
        sdc=f'''# ASAP7: default period in ps. Confirm with report_units in the installed flow.
create_clock -name core_clk -period {period_ps:g} [get_ports clk]
set_input_delay {period_ps*.2:g} -clock core_clk [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay {period_ps*.2:g} -clock core_clk [all_outputs]
set_clock_uncertainty {period_ps*.05:g} [get_clocks core_clk]
'''
        (dst/'constraint.sdc').write_text(sdc)
        files=' '.join(str(dst/f) for f in ('v25_dash_engine.sv','v25_dash_top.sv'))
        (dst/'config.mk').write_text(f'''export PLATFORM = asap7
export DESIGN_NAME = v25_dash_top
export DESIGN_NICKNAME = {label}
export SYNTH_HDL_FRONTEND = slang
export SYNTH_MEMORY_MAX_BITS = 65536
export VERILOG_FILES = {files}
export SDC_FILE = {dst/'constraint.sdc'}
export ABC_AREA = 1
export CORE_UTILIZATION = 40
export CORE_ASPECT_RATIO = 1
export CORE_MARGIN = 2
export PLACE_DENSITY = 0.65
export TNS_END_PERCENT = 100
''')
        (dst/'vivado.tcl').write_text(f'''# Vivado batch template. Run inside this directory, with the same PART for every design.
if {{$argc != 1}} {{error "Pass exact FPGA PART as -tclargs PART"}}
set part [lindex $argv 0]
read_verilog -sv [list v25_dash_engine.sv v25_dash_top.sv]
synth_design -top v25_dash_top -part $part
create_clock -name core_clk -period {period:g} [get_ports clk]
set_input_delay {period*.2:g} -clock core_clk [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay {period*.2:g} -clock core_clk [all_outputs]
set_clock_uncertainty {period*.05:g} [get_clocks core_clk]
opt_design
place_design
route_design
report_utilization -file utilization.rpt
report_timing_summary -file timing.rpt
report_power -file power_vectorless.rpt
write_checkpoint -force routed.dcp
''')
        write_json(dst/'flow_manifest.json',dict(status='VERIFIED_RTL_FLOW_INPUTS_ONLY',mode=stage,backend=backend,
            integer_sha256=sha256(folder/'integer/weights_int.npz'),rtl_sha256=actual,period_ns=period,
            asap7_default_sdc_unit='ps; confirm installed Liberty units',synthetic_weights=meta['status']=='SYNTHETIC_SMOKE_ONLY',
            ppa_status='NOT_MEASURED',power='vectorless estimate unless matching activity is supplied',
            comparison='before/after includes quantization and coding; candidate MUL vs SHIFT isolates backend with identical weights'))
        print(dst/'config.mk',flush=True)
```

## v25_dash/v25/hardware.py

```python
"""Generate coefficient-specific 49-lane engines and adapt the frozen V25-H streaming controller."""
import json
from pathlib import Path
import re
import numpy as np
from .transforms import BM,A,BLOCKS
from .integer import validate,range_report,bits_for,interval_scale

ROOT=Path(__file__).resolve().parents[1]

def literal(x,bits):return ('-' if x<0 else '')+str(bits)+"'sd"+str(abs(int(x)))

def sx(name,source,target):
    if target==source:return '$signed('+name+')'
    if target<source:return '$signed('+name+'['+str(target-1)+':0])'
    return '$signed({{'+str(target-source)+'{'+name+'['+str(source-1)+']}},'+name+'})'

def total(terms):
    if not terms:return "32'sd0"
    if len(terms)==1:return terms[0]
    mid=len(terms)//2
    return '('+total(terms[:mid])+' + '+total(terms[mid:])+')'

def lookup(p,lane):
    """{fc,conv2,tag[4:0]} distinguishes all coefficient rows."""
    result={o*4:int(p['q1_td'][o,0,lane]) for o in range(2)}
    result.update({32+o*4+i:int(p['q2_td'][o,i,lane]) for o in range(3) for i in range(2)})
    for c in range(4):
        for term in range(p['fc_terms'].shape[-1]):
            result[64+16*term+c]=int(p['fc_terms'][c,lane,term]) if lane<48 else 0
    return result

def add_bounds(bounds):return sum(x[0] for x in bounds),sum(x[1] for x in bounds)

def generate_engine(p,backend='shift'):
    name=validate(p);proof=range_report(p)
    if backend not in ('mul','shift') or backend=='shift' and name!='v25h':raise ValueError('unsupported backend')
    bm=np.array(proof['B_bounds']);cp=np.array(proof['conv_product_bounds'])
    conv_bounds=np.stack((cp[:,:,0].min(0),cp[:,:,1].max(0)),1)
    aw=[];pw=[];bw=[];fc_bounds=[];maps=[]
    for i in range(49):
        m=lookup(p,i);maps.append(m)
        fc=[interval_scale(0,255,c) for k,c in m.items() if k>=64]
        fb=(min(v[0] for v in fc),max(v[1] for v in fc));fc_bounds.append(fb)
        aw.append(bits_for(min(int(bm[i,0]),0),max(int(bm[i,1]),255 if i<48 else 0)))
        bw.append(bits_for(min(m.values()),max(m.values())))
        pw.append(bits_for(min(int(conv_bounds[i,0]),fb[0]),max(int(conv_bounds[i,1]),fb[1])))
    h=[];v=[];offset=0
    for bi,(_,_,kr,kc) in enumerate(BLOCKS):
        for r in range(kr+1):
            for col in range(2):
                ids=[offset+r*(kc+1)+j for j,c in enumerate(A[kc][col]) if c]
                coeff=[int(c) for c in A[kc][col] if c]
                bounds=add_bounds([interval_scale(*map(int,conv_bounds[k]),c) for k,c in zip(ids,coeff)])
                h.append(dict(name=f'h_{bi}_{r}_{col}',ids=ids,coeff=coeff,bounds=bounds,width=bits_for(*bounds)))
        for row in range(2):
            for col in range(2):
                items=[z for z in h if z['name'].startswith(f'h_{bi}_') and int(z['name'].split('_')[-1])==col]
                selected=[(items[j],int(c)) for j,c in enumerate(A[kr][row]) if c]
                bounds=add_bounds([interval_scale(*z['bounds'],c) for z,c in selected])
                v.append(dict(name=f'z_{bi}_{row*2+col}',items=selected,bounds=bounds,width=bits_for(*bounds)))
        offset+=(kr+1)*(kc+1)
    f4=[add_bounds(fc_bounds[i:i+3]) for i in range(0,48,3)]
    f5=[add_bounds(f4[i:i+4]) for i in range(0,16,4)]
    f4w=[bits_for(*x) for x in f4];f5w=[bits_for(*x) for x in f5]
    s=['`timescale 1ps/1ps', '// V25-derived 49-lane coefficient-specific shared pipeline; generated for DASH.',
       f'// mode={name}, backend={backend}; P0 request -> P6 response, II=1.',
       'module v25_dash_engine(input logic clk,rst_n,req_valid,req_is_fc, input logic [15:0] req_tag,',
       'input wire signed [8:0] conv_tile[0:5][0:5], input wire signed [8:0] fc_a[0:47],',
       'output logic rsp_valid,rsp_is_fc, output logic [15:0] rsp_tag,',
       'output logic signed [31:0] conv_y00,conv_y01,conv_y10,conv_y11,fc_sum);',
       'logic [6:0] valid_pipe,mode_pipe; logic [15:0] tag_pipe[0:6]; integer k;',
       'always @(posedge clk) begin if(!rst_n)begin valid_pipe<=0;mode_pipe<=0;for(k=0;k<7;k=k+1)tag_pipe[k]<=0;end',
       'else begin valid_pipe<={valid_pipe[5:0],req_valid};mode_pipe<={mode_pipe[5:0],req_is_fc};',
       'tag_pipe[0]<=req_tag;for(k=1;k<7;k=k+1)tag_pipe[k]<=tag_pipe[k-1];end end',
       'assign rsp_valid=valid_pipe[6];assign rsp_is_fc=mode_pipe[6];assign rsp_tag=tag_pipe[6];',
       'logic [7:0] x0[0:35],f0[0:47],f1[0:47];integer r,c;',
       'always @(posedge clk)begin if(!rst_n)begin for(r=0;r<36;r=r+1)x0[r]<=0;',
       'for(r=0;r<48;r=r+1)begin f0[r]<=0;f1[r]<=0;end end else begin',
       'if(req_valid)begin if(req_is_fc)begin for(r=0;r<48;r=r+1)f0[r]<=fc_a[r][7:0];end',
       'else begin for(r=0;r<6;r=r+1)for(c=0;c<6;c=c+1)x0[r*6+c]<=conv_tile[r][c][7:0];end end',
       'if(valid_pipe[0]&&mode_pipe[0])for(r=0;r<48;r=r+1)f1[r]<=f0[r];end end',
       "wire [6:0] key1={mode_pipe[1],tag_pipe[1][15],(mode_pipe[1]?tag_pipe[1][4]:1'b0),tag_pipe[1][3:0]};",
       "wire [6:0] key2={mode_pipe[2],tag_pipe[2][15],(mode_pipe[2]?tag_pipe[2][4]:1'b0),tag_pipe[2][3:0]};"]
    for lane in range(49):
        wa,wp,wc=aw[lane],pw[lane],bw[lane]
        s += [f'logic signed [{wa-1}:0] b1_{lane},a2_{lane};logic signed [{wp-1}:0] p3_{lane};']
        bterms=[]
        for j,coef in enumerate(BM[lane]):
            if coef:
                expr=sx(f"{{1'b0,x0[{j}]}}",9,wa) if wa!=9 else f"$signed({{1'b0,x0[{j}]}})"
                # Concatenations cannot be sliced/sign-extended by name; use a full-width unsigned cast.
                expr=f'$signed({{{wa-8}\'d0,x0[{j}]}})'
                bterms.append(('-'+expr) if coef<0 else expr)
        reset_product=f'p3_{lane}<=0;' if backend=='shift' else ''
        s += [f'always @(posedge clk)begin if(!rst_n)begin b1_{lane}<=0;a2_{lane}<=0;{reset_product}end else begin',
              f'if(valid_pipe[0]&&!mode_pipe[0])b1_{lane}<={total(bterms)};',
              f"if(valid_pipe[1])a2_{lane}<=mode_pipe[1]?"+(f"$signed({{{wa-8}'d0,f1[{lane}]}})" if lane<48 else "0")+f':b1_{lane};']
        if backend=='mul':
            s += ['end end',f'logic signed [{wc-1}:0] coefficient2_{lane};',
                  f'always @(posedge clk)begin if(!rst_n)coefficient2_{lane}<=0;else if(valid_pipe[1])begin case(key1)']
            s += [f"7'd{key}:coefficient2_{lane}<={literal(co,wc)};" for key,co in maps[lane].items() if co]
            s += [f"default:coefficient2_{lane}<={wc}'sd0;endcase end end",
                  f'always @(posedge clk)begin if(!rst_n)p3_{lane}<=0;else if(valid_pipe[2])p3_{lane}<={sx(f"a2_{lane}",wa,wp)}*{sx(f"coefficient2_{lane}",wc,wp)};end']
        else:
            s += ['if(valid_pipe[2])begin case(key2)']
            grouped={}
            for key,co in maps[lane].items():
                if co:grouped.setdefault(co,[]).append(key)
            for co,keys in grouped.items():
                if abs(co)&(abs(co)-1):raise ValueError('shift engine requires one PoT per temporal request')
                exp=abs(co).bit_length()-1
                expr='('+sx(f'a2_{lane}',wa,wp)+f' <<< {exp})'
                if co<0:expr='-'+expr
                s += [','.join("7'd"+str(k) for k in keys)+f':p3_{lane}<={expr};']
            s += [f"default:p3_{lane}<={wp}'sd0;endcase end end end"]
    for z in h:s.append(f'logic signed [{z["width"]-1}:0] {z["name"]};')
    for z in v:s.append(f'logic signed [{z["width"]-1}:0] {z["name"]};')
    for i,w in enumerate(f4w):s.append(f'logic signed [{w-1}:0] fg4_{i};')
    for i,w in enumerate(f5w):s.append(f'logic signed [{w-1}:0] fg5_{i};')
    s += ['always @(posedge clk)begin if(!rst_n)begin']
    s += [f'{z["name"]}<=0;' for z in h]
    s += [f'fg4_{i}<=0;' for i in range(16)]
    s += ['end else if(valid_pipe[3])begin if(!mode_pipe[3])begin']
    for z in h:
        terms=[('-' if co<0 else '')+sx(f'p3_{i}',pw[i],z['width']) for i,co in zip(z['ids'],z['coeff'])]
        s.append(z['name']+'<='+total(terms)+';')
    s += ['end else begin']
    for i,w in enumerate(f4w):s.append(f'fg4_{i}<='+total([sx(f'p3_{j}',pw[j],w) for j in range(i*3,i*3+3)])+';')
    s += ['end end end','always @(posedge clk)begin if(!rst_n)begin']
    s += [f'{z["name"]}<=0;' for z in v]
    s += [f'fg5_{i}<=0;' for i in range(4)]
    s += ['end else if(valid_pipe[4])begin if(!mode_pipe[4])begin']
    for z in v:
        terms=[('-' if co<0 else '')+sx(a['name'],a['width'],z['width']) for a,co in z['items']]
        s.append(z['name']+'<='+total(terms)+';')
    s += ['end else begin']
    for i,w in enumerate(f5w):s.append(f'fg5_{i}<='+total([sx(f'fg4_{j}',f4w[j],w) for j in range(i*4,i*4+4)])+';')
    s += ['end end end','always @(posedge clk)begin if(!rst_n)begin conv_y00<=0;conv_y01<=0;conv_y10<=0;conv_y11<=0;fc_sum<=0;end',
          'else if(valid_pipe[5])begin if(!mode_pipe[5])begin']
    for j,out in enumerate(('conv_y00','conv_y01','conv_y10','conv_y11')):
        terms=[]
        for bi,shift in enumerate((2,1,1,0)):
            z=next(z for z in v if z['name']==f'z_{bi}_{j}')
            terms.append('('+sx(z['name'],z['width'],32)+f' >>> {shift})')
        s.append(out+'<='+total(terms)+';')
    s += ['end else begin fc_sum<='+total([sx(f'fg5_{i}',f5w[i],32) for i in range(4)])+';end end end','endmodule']
    widths=dict(B_bits=aw,product_bits=pw,coefficient_bits=bw,
                horizontal_bits={z['name']:z['width'] for z in h},vertical_bits={z['name']:z['width'] for z in v},
                fc_group4_bits=f4w,fc_group5_bits=f5w,proof_scope='all independent input bytes 0..255')
    return '\n'.join(s)+'\n',widths

def generate_top(p):
    name=validate(p);source=(ROOT/'source_v25h/chip_pfdw_fc_v25h.sv').read_text()
    body=source[source.index('    localparam ST_STREAM'):source.rindex('endmodule')]
    start=body.index('    // Layer-specific scale restoration')
    end=body.index('    function automatic [2:0] add_mod7',start)
    helper=['    localparam integer C1_RESTORE_SHIFT=0,C2_RESTORE_SHIFT=0;',
            '    localparam integer FC_TWO_PASS='+str(int(name=='v25h'))+';']
    for fname,key in (('get_b1','b1'),('get_b2','b2'),('get_fcb','bfc')):
        helper += [f'function automatic signed [31:0] {fname}(input integer idx);begin case(idx)']
        helper += [f'{i}:{fname}={literal(int(x),32)};' for i,x in enumerate(p[key])]
        helper += [f'default:{fname}=0;endcase end endfunction']
    helper += ['function automatic [7:0] quant_u8(input signed [31:0] raw,input integer shift);',
               'reg signed [63:0] base,rem,half;begin base=$signed(raw)>>>shift;',
               'if(shift>0)begin rem=$signed(raw)-(base<<<shift);half=64\'sd1<<<(shift-1);',
               'if(rem>half||(rem==half&&base[0]))base=base+1;end',
               'if(base<0)quant_u8=0;else if(base>255)quant_u8=255;else quant_u8=base[7:0];end endfunction',
               f'function automatic signed [11:0] conv1_q(input signed [31:0] raw,bias32);begin conv1_q={{4\'d0,quant_u8(raw+bias32,{int(p["s1"])})}};end endfunction',
               f'function automatic signed [11:0] conv2_q(input signed [31:0] raw,bias32);begin conv2_q={{4\'d0,quant_u8(raw+bias32,{int(p["s2"])})}};end endfunction',
               'function automatic [7:0] max4_relu_a8(input signed [11:0] a,b,c,d);reg signed [11:0] m;begin',
               'm=a;if(b>m)m=b;if(c>m)m=c;if(d>m)m=d;max4_relu_a8=m[7:0];end endfunction',
               'logic signed [31:0] scores[0:3];integer score_clear;',
               'assign logits={scores[3],scores[2],scores[1],scores[0]};\n']
    body=body[:start]+'\n'.join(helper)+body[end:]
    body=body.replace('signed [19:0]','signed [31:0]').replace('signed [15:0] fc_term0_sum','signed [31:0] fc_term0_sum')
    body=body.replace('signed [15:0] rsp_fc_sum','signed [31:0] rsp_fc_sum')
    body=body.replace('signed [11:0] best_score','signed [31:0] best_score').replace('signed [11:0] fc_score_now','signed [31:0] fc_score_now')
    body=body.replace('signed [16:0] fc_class_sum','signed [31:0] fc_class_sum')
    body=body.replace('pfdw_pipe49_shift_engine_v25h u_engine','v25_dash_engine u_engine')
    for suffix in ('00','01','10','11'):body=body.replace(f'rsp_y{suffix}[19:0]',f'rsp_y{suffix}[31:0]')
    body=body.replace("fc_issue_count < 5'd20", "fc_issue_count < 5'd"+str(8 if name=='v25h' else 4))
    start=body.index('        // Exact reduced FC score datapath')
    end=body.index('\n    end\n\n    // ----',start)
    body=body[:start]+'        fc_class_sum = (FC_TWO_PASS ? fc_term0_sum : 32\'sd0) + rsp_fc_sum;\n        fc_score_now = fc_class_sum + get_fcb(rsp_fc_class);'+body[end:]
    body=body.replace("best_score <= -12'sd2048;","best_score <= 32'sh80000000;")
    body=body.replace("fc_term0_sum <= 16'sd0;","fc_term0_sum <= 32'sd0;")
    body=body.replace('            decision <= 0;','            for(score_clear=0;score_clear<4;score_clear=score_clear+1)scores[score_clear]<=0;\n            decision <= 0;')
    start=body.index('            if (req_valid && req_is_fc && state == ST_FC)')
    end=body.index('            // Conv1 response',start)
    progress='''            if(req_valid && req_is_fc && state==ST_FC)begin
                fc_issue_count<=fc_issue_count+1'b1;
                if(FC_TWO_PASS && !fc_issue_term)fc_issue_term<=1'b1;
                else begin fc_issue_term<=0;if(fc_issue_class<3)fc_issue_class<=fc_issue_class+1'b1;end
            end

'''
    body=body[:start]+progress+body[end:]
    body=body.replace("if (rsp_fc_term == 1'b0) begin", "if (FC_TWO_PASS && rsp_fc_term == 1'b0) begin")
    marker='                end else begin\n                    if (rsp_fc_class == 0) begin'
    if marker not in body:raise ValueError('frozen V25 controller FC pattern changed')
    body=body.replace(marker,'                end else begin\n                    scores[rsp_fc_class] <= fc_score_now;\n                    if (rsp_fc_class == 0) begin')
    body=body.replace('if (rsp_fc_class == 9)','if (rsp_fc_class == 3)').replace("decision <= 4'd9;","decision <= 2'd3;")
    header='''`timescale 1ps/1ps
// Derived from V25-H controller, commit 0d345f1. Continuous byte stream; one prime cycle after reset.
// DASH adaptation: four classes, train-derived scales, signed32 bias/score, RNE+U8 saturation.
module v25_dash_top(input logic clk,rst_n,input logic [7:0] data_in,
                   output logic [1:0] decision,output logic valid_out_6,output wire [127:0] logits);
'''
    return header+body+'endmodule\n'

def generate(p,out,backend='shift'):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    engine,widths=generate_engine(p,backend)
    (out/'v25_dash_engine.sv').write_text(engine)
    (out/'v25_dash_top.sv').write_text(generate_top(p))
    (out/'widths.json').write_text(json.dumps(widths,indent=2)+'\n')
    return out
```

## v25_dash/v25/integer.py

```python
"""Exact inference for the exported 2/3-channel model, with floor inverse and RNE activations."""
import json
from pathlib import Path
import numpy as np
from .spec import SHAPES,MODES,LANE_BW8,SOURCE_COMMIT
from .transforms import BM,GM,INVERSE,DIVISIONS,tiles,inverse,direct_conv
from .coding import quantize,shift_products,single_terms

def i32(x):
    x=np.asarray(x,np.int64)
    if x.size and (x.min()<-(1<<31) or x.max()>=(1<<31)):
        raise OverflowError('signed32 arithmetic contract exceeded')
    return x

def rne(x,shift):
    x=np.asarray(x,np.int64);s=int(shift)
    if not 0<=s<=31:raise ValueError('shift must be 0..31')
    if s==0:return x.copy()
    base=x>>s;rem=x-(base<<s);half=1<<(s-1)
    return base+((rem>half)|((rem==half)&((base&1)!=0)))

def mode(p):return str(np.asarray(p['mode']).item())

def validate(p):
    name=mode(p)
    if name not in MODES:raise ValueError('unknown exported mode')
    for k,shape in SHAPES.items():
        a=np.asarray(p[k])
        if a.shape!=shape or not np.issubdtype(a.dtype,np.integer):raise ValueError(k+' shape/type')
    for k in ('s1','s2'):
        a=np.asarray(p[k])
        if a.ndim or not np.issubdtype(a.dtype,np.integer) or not 0<=int(a)<=31:raise ValueError(k+' shift')
    for k,b in zip(('q1_sp','q2_sp','qfc'),MODES[name]['weight_bits']):
        if np.min(p[k])<-(1<<(b-1)) or np.max(p[k])>=(1<<(b-1)):raise ValueError(k+' coefficient range')
    if name=='int8':
        for sp,td in (('q1_sp','q1_td'),('q2_sp','q2_td')):
            expected=p[sp].reshape(p[sp].shape[:2]+(25,))@GM.T
            if not np.array_equal(expected,p[td]):raise ValueError('int8 G-transform mismatch')
        if p['fc_terms'].shape!=(4,48,1) or not np.array_equal(p['fc_terms'][...,0],p['qfc']):raise ValueError('int8 FC terms')
    else:
        for td,bits in (('q1_td',5),('q2_td',6)):
            q,_=quantize(p[td],np.array(LANE_BW8)-(8-bits),'pot1')
            if not np.array_equal(q,p[td]):raise ValueError('invalid transformed PoT codes')
        terms=np.asarray(p['fc_terms'])
        if terms.shape!=(4,48,2) or not np.issubdtype(terms.dtype,np.integer):raise ValueError('SP2 term shape/type')
        single_terms(terms)
        if not np.array_equal(terms.sum(-1),p['qfc']):raise ValueError('SP2 reconstruction mismatch')
        q,_=quantize(p['qfc'],6,'sp2')
        if not np.array_equal(q,p['qfc']):raise ValueError('invalid SP2 codes')
    for k in ('b1','b2','bfc'):i32(p[k])
    return name

def transformed_conv(x,q,method='mul'):
    bt=tiles(x);n,ic,h,w,_=bt.shape;oc=q.shape[0]
    out=np.zeros((n,oc,h,w,4),np.int64)
    for o in range(oc):
        for i in range(ic):
            if method=='mul':p=bt[:,i]*q[o,i]
            elif method=='shift':p=shift_products(bt[:,i],q[o,i])
            else:raise ValueError('mul or shift arithmetic required')
            out[:,o]+=inverse(p)
    return i32(out)

def pool_codes(raw,b,shift):
    raw=i32(raw+np.asarray(b)[None,:,None,None,None])
    return np.clip(rne(raw,shift),0,255).max(-1).astype(np.int64)

def infer(x,p,method='mul',check=True):
    name=validate(p) if check else mode(p)
    x=np.asarray(x)
    single=x.ndim==2
    if single:x=x[None]
    if x.ndim!=3 or x.shape[1:]!=(28,28) or not np.issubdtype(x.dtype,np.integer) or x.min()<0 or x.max()>255:
        raise ValueError('N,28,28 unsigned-byte input required')
    if method=='shift' and name!='v25h':raise ValueError('int8 coefficients need multiplier backend')
    p1=pool_codes(transformed_conv(x[:,None],p['q1_td'],method),p['b1'],p['s1'])
    p2=pool_codes(transformed_conv(p1,p['q2_td'],method),p['b2'],p['s2'])
    flat=p2.reshape(len(x),48)
    if method=='mul':scores=flat@p['qfc'].T
    else:
        scores=np.zeros((len(x),4),np.int64)
        for cls in range(4):
            for term in range(2):scores[:,cls]+=shift_products(flat,p['fc_terms'][cls,:,term]).sum(-1)
    scores=i32(scores+p['bfc']);decisions=scores.argmax(1)
    result=dict(pool1=p1,pool2=p2,scores=scores,decision=decisions)
    return {k:v[0] for k,v in result.items()} if single else result

def infer_spatial(x,p):
    if validate(p)!='int8':raise ValueError('spatial equivalence only applies before transformed coding')
    x=np.asarray(x,np.int64);single=x.ndim==2
    if single:x=x[None]
    def pool(y,b,s):
        y=np.clip(rne(i32(y+b[None,:,None,None]),s),0,255)
        n,c,h,w=y.shape
        return y.reshape(n,c,h//2,2,w//2,2).max((3,5))
    p1=pool(direct_conv(x[:,None],p['q1_sp']),p['b1'],p['s1'])
    p2=pool(direct_conv(p1,p['q2_sp']),p['b2'],p['s2'])
    scores=i32(p2.reshape(len(x),48)@p['qfc'].T+p['bfc'])
    result=dict(pool1=p1,pool2=p2,scores=scores,decision=scores.argmax(1))
    return {k:v[0] for k,v in result.items()} if single else result

def bits_for(lo,hi):
    for b in range(1,64):
        if lo>=-(1<<(b-1)) and hi<(1<<(b-1)):return b
    raise OverflowError('range beyond int64')

def interval_scale(lo,hi,c):
    return min(lo*c,hi*c),max(lo*c,hi*c)

def range_report(p):
    """Conservative full-U8 proofs, not bounds observed on the training samples."""
    name=validate(p)
    bmin=(np.minimum(BM,0)*255).sum(1);bmax=(np.maximum(BM,0)*255).sum(1)
    conv=np.concatenate((p['q1_td'].reshape(2,49),p['q2_td'].reshape(6,49)))
    bounds=[]; layer_bounds=[]
    for co in conv:
        products=np.array([interval_scale(int(lo),int(hi),int(c)) for lo,hi,c in zip(bmin,bmax,co)])
        bounds.append(products)
        ylo=np.zeros(4,np.int64);yhi=np.zeros(4,np.int64)
        for mat,div in zip(INVERSE,DIVISIONS):
            lo=np.minimum(mat,0)@products[:,1]+np.maximum(mat,0)@products[:,0]
            hi=np.minimum(mat,0)@products[:,0]+np.maximum(mat,0)@products[:,1]
            ylo+=lo//div;yhi+=hi//div
        layer_bounds.append((ylo,yhi))
    for o in range(2):
        lo,hi=layer_bounds[o];i32(lo+p['b1'][o]);i32(hi+p['b1'][o])
    for o in range(3):
        lo=sum(layer_bounds[2+2*o+i][0] for i in range(2))
        hi=sum(layer_bounds[2+2*o+i][1] for i in range(2))
        i32(lo+p['b2'][o]);i32(hi+p['b2'][o])
    flo=(np.minimum(p['qfc'],0)*255).sum(1)+p['bfc']
    fhi=(np.maximum(p['qfc'],0)*255).sum(1)+p['bfc'];i32(flo);i32(fhi)
    for t in range(p['fc_terms'].shape[-1]):
        i32((np.minimum(p['fc_terms'][...,t],0)*255).sum(1))
        i32((np.maximum(p['fc_terms'][...,t],0)*255).sum(1))
    return dict(status='PASS_FULL_U8_INTERVAL_BOUNDS',activation_code_range=[0,255],
                conv_coefficients=conv.tolist(),conv_product_bounds=np.asarray(bounds).tolist(),
                B_bounds=np.stack((bmin,bmax),-1).tolist(),
                fc_score_bounds=np.stack((flo,fhi),-1).tolist(),
                note='Recomputed for these DASH coefficients; legacy V25-H lane widths are not reused.')

def load(path):
    with np.load(path,allow_pickle=False) as f:return {k:f[k] for k in f.files}

def export(p,directory,provenance=None):
    d=Path(directory);d.mkdir(parents=True,exist_ok=True);name=validate(p);proof=range_report(p)
    np.savez_compressed(d/'weights_int.npz',**p)
    for key in ('q1_td','q2_td','qfc','b1','b2','bfc'):
        np.savetxt(d/(key+'.csv'),p[key].reshape(-1,p[key].shape[-1]) if p[key].ndim>1 else p[key][None],fmt='%d',delimiter=',')
    manifest=dict(mode=name,channels=[1,2,3],fc=[48,4],classes=4,
                  class_names=['excellent','great','good','poor'],weight_bits=list(MODES[name]['weight_bits']),
                  activation_bits=[8,8],coding=dict(conv=MODES[name]['conv_coding'],fc=MODES[name]['fc_coding']),
                  s1=int(p['s1']),s2=int(p['s2']),rounding='nearest_even',activation='ReLU then saturate U8',
                  inverse='floor per 3x3/3x2/2x3/2x2 block, then sum input channels',
                  flatten='CHW',source_commit=SOURCE_COMMIT,
                  adaptation='DASH train-only scales, 32-bit bias/score; not legacy MNIST wrap/slice arithmetic',
                  provenance=provenance or {})
    (d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (d/'range_proof.json').write_text(json.dumps(proof,indent=2)+'\n')
```

## v25_dash/v25/model.py

```python
"""V25-H 1->2->3 / FC48->4, with genuine transformed-domain PoT QAT."""
import math
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from .spec import MODES,LANE_BW8
from .transforms import BM,GM,INVERSE,DIVISIONS
from .coding import table,quantize

def ste(x,value):return x+(value-x).detach()
def round_ste(x):return ste(x,torch.round(x))
def floor_ste(x):return ste(x,torch.floor(x))

def power_fake(x,bits,scheme):
    vs,_=table(int(bits),scheme)
    v=torch.tensor(vs,device=x.device,dtype=x.dtype)
    chosen=v[(x.detach()[...,None]-v).abs().argmin(-1)]
    return ste(x,chosen)

class V25DASH(nn.Module):
    def __init__(self,mode='fp32'):
        super().__init__()
        if mode not in ('fp32','int8','v25h'):raise ValueError('unknown mode')
        self.mode=mode;self.quant=None
        self.w1=nn.Parameter(torch.empty(2,1,5,5));self.b1=nn.Parameter(torch.zeros(2))
        self.w2=nn.Parameter(torch.empty(3,2,5,5));self.b2=nn.Parameter(torch.zeros(3))
        self.wfc=nn.Parameter(torch.empty(4,48));self.bfc=nn.Parameter(torch.zeros(4))
        for w in (self.w1,self.w2,self.wfc):nn.init.kaiming_uniform_(w,a=math.sqrt(5))
        self.register_buffer('bm',torch.tensor(BM,dtype=torch.float64))
        self.register_buffer('gm',torch.tensor(GM,dtype=torch.float64))
        for i,a in enumerate(INVERSE):self.register_buffer('im'+str(i),torch.tensor(a,dtype=torch.float64))

    def weight_codes(self):
        if self.quant is None or self.mode=='fp32':raise ValueError('calibrate an integer mode first')
        q=self.quant;cfg=MODES[self.mode];sp=[];td=[]
        for i,w in enumerate((self.w1,self.w2)):
            q8=round_ste(torch.clamp(w.double()/2.**q['ew8'][i],-128,127))
            if cfg['prune'][i]:
                q8=ste(q8,torch.where(q8.abs()<cfg['prune'][i],torch.zeros_like(q8),q8))
            k=floor_ste(q8/2.**(8-cfg['weight_bits'][i]));sp.append(k)
            transformed=k.flatten(2)@self.gm.T
            if self.mode=='v25h':
                bw=np.array(LANE_BW8)-(8-cfg['weight_bits'][i])
                # Group equal-width lanes; avoid a large codebook per tile.
                coded=torch.zeros_like(transformed)
                for b in sorted(set(bw.tolist())):
                    ids=np.flatnonzero(bw==b).tolist()
                    coded[...,ids]=power_fake(transformed[...,ids],b,'pot1')
                transformed=coded
            td.append(transformed)
        f8=round_ste(torch.clamp(self.wfc.double()/2.**q['ew8'][2],-128,127))
        if cfg['prune'][2]:f8=ste(f8,torch.where(f8.abs()<cfg['prune'][2],torch.zeros_like(f8),f8))
        fc=floor_ste(f8/2.**(8-cfg['weight_bits'][2]))
        if self.mode=='v25h':fc=power_fake(fc,6,'sp2')
        return sp,td,fc

    def _raw(self,x,sp,td):
        # Integer values are carried in float64 so every signed32 sum is exact.
        if self.mode=='int8':
            y=F.conv2d(x,sp)
            n,c,h,w=y.shape
            return y.reshape(n,c,h//2,2,w//2,2).permute(0,1,2,4,3,5).reshape(n,c,h//2,w//2,4)
        t=x.unfold(2,6,2).unfold(3,6,2).flatten(-2)
        bt=t@self.bm.T
        products=bt[:,None]*td[None,:,:,None,None,:]
        out=sum(floor_ste((products@getattr(self,'im'+str(i)).T)/div)
                for i,div in enumerate(DIVISIONS))
        return out.sum(2)

    @staticmethod
    def _bias(b,exp):
        return round_ste(torch.clamp(b.double()/2.**exp,-(1<<31),(1<<31)-1))

    def _pool(self,raw,b,raw_exp,activation_exp):
        unit=2.**(activation_exp-raw_exp)
        z=raw+self._bias(b,raw_exp)[None,:,None,None,None]
        return torch.clamp(round_ste(z/unit),0,255).max(-1).values

    def forward(self,x,maps=False):
        if x.ndim!=4 or tuple(x.shape[1:])!=(1,28,28):raise ValueError('N,1,28,28 required')
        if self.mode=='fp32':
            p1=F.max_pool2d(F.relu(F.conv2d(x,self.w1,self.b1)),2)
            p2=F.max_pool2d(F.relu(F.conv2d(p1,self.w2,self.b2)),2)
            scores=F.linear(p2.flatten(1),self.wfc,self.bfc)
        else:
            if self.quant is None:raise ValueError('integer-mode calibration missing')
            q=self.quant;sp,td,fc=self.weight_codes()
            codes=round_ste(x.double()*256)
            p1c=self._pool(self._raw(codes,sp[0],td[0]),self.b1,-8+q['ew1'],q['ea1'])
            p2c=self._pool(self._raw(p1c,sp[1],td[1]),self.b2,q['ea1']+q['ew2'],q['ea2'])
            score_exp=q['ea2']+q['ewfc']
            scores=(p2c.flatten(1)@fc.T+self._bias(self.bfc,score_exp))*2.**score_exp
            p1=p1c*2.**q['ea1'];p2=p2c*2.**q['ea2']
        return (scores,p1,p2) if maps else scores

    @torch.no_grad()
    def calibrate(self,x):
        if self.mode=='fp32':raise ValueError('select int8/v25h before calibration')
        def exponent(value):return math.ceil(math.log2(max(float(value),1e-12)))
        ew8=[exponent(w.abs().max()/127) for w in (self.w1,self.w2,self.wfc)]
        bits=MODES[self.mode]['weight_bits']
        self.quant=dict(ew8=ew8,ew1=ew8[0]+8-bits[0],ew2=ew8[1]+8-bits[1],ewfc=ew8[2]+8-bits[2])
        q=self.quant;sp,td,_=self.weight_codes();codes=x.double()*256
        raw_exp=-8+q['ew1']
        raw=self._raw(codes,sp[0],td[0])+self._bias(self.b1,raw_exp)[None,:,None,None,None]
        q['ea1']=max(exponent(raw.clamp(min=0).max()*2.**raw_exp/255),raw_exp)
        p1=self._pool(self._raw(codes,sp[0],td[0]),self.b1,raw_exp,q['ea1'])
        raw_exp=q['ea1']+q['ew2']
        raw=self._raw(p1,sp[1],td[1])+self._bias(self.b2,raw_exp)[None,:,None,None,None]
        q['ea2']=max(exponent(raw.clamp(min=0).max()*2.**raw_exp/255),raw_exp)
        for s in (q['ea1']+8-q['ew1'],q['ea2']-q['ea1']-q['ew2']):
            if not 0<=s<=31:raise ValueError('calibration requires unsupported shift')
        return q

    @torch.no_grad()
    def export_integer(self):
        from .integer import validate,range_report
        q=self.quant;sp,td,fc=self.weight_codes()
        def arr(x):return torch.round(x).detach().cpu().numpy().astype(np.int64)
        p=dict(mode=np.array(self.mode),q1_sp=arr(sp[0]),q2_sp=arr(sp[1]),
               q1_td=arr(td[0]),q2_td=arr(td[1]),qfc=arr(fc),
               b1=arr(self._bias(self.b1,-8+q['ew1'])),b2=arr(self._bias(self.b2,q['ea1']+q['ew2'])),
               bfc=arr(self._bias(self.bfc,q['ea2']+q['ewfc'])),
               s1=np.array(q['ea1']+8-q['ew1'],np.int64),s2=np.array(q['ea2']-q['ea1']-q['ew2'],np.int64))
        p['fc_terms']=p['qfc'][...,None] if self.mode=='int8' else quantize(p['qfc'],6,'sp2')[1]
        validate(p);range_report(p);return p
```

## v25_dash/v25/spec.py

```python
"""The DASH adaptation contract; legacy MNIST shifts are not copied blindly."""
SOURCE_COMMIT = '0d345f1bb658d5772868c7ef939ac592b7a2bb19'
CLASSES = ('excellent', 'great', 'good', 'poor')
SHAPES = {'q1_sp': (2, 1, 5, 5), 'q2_sp': (3, 2, 5, 5),
          'q1_td': (2, 1, 49), 'q2_td': (3, 2, 49), 'qfc': (4, 48),
          'b1': (2,), 'b2': (3,), 'bfc': (4,)}
MODES = {
    'int8': dict(weight_bits=(8, 8, 8), activation_bits=(8, 8), prune=(0, 0, 0),
                 conv_coding='exact', fc_coding='exact'),
    'v25h': dict(weight_bits=(5, 6, 6), activation_bits=(8, 8), prune=(16, 8, 8),
                  conv_coding='pot1', fc_coding='sp2'),
}
# G coefficient widths inherited from the V25 transformed-domain layout.
LANE_BW8 = tuple(12 if i in {5,6,9,10} else
                 11 if i in {1,2,4,7,8,11,13,14,20,23,33,34} else
                 10 if i in {0,3,12,15,17,19,21,22,24,26,29,30,32,35,37,38,44} else
                 9 if i in {16,18,25,27,28,31,36,39,41,43,45,47} else 8
                 for i in range(49))
```

## v25_dash/v25/train.py

```python
"""Train/validation only. Three frozen stages: FP32 -> dense INT8 -> V25-H coded QAT."""
import copy
import csv
import json
from pathlib import Path
import random
import time
import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader,TensorDataset,WeightedRandomSampler
from dash_cnn.data.audit import load,validate_splits,coverage
from dash_cnn.evaluation.metrics import metrics
from .model import V25DASH
from .integer import infer,infer_spatial,export
from .spec import SOURCE_COMMIT
from .util import write_json,sha256

def seed_all(seed,threads):
    if threads<1:raise ValueError('threads >= 1 required')
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)

def dataset_identity(data_work,splits=('train','validation')):
    return {s:sha256(Path(data_work)/'data'/(s+'.npz')) for s in splits}

def checkpoint(path,device='cpu'):
    c=torch.load(path,map_location='cpu',weights_only=True)
    m=V25DASH(c['mode']);m.load_state_dict(c['state_dict']);m.quant=c['quant'];m.to(device);m.eval()
    return m,c

def save_checkpoint(path,model,epoch,identity):
    torch.save(dict(mode=model.mode,quant=copy.deepcopy(model.quant),epoch=int(epoch),
                    state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()},dataset_identity=identity),path)

def predict_integer(x,p,batch_size=128):
    values=[]
    for start in range(0,len(x),batch_size):
        values.append(infer(x[start:start+batch_size],p,check=False)['decision'])
    return np.concatenate(values)

@torch.no_grad()
def validation(model,d,batch_size,device):
    if model.mode!='fp32':pred=predict_integer(d['x'],model.export_integer(),batch_size)
    else:
        pred=[]
        for start in range(0,len(d['x']),batch_size):
            x=torch.from_numpy(d['x'][start:start+batch_size].copy()).to(device=device,dtype=torch.float32)[:,None]/256
            pred.append(model(x).argmax(1).cpu().numpy())
        pred=np.concatenate(pred)
    return metrics(d['y'],pred,d['video_id'])

@torch.no_grad()
def crosscheck(model,x,device):
    p=model.export_integer();a=infer(x,p)
    s,p1,p2=model(torch.from_numpy(x.copy()).to(device=device,dtype=torch.float32)[:,None]/256,maps=True)
    q=model.quant
    torch_values=dict(pool1=(p1/2.**q['ea1']).cpu().numpy(),pool2=(p2/2.**q['ea2']).cpu().numpy(),
                      scores=(s/2.**(q['ea2']+q['ewfc'])).cpu().numpy(),decision=s.argmax(1).cpu().numpy())
    b=infer(x,p,'shift') if model.mode=='v25h' else infer_spatial(x,p)
    for k in a:
        if not np.array_equal(a[k],torch_values[k]) or not np.array_equal(a[k],b[k]):
            raise AssertionError('QAT/export/backend mismatch: '+k)
    return dict(status='PASS_QAT_INTEGER_BACKENDS',n=len(x),maps=['pool1','pool2','four_scores','decision'])

def representatives(d,count=4):
    ids=[int(np.flatnonzero(d['y']==c)[0]) for c in range(4) if np.any(d['y']==c)]
    ids+= [i for i in range(len(d['y'])) if i not in ids][:max(0,count-len(ids))]
    return d['x'][ids[:count]],d['sample_id'][ids[:count]].astype(str).tolist()

def train(args):
    seed_all(args.seed,args.threads)
    device=torch.device(args.device)
    if device.type=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA unavailable; use --device cpu')
    if args.batch_size<1 or min(args.base_epochs,args.qat_epochs,args.coded_epochs)<1 or args.calibration_samples<1:
        raise ValueError('positive epochs, batch and calibration count required')
    work=Path(args.data_work);out=Path(args.out);identity=dataset_identity(work)
    # Test NPZ is deliberately never opened by training or model selection.
    tr=load(work/'data/train.npz');va=load(work/'data/validation.npz')
    audit=validate_splits(tr,va)
    if not coverage(tr)['all_classes_present'] or not coverage(va)['all_classes_present']:
        raise ValueError('all four train/validation labels required')
    smoke=bool(np.asarray(tr.get('synthetic_smoke',False)).item())
    if smoke!=bool(np.asarray(va.get('synthetic_smoke',False)).item()):raise ValueError('mixed synthetic/real splits')
    stages=('fp32','int8','v25h') if args.stage=='all' else (args.stage,)
    config=dict(seed=args.seed,batch_size=args.batch_size,threads=args.threads,device=str(device),
                base_epochs=args.base_epochs,qat_epochs=args.qat_epochs,coded_epochs=args.coded_epochs,
                lr=args.lr,qat_lr=args.qat_lr,calibration_samples=args.calibration_samples,
                sampling='inverse-frequency WeightedRandomSampler, replacement; unweighted cross entropy')
    for stage in stages:
        dest=out/'models'/stage
        report_path=dest/'training_report.json'
        if report_path.exists():
            old=json.loads(report_path.read_text())
            if old['dataset_identity']!=identity or old['config']!=config:raise ValueError('completed stage configuration differs: use a new --out')
            if sha256(dest/'weights.pt')!=old['checkpoint_sha256']:raise ValueError('completed checkpoint changed')
            print('REUSE_COMPLETED',stage,flush=True);continue
        if dest.exists() and any(dest.iterdir()):raise ValueError('incomplete stage already exists: '+str(dest)+'; inspect it, then use a new --out')
        dest.mkdir(parents=True,exist_ok=True)
        seed_all(args.seed,args.threads)
        parent=None
        if stage=='fp32':model=V25DASH(stage).to(device)
        else:
            previous='fp32' if stage=='int8' else 'int8';parent=out/'models'/previous/'weights.pt'
            previous_report=parent.with_name('training_report.json')
            if not previous_report.exists():raise ValueError('complete '+previous+' first')
            parent_model,parent_info=checkpoint(parent)
            if parent_info['dataset_identity']!=identity:raise ValueError('parent uses a different dataset')
            if sha256(parent)!=json.loads(previous_report.read_text())['checkpoint_sha256']:raise ValueError('parent checkpoint changed')
            model=V25DASH(stage);model.load_state_dict(parent_model.state_dict());model.to(device)
        rng=np.random.default_rng(args.seed)
        calib_ids=np.sort(rng.choice(len(tr['x']),min(args.calibration_samples,len(tr['x'])),replace=False))
        if stage!='fp32':
            cx=torch.from_numpy(tr['x'][calib_ids].copy()).to(device=device,dtype=torch.float32)[:,None]/256
            model.calibrate(cx);del cx
        x=torch.from_numpy(tr['x'].copy())[:,None].float()/256;y=torch.from_numpy(tr['y'].copy()).long()
        counts=np.bincount(tr['y'],minlength=4)
        sampler=WeightedRandomSampler(torch.from_numpy(1./counts[tr['y']]),len(y),replacement=True,
                                      generator=torch.Generator().manual_seed(args.seed))
        loader=DataLoader(TensorDataset(x,y),batch_size=args.batch_size,sampler=sampler,num_workers=0)
        optimizer=torch.optim.Adam(model.parameters(),lr=args.lr if stage=='fp32' else args.qat_lr)
        epochs={'fp32':args.base_epochs,'int8':args.qat_epochs,'v25h':args.coded_epochs}[stage]
        model.eval();best=validation(model,va,args.batch_size,device);best_epoch=0
        # Include calibrated epoch zero; coding QAT is permitted to improve or retain it.
        save_checkpoint(dest/'weights.pt',model,0,identity)
        hist=[dict(epoch=0,loss='',val_macro_f1=best['macro_f1'],val_accuracy=best['accuracy'],seconds=0)]
        print(stage,0,'calibrated_val_F1',round(best['macro_f1'],6),flush=True)
        for epoch in range(1,epochs+1):
            start=time.perf_counter();model.train();loss_sum=0.
            for bx,by in loader:
                bx=bx.to(device);by=by.to(device);optimizer.zero_grad(set_to_none=True)
                loss=F.cross_entropy(model(bx),by)
                if not torch.isfinite(loss):raise FloatingPointError('nonfinite training loss')
                loss.backward();optimizer.step();loss_sum+=float(loss.detach())*len(by)
            model.eval();val=validation(model,va,args.batch_size,device)
            hist.append(dict(epoch=epoch,loss=loss_sum/len(y),val_macro_f1=val['macro_f1'],
                             val_accuracy=val['accuracy'],seconds=time.perf_counter()-start))
            print(stage,epoch,'loss',round(loss_sum/len(y),5),'val_F1',round(val['macro_f1'],6),flush=True)
            if val['macro_f1']>best['macro_f1']:
                best=val;best_epoch=epoch;save_checkpoint(dest/'weights.pt',model,epoch,identity)
        model,_=checkpoint(dest/'weights.pt',device)
        write_json(dest/'validation.json',best)
        with (dest/'history.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(hist[0]));writer.writeheader();writer.writerows(hist)
        provenance=dict(dataset_identity=identity,checkpoint_sha256=sha256(dest/'weights.pt'),seed=args.seed,
                        selected_epoch=best_epoch,synthetic_smoke=smoke)
        check=None
        if stage!='fp32':
            vx,_=representatives(va,6);check=crosscheck(model,vx,device)
            export(model.export_integer(),dest/'integer',provenance)
        report=dict(status='SYNTHETIC_SMOKE_ONLY' if smoke else 'TRAINED_TEST_AND_PPA_PENDING',
                    mode=stage,source_commit=SOURCE_COMMIT,parameters=sum(p.numel() for p in model.parameters()),
                    dataset_identity=identity,config=config,split_audit=audit,train=coverage(tr),validation=coverage(va),
                    best_epoch=best_epoch,best_validation=best,selection='maximum validation macro-F1, earliest tie; includes epoch zero',
                    calibration='train only; frozen activation/weight exponents throughout QAT',
                    calibration_sample_ids=tr['sample_id'][calib_ids].astype(str).tolist() if stage!='fp32' else [],
                    quant=model.quant,parent_checkpoint_sha256=sha256(parent) if parent else None,
                    checkpoint_sha256=sha256(dest/'weights.pt'),integer_crosscheck=check,
                    ppa_status='NOT_MEASURED')
        write_json(report_path,report)
        print('COMPLETE',stage,report['status'],flush=True)
    return out

def evaluate(args):
    from .integer import load as load_integer
    from .integer import validate
    out=Path(args.out);work=Path(args.data_work)
    stages=('int8','v25h') if args.stage=='all' else (args.stage,)
    ds=[load(work/'data'/(s+'.npz')) for s in ('train','validation','test')]
    audit=validate_splits(*ds);test=ds[2];identity=dataset_identity(work)
    result={}
    for stage in stages:
        folder=out/'models'/stage;report=json.loads((folder/'training_report.json').read_text())
        if report['dataset_identity']!=identity or report['checkpoint_sha256']!=sha256(folder/'weights.pt'):
            raise ValueError('frozen checkpoint/dataset identity changed')
        p=load_integer(folder/'integer/weights_int.npz')
        if validate(p)!=stage:raise ValueError('integer mode mismatch')
        # Verify export against the frozen model so a changed NPZ cannot be evaluated silently.
        model,_=checkpoint(folder/'weights.pt');expected=model.export_integer()
        for key in expected:
            if not np.array_equal(expected[key],p[key]):raise ValueError('export changed: '+key)
        pred=predict_integer(test['x'],p,args.batch_size)
        r=metrics(test['y'],pred,test['video_id'])
        r.update(mode=stage,split_audit=audit,checkpoint_sha256=report['checkpoint_sha256'],
                 integer_sha256=sha256(folder/'integer/weights_int.npz'),test_sha256=sha256(work/'data/test.npz'),
                 status='SYNTHETIC_SMOKE_ONLY' if bool(test.get('synthetic_smoke',False)) else 'FROZEN_TEST_RESULT_PPA_PENDING')
        write_json(out/'reports'/('test_'+stage+'.json'),r)
        np.savez_compressed(out/'reports'/('test_predictions_'+stage+'.npz'),y=test['y'],prediction=pred,sample_id=test['sample_id'],video_id=test['video_id'])
        print(stage,json.dumps(r,ensure_ascii=False),flush=True);result[stage]=r
    if len(result)==2:
        write_json(out/'reports/test_comparison.json',dict(baseline='int8',candidate='v25h',
                   macro_f1_delta=result['v25h']['macro_f1']-result['int8']['macro_f1'],
                   model_selection='validation only; this is a frozen test comparison',ppa_status='NOT_MEASURED'))
```

## v25_dash/v25/transforms.py

```python
"""V25's 49-lane B/G/A order, with separate inverse floors for four blocks."""
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

B = {3: np.array([[1,0,-1,0],[0,1,1,0],[0,-1,1,0],[0,1,0,-1]], np.int64),
     2: np.array([[1,-1,0],[0,1,0],[0,-1,1]], np.int64)}
G = {3: np.array([[2,0,0],[1,1,1],[1,-1,1],[0,0,2]], np.int64),
     2: np.array([[1,0],[1,1],[0,1]], np.int64)}
A = {3: np.array([[1,1,1,0],[0,1,-1,-1]], np.int64),
     2: np.array([[1,1,0],[0,1,1]], np.int64)}
BLOCKS = ((0,0,3,3),(0,3,3,2),(3,0,2,3),(3,3,2,2))

def matrices():
    bm = np.zeros((49,36), np.int64); gm = np.zeros((49,25), np.int64)
    inverse = []; divisions = []; start = 0
    for r,c,kr,kc in BLOCKS:
        size = (kr+1)*(kc+1)
        ids_x = [(r+i)*6+c+j for i in range(kr+1) for j in range(kc+1)]
        ids_w = [(r+i)*5+c+j for i in range(kr) for j in range(kc)]
        bm[start:start+size, ids_x] = np.kron(B[kr], B[kc])
        gm[start:start+size, ids_w] = np.kron(G[kr], G[kc])
        im = np.zeros((4,49), np.int64)
        im[:, start:start+size] = np.kron(A[kr], A[kc])
        inverse.append(im); divisions.append((2 if kr==3 else 1)*(2 if kc==3 else 1))
        start += size
    return bm, gm, tuple(inverse), tuple(divisions)

BM, GM, INVERSE, DIVISIONS = matrices()

def tiles(x):
    """N,IC,H,W -> N,IC,pooled-H,pooled-W,49; tile stride is two."""
    x = np.asarray(x, np.int64)
    if x.ndim != 4 or min(x.shape[-2:]) < 6 or any((s-4)%2 for s in x.shape[-2:]):
        raise ValueError('even valid convolution dimensions required')
    t = sliding_window_view(x, (6,6), axis=(2,3))[:, :, ::2, ::2]
    return t.reshape(t.shape[:-2]+(36,)) @ BM.T

def inverse(products):
    p = np.asarray(products, np.int64)
    return sum((p @ mat.T)//div for mat,div in zip(INVERSE,DIVISIONS))

def direct_conv(x, w):
    sw = sliding_window_view(np.asarray(x,np.int64), (5,5), axis=(2,3))
    return np.einsum('nihwkl,oikl->nohw',sw,np.asarray(w,np.int64))
```

## v25_dash/v25/util.py

```python
"""Standalone I/O; reuse only the existing data audit/metrics at the CLI boundary."""
import hashlib
import json
import os
from pathlib import Path

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def write_json(path,value):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+'.tmp')
    temp.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    os.replace(temp,p)
```

## v25_dash/v25/verify.py

```python
"""Actual Icarus runs against exported integer scores and intermediate feature maps."""
import json
from pathlib import Path
import shutil
import subprocess
import numpy as np
from .transforms import BM,inverse
from .integer import validate,infer,infer_spatial
from .hardware import generate
from .util import write_json,sha256

def hexfile(path,values,bits):
    Path(path).write_text('\n'.join(format(int(x)&((1<<bits)-1),'0'+str((bits+3)//4)+'x') for x in np.asarray(values).flat)+'\n')

def compile_run(folder,top,iverilog,vvp,ivl_base=None):
    folder=Path(folder).resolve()
    iv=shutil.which(iverilog) or str(Path(iverilog).resolve())
    vp=shutil.which(vvp) or str(Path(vvp).resolve())
    cmd=[iv]
    if ivl_base:cmd+=['-B',str(Path(ivl_base).resolve())]
    cmd+=['-g2012','-s',top,'-o','simulation.vvp']+[str(p.name) for p in sorted(folder.glob('*.sv'))]
    c=subprocess.run(cmd,cwd=folder,text=True,capture_output=True,timeout=120)
    (folder/'compile.log').write_text(c.stdout+c.stderr)
    if c.returncode:raise RuntimeError('RTL compile failed: '+str(folder/'compile.log'))
    # Width mismatch is a real contract failure; Icarus constant-select notices are harmless.
    if 'expects' in c.stderr and 'bits, got' in c.stderr:raise RuntimeError('RTL port-width mismatch')
    r=subprocess.run([vp,'simulation.vvp'],cwd=folder,text=True,capture_output=True,timeout=120)
    (folder/'simulation.log').write_text(r.stdout+r.stderr)
    if r.returncode or 'PASS' not in r.stdout or 'FAIL' in r.stdout:raise RuntimeError('RTL mismatch: '+str(folder/'simulation.log'))
    print(r.stdout.strip(),flush=True)
    return r.stdout

def engine_vectors(p,folder,seed=2026,count=192):
    rng=np.random.default_rng(seed);tags=[];isfc=[];inputs=[];expected=[]
    # All eight convolution kernels and every FC temporal term appear repeatedly.
    rows=[(0,o*4,p['q1_td'][o,0]) for o in range(2)]
    rows +=[(0,0x8000+o*4+i,p['q2_td'][o,i]) for o in range(3) for i in range(2)]
    rows +=[(1,t*16+c,p['fc_terms'][c,:,t]) for c in range(4) for t in range(p['fc_terms'].shape[-1])]
    for k in range(count):
        fc,tag,co=rows[k%len(rows)];x=rng.integers(0,256,48,dtype=np.int64)
        if k<len(rows):x[:]=255 if k%2 else 0
        y=np.array([np.dot(x,co),0,0,0]) if fc else inverse((BM@x[:36])*co)
        tags.append(tag);isfc.append(fc);inputs.append(x);expected.append(y)
    for name,arr,bits in [('engine_x.hex',inputs,8),('engine_tag.hex',tags,16),('engine_fc.hex',isfc,1),('engine_y.hex',expected,32)]:hexfile(folder/name,arr,bits)
    text=f'''`timescale 1ps/1ps
module tb_engine;
reg clk=0,rst_n=0,req_valid=0,req_is_fc=0;reg [15:0] req_tag=0;
reg signed [8:0] tile[0:5][0:5],fa[0:47];wire rv,rf;wire [15:0] rt;
wire signed [31:0] y0,y1,y2,y3,fs;
v25_dash_engine dut(clk,rst_n,req_valid,req_is_fc,req_tag,tile,fa,rv,rf,rt,y0,y1,y2,y3,fs);
always #5 clk=~clk;
reg [7:0] xs[0:{count*48-1}];reg [15:0] tags[0:{count-1}];reg fcs[0:{count-1}];reg [31:0] ys[0:{count*4-1}];
integer sent=0,received=0,r,c,j,cycle=0,issue_cycle[0:{count-1}];
always @(posedge clk)begin
 cycle=cycle+1;
 if(rst_n && req_valid)begin issue_cycle[sent]=cycle;sent=sent+1;end
 #1;
 if(rst_n && rv)begin
  if(received>=sent || rt!==tags[received] || rf!==fcs[received])$fatal(1,"FAIL engine tag/order");
  if(cycle-issue_cycle[received]!=6)$fatal(1,"FAIL engine latency");
  if(rf)begin if(fs!==ys[received*4])$fatal(1,"FAIL FC engine case=%0d got=%0d expected=%0d",received,fs,$signed(ys[received*4]));end
  else if(y0!==ys[received*4]||y1!==ys[received*4+1]||y2!==ys[received*4+2]||y3!==ys[received*4+3])
   $fatal(1,"FAIL Conv engine case=%0d got=%0d,%0d,%0d,%0d expected=%0d,%0d,%0d,%0d",received,y0,y1,y2,y3,$signed(ys[received*4]),$signed(ys[received*4+1]),$signed(ys[received*4+2]),$signed(ys[received*4+3]));
  received=received+1;
 end
end
initial begin
 $readmemh("engine_x.hex",xs);$readmemh("engine_tag.hex",tags);$readmemh("engine_fc.hex",fcs);$readmemh("engine_y.hex",ys);
 repeat(3)@(negedge clk);rst_n=1;
 for(j=0;j<{count};j=j+1)begin
  if(j%11==0)begin req_valid=0;@(negedge clk);end
  req_valid=1;req_tag=tags[j];req_is_fc=fcs[j];
  for(r=0;r<6;r=r+1)for(c=0;c<6;c=c+1)tile[r][c]={{1'b0,xs[j*48+r*6+c]}};
  for(r=0;r<48;r=r+1)fa[r]={{1'b0,xs[j*48+r]}};
  @(negedge clk);
 end
 req_valid=0;repeat(10)@(negedge clk);
 if(received!={count})$fatal(1,"FAIL missing engine results");
 $display("PASS engine: {count} requests, all coefficient tags, bubbles, II=1, latency=6");$finish;
end
endmodule
'''
    (folder/'tb_engine.sv').write_text(text)

def top_vectors(x,p,folder):
    golden=infer(x,p);count=len(x)
    for name,arr,bits in [('pixels.hex',x,8),('scores.hex',golden['scores'],32),('pool1.hex',golden['pool1'],8),('pool2.hex',golden['pool2'],8),('decision.hex',golden['decision'],2)]:hexfile(folder/name,arr,bits)
    text=f'''`timescale 1ps/1ps
module tb_top;
reg clk=0,rst_n=0;reg [7:0] data_in=0;wire [1:0] decision;wire valid_out_6;wire [127:0] logits;
v25_dash_top dut(clk,rst_n,data_in,decision,valid_out_6,logits);
always #5 clk=~clk;
reg [7:0] pixels[0:{count*784-1}],p1[0:{count*288-1}],p2[0:{count*48-1}];
reg [31:0] scores[0:{count*4-1}];reg [1:0] decisions[0:{count-1}];
integer n,j,c,r,col,cycles;
always @(posedge clk)begin
 if(rst_n)begin
  if(dut.c1_wb_valid)begin
   r=dut.c1_commit_count/24;c=dut.c1_wb_oc;col=dut.c1_wb_pc;
   if(dut.max4_relu_a8(dut.c1_wb_q00,dut.c1_wb_q01,dut.c1_wb_q10,dut.c1_wb_q11)!==p1[n*288+c*144+r*12+col])
    $fatal(1,"FAIL pool1 case=%0d channel=%0d row=%0d col=%0d",n,c,r,col);
  end
 end
end
task reset_patch;begin rst_n=0;data_in=0;repeat(3)@(negedge clk);rst_n=1;@(negedge clk);end endtask
initial begin
 $readmemh("pixels.hex",pixels);$readmemh("scores.hex",scores);$readmemh("pool1.hex",p1);$readmemh("pool2.hex",p2);$readmemh("decision.hex",decisions);
 for(n=0;n<{count};n=n+1)begin
  reset_patch();
  for(j=0;j<784;j=j+1)begin data_in=pixels[n*784+j];@(negedge clk);end
  data_in=0;cycles=784;
  while(!valid_out_6 && cycles<2000)begin @(negedge clk);cycles=cycles+1;end
  if(!valid_out_6)$fatal(1,"FAIL top timeout");
  for(c=0;c<4;c=c+1)if(logits[c*32+:32]!==scores[n*4+c])$fatal(1,"FAIL score case=%0d class=%0d got=%0d expected=%0d",n,c,$signed(logits[c*32+:32]),$signed(scores[n*4+c]));
  if(decision!==decisions[n])$fatal(1,"FAIL decision");
  for(c=0;c<3;c=c+1)for(r=0;r<4;r=r+1)for(col=0;col<4;col=col+1)
   if(dut.fmap2[c][r][col]!==p2[n*48+c*16+r*4+col])$fatal(1,"FAIL pool2");
  if(dut.c1_commit_count!=288||dut.c2_commit_count!=48)$fatal(1,"FAIL commit count");
  $display("PASS top case=%0d class=%0d input_start_to_result_cycles=%0d",n,decision,cycles);
  repeat(3)begin @(negedge clk);if(valid_out_6)$fatal(1,"FAIL repeated valid");end
 end
 // Interrupt a fresh patch, reset, then reproduce case zero to catch stale ring/valid state.
 n=0;reset_patch();for(j=0;j<97;j=j+1)begin data_in=pixels[j];@(negedge clk);end
 reset_patch();for(j=0;j<784;j=j+1)begin data_in=pixels[j];@(negedge clk);end
 cycles=784;while(!valid_out_6&&cycles<2000)begin @(negedge clk);cycles=cycles+1;end
 if(!valid_out_6||decision!==decisions[0])$fatal(1,"FAIL mid-patch reset");
 for(c=0;c<4;c=c+1)if(logits[c*32+:32]!==scores[c])$fatal(1,"FAIL reset score");
 $display("PASS top: all four scores, both pooled maps, U8 extremes, repeat reset, mid-patch reset");$finish;
end
endmodule
'''
    (folder/'tb_top.sv').write_text(text)

def verify(p,x,out,iverilog='iverilog',vvp='vvp',ivl_base=None):
    name=validate(p);out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    # Validation representatives plus boundary patterns. Never consult test data here.
    x=np.asarray(x,np.uint8)
    checker=np.indices((28,28)).sum(0)%2*255
    vectors=np.concatenate((x,np.zeros((1,28,28),np.uint8),np.full((1,28,28),255,np.uint8),checker[None].astype(np.uint8)))
    a=infer(vectors,p)
    b=infer(vectors,p,'shift') if name=='v25h' else infer_spatial(vectors,p)
    for key in a:
        if not np.array_equal(a[key],b[key]):raise AssertionError('independent integer backend mismatch: '+key)
    backends=('mul','shift') if name=='v25h' else ('mul',)
    logs={}
    for backend in backends:
        folder=generate(p,out/backend,backend)
        engine_vectors(p,folder);top_vectors(vectors,p,folder)
        logs[backend]=dict(engine=compile_run(folder,'tb_engine',iverilog,vvp,ivl_base),
                           top=compile_run(folder,'tb_top',iverilog,vvp,ivl_base),
                           rtl_sha256={f.name:sha256(f) for f in folder.glob('v25_*.sv')})
    report=dict(status='PASS_EXPORTED_INTEGER_AND_ACTUAL_RTL',mode=name,backend_equivalence=True,
                validation_and_edge_cases=len(vectors),source='validation + synthetic U8 patterns',
                protocol='one prime cycle after reset; continuous 784 bytes; no input stalls; per-patch reset',
                ppa_status='NOT_MEASURED',logs=logs)
    write_json(out/'verification.json',report);return report
```

