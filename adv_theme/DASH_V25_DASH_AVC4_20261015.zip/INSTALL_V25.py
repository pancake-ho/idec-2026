#!/usr/bin/env python3
"""Add only v25_dash to an existing adv_theme; reject conflicts rather than overwrite."""
import argparse
import hashlib
from pathlib import Path
import shutil

def digest(p):return hashlib.sha256(p.read_bytes()).digest()

def main():
    a=argparse.ArgumentParser();a.add_argument('--adv-theme',required=True);args=a.parse_args()
    source=Path(__file__).resolve().parent/'v25_dash';root=Path(args.adv_theme).resolve()
    required=('src/dash_cnn/data/audit.py','src/dash_cnn/evaluation/metrics.py','tests/make_smoke_data.py')
    for f in required:
        if not (root/f).is_file():raise SystemExit('Existing adv_theme helper missing: '+str(root/f))
    dest=root/'v25_dash';pairs=[(p,dest/p.relative_to(source)) for p in sorted(source.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
    # Complete conflict check before copying any file.
    for original,target in pairs:
        if target.is_symlink():raise SystemExit('Refusing symlink target: '+str(target))
        if target.exists() and (not target.is_file() or digest(original)!=digest(target)):
            raise SystemExit('Different v25_dash file already exists: '+str(target)+'; choose another installation root')
        for parent in target.parents:
            if parent==root:break
            if parent.is_symlink():raise SystemExit('Refusing symlink directory: '+str(parent))
    added=0
    for original,target in pairs:
        if not target.exists():target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,target);added+=1
    print('INSTALLED',dest,'new_files='+str(added))
    print('Next: cd '+str(root)+' && python v25_dash/run.py doctor')

if __name__=='__main__':main()
