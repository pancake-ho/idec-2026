# 실행 명령 — moana-master / 기존 lab 환경

ZIP에는 기존 `adv_theme`에 추가할 `v25_dash/`, 안전한 추가 설치 스크립트, 코드 전문, 검증 기록이 들어 있다. BBB·ED 다운로드나 `prepare`를 다시 할 필요가 없다. `runs/avc4/data/{train,validation,test}.npz`를 그대로 읽는다.

## 1. 설치

ZIP을 서버에 복사하고 새 임시 디렉터리에서 해제한다. ZIP이 홈에 있다면 아래처럼 실행한다. 실제 ZIP 위치만 맞추면 된다.

```bash
conda activate lab
mkdir -p /tmp/dash_v25_install_20261015
unzip ~/DASH_V25_DASH_AVC4_20261015.zip -d /tmp/dash_v25_install_20261015
python /tmp/dash_v25_install_20261015/INSTALL_V25.py \
  --adv-theme /data/surt321/repos/idec/adv_theme
cd /data/surt321/repos/idec/adv_theme
python v25_dash/run.py doctor
python v25_dash/run.py selftest
```

doctor에서 `channels: [1,2,3]`, `fc: [48,4]`, `parameters: 401`이면 새 코드다. 기존 Torch 2.4.1과 NumPy를 사용한다. 기존 환경을 다시 설치하지 않는다. 동일 파일로 재설치하는 것은 가능하지만 다른 내용의 `v25_dash`가 이미 있으면 설치기는 먼저 멈춘다.

## 2. 우선 FP32 학습

먼저 작은 V25 구조의 성능부터 확인한다. 이 명령의 기본값은 FP32 40 epoch, batch 64, seed 2026, CPU 2 thread다.

```bash
python -u v25_dash/run.py train \
  --data-work runs/avc4 --out runs/v25_avc4 \
  --stage fp32 --device cpu
```

확인할 파일:

```bash
cat runs/v25_avc4/models/fp32/training_report.json
cat runs/v25_avc4/models/fp32/validation.json
cat runs/v25_avc4/models/fp32/history.csv
```

먼저 이 세 파일을 첨부하면 기존 모델과 비교해 구조 축소의 영향을 볼 수 있다. FP32가 학습되지 않거나 클래스별 성능이 무너지면 test를 반복해서 보며 튜닝하지 않고 train/validation에서 원인을 확인한다.

## 3. INT8 before 기준과 V25-H QAT

```bash
python -u v25_dash/run.py train \
  --data-work runs/avc4 --out runs/v25_avc4 \
  --stage int8 --device cpu

python -u v25_dash/run.py train \
  --data-work runs/avc4 --out runs/v25_avc4 \
  --stage v25h --device cpu
```

두 단계는 기본 15 epoch씩이다. FP32→INT8, INT8→V25-H 순서로 validation 최상 체크포인트를 가져오며 각 단계에 진입할 때 train-only scale을 정한다. INT8·V25 모두 2/3채널 구조이며 기존 6/12채널 모델은 이 경로에 들어오지 않는다.

처음부터 세 단계를 연속 실행하려면 위 세 명령 대신 다음 한 번으로 실행해도 된다. 같은 설정으로 완료된 단계는 재사용한다.

```bash
python -u v25_dash/run.py train \
  --data-work runs/avc4 --out runs/v25_avc4 \
  --stage all --device cpu
```

기본 설정을 바꾼 실험은 `--out runs/v25_avc4_seed2`처럼 새 폴더를 사용한다. 중단된 학습의 자동 resume은 이번 패키지에 없으며, 완료된 단계만 재사용한다. 기존 결과를 조용히 덮어쓰지 않도록 미완료 폴더가 있으면 명시적으로 실패한다.

## 4. 실제 생성 RTL 검증

서버 doctor에서 이미 확인한 `iverilog`·`vvp`를 사용한다. `--stage all`은 INT8 MUL과 V25-H MUL/SHIFT를 모두 검증한다.

```bash
python -u v25_dash/run.py verify-export \
  --data-work runs/avc4 --out runs/v25_avc4 --stage all
```

원하는 경로를 지정해야 하면 `--iverilog /path/to/iverilog --vvp /path/to/vvp`를 추가한다. 별도 추출 설치의 Icarus library 경로만 `--ivl-base /path/to/ivl`로 전달한다. 서버의 정상 conda 설치에는 필요 없다.

```bash
cat runs/v25_avc4/verification/int8/verification.json
cat runs/v25_avc4/verification/v25h/verification.json
```

`PASS_EXPORTED_INTEGER_AND_ACTUAL_RTL`을 확인한다. RTL은 각 `verification/{int8,v25h}/{mul,shift}/v25_dash_*.sv`에 생성된다. INT8에는 shift backend가 없다. `verification.json`의 cycle 수를 Fmax로 읽지 않는다.

## 5. 선택 완료 후 frozen test

validation으로 후보/설정을 확정한 후 실행한다.

```bash
python -u v25_dash/run.py evaluate \
  --data-work runs/avc4 --out runs/v25_avc4 --stage all

cat runs/v25_avc4/reports/test_int8.json
cat runs/v25_avc4/reports/test_v25h.json
cat runs/v25_avc4/reports/test_comparison.json
```

macro-F1, 클래스별 F1·recall·혼동행렬, poor→excellent, 평균 등급 오차, 영상별 결과를 확인한다. test 결과를 바탕으로 반복 후보 선택을 하면 이 test는 개발용 데이터가 되므로 별도 미사용 평가 구간이 필요하다.

## 6. PPA flow 입력 생성

```bash
python v25_dash/run.py flow --out runs/v25_avc4 --period-ns 10
```

`runs/v25_avc4/flow/{before_int8_mul,after_v25h_shift,ablation_v25h_mul}`에 RTL, `config.mk`, SDC, Vivado Tcl이 생성된다. 실제 합성 도구가 설치된 머신에서 실행한다. 아래 ORFS 위치는 예시이므로 설치 경로로 바꾼다.

```bash
cd /path/to/OpenROAD-flow-scripts
source env.sh
yosys -m slang -p slang_version
cd flow
make DESIGN_CONFIG=/data/surt321/repos/idec/adv_theme/runs/v25_avc4/flow/before_int8_mul/config.mk
make DESIGN_CONFIG=/data/surt321/repos/idec/adv_theme/runs/v25_avc4/flow/after_v25h_shift/config.mk
make DESIGN_CONFIG=/data/surt321/repos/idec/adv_theme/runs/v25_avc4/flow/ablation_v25h_mul/config.mk
```

ASAP7 시간 단위는 ps를 가정한다. `report_units`로 확인하고 두 설계에 동일하게 적용한다. 10ns는 기본 SDC의 10,000ps이며 한계 Fmax를 찾은 주기가 아니다. Vivado를 사용한다면 각 flow 폴더에서 동일한 실제 FPGA part로 `vivado -mode batch -source vivado.tcl -tclargs 실제_PART`를 실행한다. 제공한 flow 파일 자체의 생성은 확인했지만 합성/P&R은 아직 실행하지 않았다.

## 7. 서버에서 먼저 짧게 연결 검사하고 싶을 때

새 합성 폴더로 실행한다. 이 결과는 BBB·ED 품질 성능이 아니다.

```bash
cd /data/surt321/repos/idec/adv_theme
python v25_dash/run.py smoke --data-work runs/v25_smoke_data
python -u v25_dash/run.py train \
  --data-work runs/v25_smoke_data --out runs/v25_smoke \
  --base-epochs 2 --qat-epochs 2 --coded-epochs 2 \
  --calibration-samples 24 --device cpu
python -u v25_dash/run.py verify-export \
  --data-work runs/v25_smoke_data --out runs/v25_smoke
```

## 결과를 보내줄 때

우선 `models/fp32/{training_report.json,validation.json,history.csv}`를 보내면 된다. 나머지 단계 완료 후에는 INT8·V25-H의 동일 세 파일과 `verification/*/verification.json`, frozen test 두 JSON을 함께 첨부하면 FP32 용량·INT8 양자화·V25 코딩의 영향을 단계별로 비교할 수 있다.
