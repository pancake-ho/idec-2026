# DASH AVC4 FFmpeg 호환 패치 — 2026-10-14

## 오류와 현재 상태

사용자 로그의 실패는 `Unrecognized option 'fps_mode'`이다. 설치된 FFmpeg가
기존 `src/dash_cnn/data/media.py`의 `-fps_mode passthrough`를 지원하지 않는다.
정확한 서버 FFmpeg 버전은 이전 doctor 출력에 없으므로 단정하지 않는다.
산술 검사, RTL 검사, BBB/ED 다운로드는 완료됐고, prepare는 BBB rep_19 디코더에서
중단됐다. BBB 원본 캐시 생성 후의 실패이므로 같은 경로로 재실행하면 재사용한다.
원본 파일의 SHA-256 재확인에는 시간이 걸릴 수 있다.

## 개선한 동작

- FFmpeg `-h full`을 확인하여 `-fps_mode passthrough`를 우선 선택하고,
  해당 옵션이 없을 때 `-vsync 0`을 선택한다. 두 옵션 모두 없으면 준비 초기에 중단한다.
- prepare가 큰 원본 압축을 읽기 전에 FFmpeg 호환성을 확인하고 선택한 옵션을 출력한다.
- doctor가 호스트명, FFmpeg/FFprobe 버전, 선택한 프레임 동기화 옵션을 출력한다.
- 새 디코딩 캐시에 FFmpeg 버전과 선택한 옵션을 기록한다. 기존 캐시도 재사용한다.
- 실행 코드 3개와 호환 검사 1개, 최신 코드 전문과 소스 해시 목록을 제공한다.

프레임 선택 후 자동 CFR 변환을 하면 프레임을 복제/삭제할 수 있으므로 동기화 옵션을
단순히 지우지 않는다. SSIM 경계, split, 모델, RTL은 변경하지 않는다.

## 적용 및 재실행

이 ZIP을 서버의 `/data/surt321/repos/idec/adv_theme/`에 올린 뒤 다음을 실행한다.
처음 unzip 출력에 나타나는 폴더는 `DASH_AVC4_ffmpeg_compat_fix/`이다.

```bash
conda activate lab
cd /data/surt321/repos/idec/adv_theme
unzip DASH_AVC4_ffmpeg_compat_fix_20261014.zip -d /tmp/dash_avc4_ffmpeg_fix_20261014
python /tmp/dash_avc4_ffmpeg_fix_20261014/DASH_AVC4_ffmpeg_compat_fix/APPLY_FIX.py --root "$PWD"
python scripts/run.py doctor
python scripts/run.py prepare --media-work runs/assets --work runs/avc4
python scripts/run.py audit --work runs/avc4
```

`prepare`가 성공한 뒤에만 `audit`을 실행한다. doctor의 `frame_sync_args`가
`["-vsync", "0"]` 또는 `["-fps_mode", "passthrough"]`이면 해당 분기가 선택됐다.
`ffmpeg_error`가 출력되면 그 내용을 확인하고 먼저 해결한다.
다운로드나 `runs/assets/cache` 삭제, 전체 패키지 재설치는 필요하지 않다.
현재 로그에서 NPZ 생성까지 진행하지 않았으므로 동일한 `runs/avc4`를 사용한다.
이미 다른 시도에서 NPZ를 완성했다면 이를 덮어쓰지 말고 새 work 경로를 선택한다.

패치 적용은 전달했던 원본과 파일 SHA-256이 일치할 때만 진행한다. 알려지지 않은 수정이
있으면 어떤 파일도 바꾸지 않고 해당 경로를 출력한다. 이 경우 출력된 파일을 확인하여
수정 내용을 합쳐야 한다. 정상 적용 시 `patch_backups/ffmpeg_compat_.../`에 원본을 보관한다.
`--check`를 추가하면 적용 가능 여부만 검사할 수 있고, 같은 패치를 다시 실행하면 변경하지 않는다.

선택적으로 `python tests/test_ffmpeg_compat.py`를 실행하면 해당 서버의 실제 디코더로
간격이 있는 프레임의 개수·픽셀·기존 캐시 재사용을 검증한다. 이 검사에 한해 작은 임시
H.264 파일을 만들기 때문에 FFmpeg의 `libx264` 인코더도 필요하다. 실제 prepare에는
H.264 디코더, extractplanes 필터, PNG 인코더가 필요하며 libx264 인코더는 필요하지 않다.

## 이번 패치 검증 범위

- FFmpeg 옵션 탐지 5개 + 실제 sparse frame 추출 2개: 7개 통과.
- FFmpeg 6.1.1에서 modern/legacy 옵션 모두 전체 디코드의 해당 Y 프레임과 픽셀 단위 일치.
- 구형 도움말은 모의 입력으로 검사했다. 사용자의 구형 FFmpeg 자체를 실행한 결과는 아니다.
- 기존 데이터 검사 9개 통과.
- 합성 영상 2개/AVC 인코딩 6개로 전체 prepare 파이프라인 통과.
- 패치 설치·반복 적용·사용자 수정 충돌 거부·기존 데이터 보존 검사 통과.

실제 BBB/ED 준비 완료, 실제 콘텐츠 정확도, GPU 학습은 이번 환경에서 새로 측정하지 않았다.

## GPU와 서버

로그의 실행 호스트는 `moana-master`이고 `cuda_available: false`, GPU 0개로 보인다.
이 오류는 GPU와 관계없는 FFmpeg 인자 오류이며 prepare는 CPU로 실행할 수 있다.
이 정보만으로 SERAPH의 GPU 노드 구성이나 접속 경로를 판단하지 않는다.
CUDA 학습 전에 의도한 GPU 할당 세션에서 doctor를 다시 실행하여 GPU 노출을 확인한다.
현재 오류를 해결하기 위해 Torch/CUDA 패키지를 교체할 필요는 없다.

## 출처

- FFmpeg frame sync 설명: https://ffmpeg.org/ffmpeg.html#Advanced-options
- legacy vsync 0 = passthrough:
  https://ffmpeg.org/pipermail/ffmpeg-cvslog/2021-December/129992.html

`payload/CODE_FULL.md`는 패치 적용 후 코드 전문이다.
`changes.diff`는 원본 ZIP과 실행 코드 변경 내용을 비교할 수 있는 diff이다.
