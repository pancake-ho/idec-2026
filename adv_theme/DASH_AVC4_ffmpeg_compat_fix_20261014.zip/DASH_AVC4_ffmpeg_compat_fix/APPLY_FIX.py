#!/usr/bin/env python3
"""Apply only reviewed patch files; reject unknown local edits before writing."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile

HERE = Path(__file__).resolve().parent

def digest(data):
    return hashlib.sha256(data).hexdigest()

def atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True, help='Existing adv_theme directory')
    ap.add_argument('--check', action='store_true', help='Check applicability without writing')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    if not (root / 'configs/avc4.json').is_file():
        ap.error('--root must point to the existing adv_theme directory')
    entries = json.loads((HERE / 'PATCH_MANIFEST.json').read_text())['files']
    changes = []
    # Prevalidate every original and replacement before the first mutation.
    for rel, identity in entries.items():
        relative = Path(rel)
        if relative.is_absolute() or '..' in relative.parts:
            raise SystemExit('Unsafe patch path: ' + rel)
        target = root / relative
        if target.is_symlink() or not target.resolve().is_relative_to(root):
            raise SystemExit('Refusing a symlink/outside-root target: ' + rel)
        replacement = (HERE / 'payload' / relative).read_bytes()
        if digest(replacement) != identity['new_sha256']:
            raise SystemExit('Patch payload checksum failed: ' + rel)
        old = target.read_bytes() if target.exists() else None
        old_sha = None if old is None else digest(old)
        if old_sha == identity['new_sha256']:
            continue
        if old_sha != identity['original_sha256']:
            raise SystemExit('Local file differs from the delivered source; no files changed: '
                             + rel + '\nPlease review this file before applying the patch.')
        changes.append((rel, target, old, replacement))
    if not changes:
        print('Already applied; no files changed.')
        return
    print('Files to update:', ', '.join(item[0] for item in changes))
    if args.check:
        print('CHECK PASS; no files changed.')
        return
    parent = root / 'patch_backups'
    if not parent.resolve().is_relative_to(root):
        raise SystemExit('Refusing an outside-root backup directory')
    parent.mkdir(exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_')
    backup = Path(tempfile.mkdtemp(prefix='ffmpeg_compat_' + timestamp, dir=parent))
    for rel, target, old, replacement in changes:
        if old is not None:
            saved = backup / rel
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
    (backup / 'restore_manifest.json').write_text(json.dumps({
        'root': str(root), 'files': [{
            'path': rel, 'previously_existed': old is not None,
            'old_sha256': None if old is None else digest(old),
            'new_sha256': digest(replacement)
        } for rel, target, old, replacement in changes]
    }, indent=2) + '\n')
    written = []
    try:
        for rel, target, old, replacement in changes:
            current = target.read_bytes() if target.exists() else None
            if current != old:
                raise RuntimeError('File changed while applying patch: ' + rel)
            atomic_write(target, replacement)
            written.append((target, old))
    except Exception:
        for target, old in reversed(written):
            if old is None:
                target.unlink()
            else:
                atomic_write(target, old)
        raise
    print('PATCH APPLIED; backup:', backup)
    print('Existing runs/, downloads, caches, configs and RTL were preserved.')

if __name__ == '__main__':
    main()
