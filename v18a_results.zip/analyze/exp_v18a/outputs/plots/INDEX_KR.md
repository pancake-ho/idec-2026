# V18A 그래프 모음

CSV/JSON/NPZ 결과에서 생성한 정적 그래프입니다. 영어 축·제목을 사용해 서버의 한국어 폰트 설치에 의존하지 않습니다.
색상·마커·선 종류는 `plots/style.py`에서 함께 조정합니다. 숫자 원본과 SHA-256은 `plot_manifest.json`에 기록합니다.
정확도는 고유 이미지 기준이며, 회로 비용은 q-domain 구조 가정입니다. 실제 ASIC PPA 측정은 포함되지 않습니다.

## weight_sensitivity_even

범위: calibration

[weight_sensitivity_even.png](weight_sensitivity_even.png) · [weight_sensitivity_even.pdf](weight_sensitivity_even.pdf)

![weight_sensitivity_even](weight_sensitivity_even.png)

## weight_sensitivity_floor

범위: calibration

[weight_sensitivity_floor.png](weight_sensitivity_floor.png) · [weight_sensitivity_floor.pdf](weight_sensitivity_floor.pdf)

![weight_sensitivity_floor](weight_sensitivity_floor.png)

## activation_sensitivity_even

범위: calibration

[activation_sensitivity_even.png](activation_sensitivity_even.png) · [activation_sensitivity_even.pdf](activation_sensitivity_even.pdf)

![activation_sensitivity_even](activation_sensitivity_even.png)

## activation_sensitivity_floor

범위: calibration

[activation_sensitivity_floor.png](activation_sensitivity_floor.png) · [activation_sensitivity_floor.pdf](activation_sensitivity_floor.pdf)

![activation_sensitivity_floor](activation_sensitivity_floor.png)

## candidate_tradeoff

범위: validation

[candidate_tradeoff.png](candidate_tradeoff.png) · [candidate_tradeoff.pdf](candidate_tradeoff.pdf)

![candidate_tradeoff](candidate_tradeoff.png)

## channel_class_heatmaps

범위: calibration; n=60 unique images

[channel_class_heatmaps.png](channel_class_heatmaps.png) · [channel_class_heatmaps.pdf](channel_class_heatmaps.pdf)

![channel_class_heatmaps](channel_class_heatmaps.png)

## feature_separability

범위: calibration; n=60 unique images

[feature_separability.png](feature_separability.png) · [feature_separability.pdf](feature_separability.pdf)

![feature_separability](feature_separability.png)

## pooled_activation_distributions

범위: calibration; n=60 unique images

[pooled_activation_distributions.png](pooled_activation_distributions.png) · [pooled_activation_distributions.pdf](pooled_activation_distributions.pdf)

![pooled_activation_distributions](pooled_activation_distributions.png)

## baseline_margin_distribution

범위: calibration; n=60 unique images

[baseline_margin_distribution.png](baseline_margin_distribution.png) · [baseline_margin_distribution.pdf](baseline_margin_distribution.pdf)

![baseline_margin_distribution](baseline_margin_distribution.png)

## weight_channel_ranges

범위: original parameters

[weight_channel_ranges.png](weight_channel_ranges.png) · [weight_channel_ranges.pdf](weight_channel_ranges.pdf)

![weight_channel_ranges](weight_channel_ranges.png)

## baseline_wrap_events

범위: calibration; n=60 unique images

[baseline_wrap_events.png](baseline_wrap_events.png) · [baseline_wrap_events.pdf](baseline_wrap_events.pdf)

![baseline_wrap_events](baseline_wrap_events.png)

## lane_observed_widths

범위: calibration; n=60 unique images

[lane_observed_widths.png](lane_observed_widths.png) · [lane_observed_widths.pdf](lane_observed_widths.pdf)

![lane_observed_widths](lane_observed_widths.png)

## selected_lane_widths

범위: guaranteed code-range structural model

[selected_lane_widths.png](selected_lane_widths.png) · [selected_lane_widths.pdf](selected_lane_widths.pdf)

![selected_lane_widths](selected_lane_widths.png)

## selected_accuracy_decisions_cost

범위: internal split / all-unique descriptive / structural proxy

[selected_accuracy_decisions_cost.png](selected_accuracy_decisions_cost.png) · [selected_accuracy_decisions_cost.pdf](selected_accuracy_decisions_cost.pdf)

![selected_accuracy_decisions_cost](selected_accuracy_decisions_cost.png)

## selected_confusions

범위: all-unique descriptive

[selected_confusions.png](selected_confusions.png) · [selected_confusions.pdf](selected_confusions.pdf)

![selected_confusions](selected_confusions.png)

## selected_margin_changes

범위: all-unique descriptive

[selected_margin_changes.png](selected_margin_changes.png) · [selected_margin_changes.pdf](selected_margin_changes.pdf)

![selected_margin_changes](selected_margin_changes.png)

